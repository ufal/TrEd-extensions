<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="sample6.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94202-45-p1s1">
  <m id="m-ln94202-45-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p1s1w1</w.rf>
   <form>Možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-45-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p1s1w2</w.rf>
   <form>hypoték</form>
   <lemma>hypotéka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94202-45-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p1s1w3</w.rf>
   <form>parlament</form>
   <lemma>parlament</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-45-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p1s1w4</w.rf>
   <form>projedná</form>
   <lemma>projednat_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-45-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p1s1w5</w.rf>
   <form>koncem</form>
   <lemma>konec</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94202-45-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p1s1w6</w.rf>
   <form>letošního</form>
   <lemma>letošní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94202-45-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p1s1w7</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
 </s>
 <s id="m-ln94202-45-p2s1A">
  <m id="m-ln94202-45-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Aw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Aw3</w.rf>
   <form>haš</form>
   <lemma>haš-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94202-45-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Aw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Aw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-45-p2s1B">
  <m id="m-ln94202-45-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw1</w.rf>
   <form>Česká</form>
   <lemma>český</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw2</w.rf>
   <form>národní</form>
   <lemma>národní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw3</w.rf>
   <form>banka</form>
   <lemma>banka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw4</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw5</w.rf>
   <form>připravila</form>
   <lemma>připravit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw6</w.rf>
   <form>text</form>
   <lemma>text</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw7</w.rf>
   <form>nového</form>
   <lemma>nový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw8</w.rf>
   <form>bankovního</form>
   <lemma>bankovní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw9</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw11</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw12</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw13</w.rf>
   <form>umožnit</form>
   <lemma>umožnit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw14</w.rf>
   <form>hypoteční</form>
   <lemma>hypoteční</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw15</w.rf>
   <form>úvěry</form>
   <lemma>úvěr</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw18</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw19</w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw20</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw21</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw22</w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PPZS4--3------2</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw23</w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw24</w.rf>
   <form>obdržet</form>
   <lemma>obdržet</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw25</w.rf>
   <form>poslanci</form>
   <lemma>poslanec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw26</w.rf>
   <form>parlamentu</form>
   <lemma>parlament</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s1Bw27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-45-p2s2">
  <m id="m-ln94202-45-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94202-45-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w2</w.rf>
   <form>včerejším</form>
   <lemma>včerejší</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w3</w.rf>
   <form>televizním</form>
   <lemma>televizní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w4</w.rf>
   <form>pořadu</form>
   <lemma>pořad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w5</w.rf>
   <form>Debata</form>
   <lemma>debata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w6</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-ln94202-45-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w7</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94202-45-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w8</w.rf>
   <form>odvoláním</form>
   <lemma>odvolání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94202-45-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w10</w.rf>
   <form>guvernéra</form>
   <lemma>guvernér</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w11</w.rf>
   <form>ČNB</form>
   <lemma>ČNB-1_:B_;K_;b_^(Česká_národní_banka)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94202-45-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w12</w.rf>
   <form>Josefa</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w13</w.rf>
   <form>Tošovského</form>
   <lemma>Tošovský_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w14</w.rf>
   <form>uvedl</form>
   <lemma>uvést</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-45-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w15</w.rf>
   <form>ministr</form>
   <lemma>ministr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w16</w.rf>
   <form>hospodářství</form>
   <lemma>hospodářství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w17</w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w18</w.rf>
   <form>Dyba</form>
   <lemma>Dyba_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w19</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w20</w.rf>
   <form>ODS</form>
   <lemma>ODS-1_:B_;K_;p_^(Občanská_demokratická_strana)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94202-45-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s2w22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-45-p2s3">
  <m id="m-ln94202-45-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w1</w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w2</w.rf>
   <form>změnách</form>
   <lemma>změna</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w3</w.rf>
   <form>mechanismu</form>
   <lemma>mechanismus</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w4</w.rf>
   <form>úvěrů</form>
   <lemma>úvěr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w6</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w7</w.rf>
   <form>něho</form>
   <lemma>on-1_^(on)</lemma>
   <tag>P5ZS2--3------1</tag>
  </m>
  <m id="m-ln94202-45-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w8</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-ln94202-45-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w9</w.rf>
   <form>jednat</form>
   <lemma>jednat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w10</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w11</w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w13</w.rf>
   <form>rámci</form>
   <lemma>rámec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w14</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w15</w.rf>
   <form>diskuse</form>
   <lemma>diskuse</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w16</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w17</w.rf>
   <form>státním</form>
   <lemma>státní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w18</w.rf>
   <form>rozpočtu</form>
   <lemma>rozpočet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w20</w.rf>
   <form>ovšem</form>
   <lemma>ovšem-1_^(avšak,_však;_odporovací_spojka)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w21</w.rf>
   <form>uvažované</form>
   <lemma>uvažovaný_^(*2t)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w22</w.rf>
   <form>podmínky</form>
   <lemma>podmínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w23</w.rf>
   <form>hypoték</form>
   <lemma>hypotéka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w24</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-45-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w25</w.rf>
   <form>Dyba</form>
   <lemma>Dyba_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-45-p2s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w26</w.rf>
   <form>nezná</form>
   <lemma>znát</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-ln94202-45-p2s3w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-45-p2s3w27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-14-p1s1">
  <m id="m-ln94208-14-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p1s1w1</w.rf>
   <form>Palestince</form>
   <lemma>Palestinec_;E</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94208-14-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p1s1w2</w.rf>
   <form>čekají</form>
   <lemma>čekat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94208-14-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p1s1w3</w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94208-14-p2s1">
  <m id="m-ln94208-14-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w1</w.rf>
   <form>Dosažení</form>
   <lemma>dosažení_^(*5áhnout)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w2</w.rf>
   <form>porozumění</form>
   <lemma>porozumění_^(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w3</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w4</w.rf>
   <form>Izraelem</form>
   <lemma>Izrael_;G</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w6</w.rf>
   <form>Organizací</form>
   <lemma>organizace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w7</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w8</w.rf>
   <form>osvobození</form>
   <lemma>osvobození_^(*4dit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w9</w.rf>
   <form>Palestiny</form>
   <lemma>Palestina_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w10</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-14-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w11</w.rf>
   <form>doprovázeno</form>
   <lemma>doprovázet_:T</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-ln94208-14-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w12</w.rf>
   <form>zveřejněním</form>
   <lemma>zveřejnění_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w13</w.rf>
   <form>úmyslů</form>
   <lemma>úmysl</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w14</w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w15</w.rf>
   <form>mezinárodních</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w16</w.rf>
   <form>organizací</form>
   <lemma>organizace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w18</w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w19</w.rf>
   <form>napomáhat</form>
   <lemma>napomáhat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w20</w.rf>
   <form>rozvoji</form>
   <lemma>rozvoj</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w21</w.rf>
   <form>hospodářství</form>
   <lemma>hospodářství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w22</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w23</w.rf>
   <form>územích</form>
   <lemma>území</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w25</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w26</w.rf>
   <form>nichž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P9XP6----------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w27</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-ln94208-14-p2s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w28</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w29</w.rf>
   <form>západním</form>
   <lemma>západní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w30</w.rf>
   <form>břehu</form>
   <lemma>břeh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w31</w.rf>
   <form>Jordánu</form>
   <lemma>Jordán-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w32</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w33</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-14-p2s1w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w34</w.rf>
   <form>Gaze</form>
   <lemma>Gaza_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w35</w.rf>
   <form>vykonávána</form>
   <lemma>vykonávat_:T_^(*4at)</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ln94208-14-p2s1w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w36</w.rf>
   <form>omezená</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w37</w.rf>
   <form>palestinská</form>
   <lemma>palestinský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w38</w.rf>
   <form>samospráva</form>
   <lemma>samospráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s1w39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s1w39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-14-p2s2">
  <m id="m-ln94208-14-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s2w1</w.rf>
   <form>Hovořilo</form>
   <lemma>hovořit_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-14-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s2w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94208-14-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s2w3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-14-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s2w4</w.rf>
   <form>hovoří</form>
   <lemma>hovořit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-14-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s2w5</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-14-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s2w6</w.rf>
   <form>miliardách</form>
   <lemma>miliarda`1000000000</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s2w7</w.rf>
   <form>dolarů</form>
   <lemma>dolar_;b</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p2s2w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-14-p3s1">
  <m id="m-ln94208-14-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w1</w.rf>
   <form>Jedna</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS1----------</tag>
  </m>
  <m id="m-ln94208-14-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w2</w.rf>
   <form>věc</form>
   <lemma>věc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94208-14-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w3</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94208-14-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w4</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-14-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w5</w.rf>
   <form>úmysly</form>
   <lemma>úmysl</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94208-14-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-14-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w7</w.rf>
   <form>sliby</form>
   <lemma>slib</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94208-14-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-14-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w9</w.rf>
   <form>druhá</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94208-14-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w10</w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-14-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w11</w.rf>
   <form>uvedení</form>
   <lemma>uvedení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94208-14-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w12</w.rf>
   <form>toku</form>
   <lemma>tok</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w13</w.rf>
   <form>peněz</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w14</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-14-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w15</w.rf>
   <form>pohybu</form>
   <lemma>pohyb</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-14-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-14-p3s1w16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-16-p1s1">
  <m id="m-ln94208-16-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p1s1w1</w.rf>
   <form>Krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
 </s>
 <s id="m-ln94208-16-p2s1">
  <m id="m-ln94208-16-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w1</w.rf>
   <form>Objem</form>
   <lemma>objem</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w2</w.rf>
   <form>dovozu</form>
   <lemma>dovoz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w3</w.rf>
   <form>ropy</form>
   <lemma>ropa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-16-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w5</w.rf>
   <form>USA</form>
   <lemma>USA_;G</lemma>
   <tag>NNIPX-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w6</w.rf>
   <form>dosáhl</form>
   <lemma>dosáhnout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-16-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w7</w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-16-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-16-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w9</w.rf>
   <form>červenci</form>
   <lemma>červenec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w10</w.rf>
   <form>nejvyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAFS2----3A----</tag>
  </m>
  <m id="m-ln94208-16-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w11</w.rf>
   <form>úrovně</form>
   <lemma>úroveň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w12</w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP2----------</tag>
  </m>
  <m id="m-ln94208-16-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w13</w.rf>
   <form>dob</form>
   <lemma>doba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s1w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-16-p2s2">
  <m id="m-ln94208-16-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s2w1</w.rf>
   <form>Průměrná</form>
   <lemma>průměrný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94208-16-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s2w2</w.rf>
   <form>hodnota</form>
   <lemma>hodnota</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s2w3</w.rf>
   <form>denního</form>
   <lemma>denní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94208-16-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s2w4</w.rf>
   <form>dovozu</form>
   <lemma>dovoz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s2w5</w.rf>
   <form>činila</form>
   <lemma>činit_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94208-16-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s2w6</w.rf>
   <form>10059</form>
   <lemma>10059</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-16-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s2w7</w.rf>
   <form>mil</form>
   <lemma>milión`1000000_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln94208-16-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s2w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-16-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s2w9</w.rf>
   <form>barelů</form>
   <lemma>barel</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s2w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-16-p2s3">
  <m id="m-ln94208-16-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w1</w.rf>
   <form>Dosavadní</form>
   <lemma>dosavadní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94208-16-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w2</w.rf>
   <form>měsíční</form>
   <lemma>měsíční</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94208-16-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w3</w.rf>
   <form>rekord</form>
   <lemma>rekord</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-16-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w5</w.rf>
   <form>dosažen</form>
   <lemma>dosáhnout</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ln94208-16-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-16-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w7</w.rf>
   <form>jaře</form>
   <lemma>jaro</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w8</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-ln94208-16-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w9</w.rf>
   <form>1977</form>
   <lemma>1977</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-16-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-16-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w11</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-16-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w12</w.rf>
   <form>USA</form>
   <lemma>USA_;G</lemma>
   <tag>NNIPX-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w13</w.rf>
   <form>denně</form>
   <lemma>denně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94208-16-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w14</w.rf>
   <form>dovážely</form>
   <lemma>dovážet_:T_^(z_ciziny)</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln94208-16-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w15</w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-16-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w16</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-16-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w17</w.rf>
   <form>mil</form>
   <lemma>milión`1000000_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln94208-16-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-16-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w19</w.rf>
   <form>barelů</form>
   <lemma>barel</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94208-16-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-16-p2s3w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-58-p1s1">
  <m id="m-ln94207-58-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p1s1w1</w.rf>
   <form>Součet</form>
   <lemma>součet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-58-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p1s1w2</w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-58-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p1s1w3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p1s1w4</w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94207-58-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p1s1w5</w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-ln94207-58-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p1s1w6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p1s1w7</w.rf>
   <form>ligy</form>
   <lemma>liga</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln94207-58-p2s5A">
  <m id="m-ln94207-58-p2s5Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Aw1</w.rf>
   <form>Penalty</form>
   <lemma>penalta</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94207-58-p2s5Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Aw2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Aw3</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Aw4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-58-p2s5B">
  <m id="m-ln94207-58-p2s5Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw1</w.rf>
   <form>Vrabec</form>
   <lemma>vrabec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw3</w.rf>
   <form>Žižkov</form>
   <lemma>Žižkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw6</w.rf>
   <form>Sokol</form>
   <lemma>Sokol-1_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw7</w.rf>
   <form>proměnili</form>
   <lemma>proměnit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw9</w.rf>
   <form>Pavlík</form>
   <lemma>Pavlík_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw10</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw11</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw12</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw14</w.rf>
   <form>Bielik</form>
   <lemma>Bielik_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw15</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw16</w.rf>
   <form>Cheb</form>
   <lemma>Cheb_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw17</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw18</w.rf>
   <form>neproměnili</form>
   <lemma>proměnit_:W</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-ln94207-58-p2s5Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s5Bw19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-58-p2s10">
  <m id="m-ln94207-58-p2s10w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s10w1</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-58-p2s10w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s10w2</w.rf>
   <form>šv</form>
   <lemma>šv-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94207-58-p2s10w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-58-p2s10w3</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95046-027-p1s1">
  <m id="m-ln95046-027-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p1s1w1</w.rf>
   <form>Smrt</form>
   <lemma>smrt</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95046-027-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p1s1w2</w.rf>
   <form>basketbalisty</form>
   <lemma>basketbalista</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln95046-027-p2s1A">
  <m id="m-ln95046-027-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Aw1</w.rf>
   <form>Fabriano</form>
   <lemma>Fabriano_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95046-027-p2s1B">
  <m id="m-ln95046-027-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw1</w.rf>
   <form>kysličníkem</form>
   <lemma>kysličník</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw2</w.rf>
   <form>uhelnatým</form>
   <lemma>uhelnatý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw3</w.rf>
   <form>unikajícím</form>
   <lemma>unikající_^(*4t)</lemma>
   <tag>AGIS7-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw5</w.rf>
   <form>ohřívače</form>
   <lemma>ohřívač</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw6</w.rf>
   <form>teplé</form>
   <lemma>teplý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw7</w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw9</w.rf>
   <form>zřejmě</form>
   <lemma>zřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw10</w.rf>
   <form>otrávil</form>
   <lemma>otrávit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw11</w.rf>
   <form>americký</form>
   <lemma>americký</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw12</w.rf>
   <form>basketbalista</form>
   <lemma>basketbalista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw13</w.rf>
   <form>Samuel</form>
   <lemma>Samuel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw14</w.rf>
   <form>Mitchell</form>
   <lemma>Mitchell_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw16</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw17</w.rf>
   <form>působil</form>
   <lemma>působit_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw19</w.rf>
   <form>druholigovém</form>
   <lemma>druholigový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw20</w.rf>
   <form>italském</form>
   <lemma>italský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw21</w.rf>
   <form>klubu</form>
   <lemma>klub</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw22</w.rf>
   <form>Fabriano</form>
   <lemma>Fabriano_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw23</w.rf>
   <form>Turboair</form>
   <lemma>Turboair_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Bw24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95046-027-p2s1C">
  <m id="m-ln95046-027-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Cw1</w.rf>
   <form>mrtvého</form>
   <lemma>mrtvý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Cw2</w.rf>
   <form>čtyřiadvacetiletého</form>
   <lemma>čtyřiadvacetiletý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Cw3</w.rf>
   <form>hráče</form>
   <lemma>hráč</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Cw4</w.rf>
   <form>našel</form>
   <lemma>najít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95046-027-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Cw5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95046-027-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Cw6</w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Cw7</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln95046-027-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Cw8</w.rf>
   <form>trenér</form>
   <lemma>trenér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95046-027-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95046-027-p2s1Cw9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-012-p1s1">
  <m id="m-ln95049-012-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p1s1w1</w.rf>
   <form>OP</form>
   <lemma>op</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95049-012-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p1s1w2</w.rf>
   <form>Prostějov</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95049-012-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p1s1w3</w.rf>
   <form>očekává</form>
   <lemma>očekávat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95049-012-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p1s1w4</w.rf>
   <form>zisk</form>
   <lemma>zisk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
 </s>
 <s id="m-ln95049-012-p2s1A">
  <m id="m-ln95049-012-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-012-p2s1B">
  <m id="m-ln95049-012-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw1</w.rf>
   <form>Hrubý</form>
   <lemma>hrubý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw2</w.rf>
   <form>zisk</form>
   <lemma>zisk</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw3</w.rf>
   <form>Oděvního</form>
   <lemma>oděvní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw4</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw5</w.rf>
   <form>Prostějov</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw6</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw7</w.rf>
   <form>loňský</form>
   <lemma>loňský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw8</w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw9</w.rf>
   <form>dosáhne</form>
   <lemma>dosáhnout</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw10</w.rf>
   <form>přibližně</form>
   <lemma>přibližně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw11</w.rf>
   <form>200</form>
   <lemma>200</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw12</w.rf>
   <form>miliónů</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw13</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw15</w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw16</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw17</w.rf>
   <form>předloni</form>
   <lemma>předloni</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-012-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s1Bw18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-012-p2s2">
  <m id="m-ln95049-012-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w1</w.rf>
   <form>Uvedl</form>
   <lemma>uvést</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95049-012-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-ln95049-012-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95049-012-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w4</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w5</w.rf>
   <form>generální</form>
   <lemma>generální</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln95049-012-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w6</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w7</w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w8</w.rf>
   <form>František</form>
   <lemma>František_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w9</w.rf>
   <form>Tuhý</form>
   <lemma>Tuhý_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-012-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w11</w.rf>
   <form>pražském</form>
   <lemma>pražský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln95049-012-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w12</w.rf>
   <form>veletrhu</form>
   <lemma>veletrh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w13</w.rf>
   <form>Elegance</form>
   <lemma>elegance</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-012-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p2s2w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-012-p3s1">
  <m id="m-ln95049-012-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w1</w.rf>
   <form>Obrat</form>
   <lemma>obrat-1_^(z_prodeje_zboží)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w2</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w3</w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w4</w.rf>
   <form>vzroste</form>
   <lemma>vzrůst</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95049-012-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w5</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95049-012-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w6</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln95049-012-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w7</w.rf>
   <form>slov</form>
   <lemma>slovo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w8</w.rf>
   <form>nejméně</form>
   <lemma>málo-3</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-ln95049-012-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w9</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95049-012-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w10</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w11</w.rf>
   <form>procent</form>
   <lemma>procento</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w13</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95049-012-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w14</w.rf>
   <form>loňských</form>
   <lemma>loňský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln95049-012-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w15</w.rf>
   <form>2.5</form>
   <form_change>num_normalization</form_change>
   <lemma>2.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w16</w.rf>
   <form>miliardy</form>
   <lemma>miliarda`1000000000</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w17</w.rf>
   <form>Kč</form>
   <lemma>Kč</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s1w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-012-p3s2">
  <m id="m-ln95049-012-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w1</w.rf>
   <form>Sedmdesát</form>
   <lemma>sedmdesát`70</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w2</w.rf>
   <form>procent</form>
   <lemma>procento</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w3</w.rf>
   <form>klasické</form>
   <lemma>klasický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w4</w.rf>
   <form>pánské</form>
   <lemma>pánský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w6</w.rf>
   <form>dámské</form>
   <lemma>dámský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w7</w.rf>
   <form>konfekce</form>
   <lemma>konfekce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w9</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w10</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95049-012-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w11</w.rf>
   <form>hlavním</form>
   <lemma>hlavní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w12</w.rf>
   <form>programem</form>
   <lemma>program-1</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w13</w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w15</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w16</w.rf>
   <form>vyváží</form>
   <lemma>vyvážet_:T_^(zboží_přes_hranice)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95049-012-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w18</w.rf>
   <form>zejména</form>
   <lemma>zejména</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w19</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w20</w.rf>
   <form>německy</form>
   <lemma>německy_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w21</w.rf>
   <form>mluvících</form>
   <lemma>mluvící_^(*3it)</lemma>
   <tag>AGFP2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w22</w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w24</w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w25</w.rf>
   <form>Británie</form>
   <lemma>Británie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95049-012-p3s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w27</w.rf>
   <form>Spojených</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w28</w.rf>
   <form>států</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95049-012-p3s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-012-p3s2w29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-143-p1s1">
  <m id="m-ln94208-143-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p1s1w1</w.rf>
   <form>Očekává</form>
   <lemma>očekávat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-143-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p1s1w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94208-143-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p1s1w3</w.rf>
   <form>vzestup</form>
   <lemma>vzestup</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-143-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p1s1w4</w.rf>
   <form>cen</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p1s1w5</w.rf>
   <form>cukru</form>
   <lemma>cukr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln94208-143-p2s1">
  <m id="m-ln94208-143-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-143-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w2</w.rf>
   <form>odhadu</form>
   <lemma>odhad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w3</w.rf>
   <form>britské</form>
   <lemma>britský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w4</w.rf>
   <form>obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w5</w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w6</w.rf>
   <form>E</form>
   <lemma>E-4_:B_;K</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-ln94208-143-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-143-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w8</w.rf>
   <form>D</form>
   <lemma>D-4_:B_;K</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-ln94208-143-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-143-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w10</w.rf>
   <form>and</form>
   <lemma>and-1_,t_^(obv._souč._anglických_názvů,_"a"</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-143-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w11</w.rf>
   <form>F</form>
   <lemma>F-4_:B_;K</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-ln94208-143-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-143-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w13</w.rf>
   <form>Man</form>
   <lemma>Man-1_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w14</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-ln94208-143-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w15</w.rf>
   <form>objem</form>
   <lemma>objem</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w16</w.rf>
   <form>letošní</form>
   <lemma>letošní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w17</w.rf>
   <form>produkce</form>
   <lemma>produkce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w18</w.rf>
   <form>cukru</form>
   <lemma>cukr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-143-p2s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w20</w.rf>
   <form>zemích</form>
   <lemma>země</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w21</w.rf>
   <form>EU</form>
   <lemma>EU-1_:B_;K_;p_^(Evropská_Unie)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94208-143-p2s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w22</w.rf>
   <form>nižší</form>
   <lemma>nízký</lemma>
   <tag>AAIS1----2A----</tag>
  </m>
  <m id="m-ln94208-143-p2s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w23</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94208-143-p2s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w24</w.rf>
   <form>loni</form>
   <lemma>vloni_,h</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-ln94208-143-p2s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s1w25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-143-p2s2">
  <m id="m-ln94208-143-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w1</w.rf>
   <form>Přesto</form>
   <lemma>přesto</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94208-143-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w2</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln94208-143-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94208-143-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w4</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-143-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w5</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln94208-143-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w6</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94208-143-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w7</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-143-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-143-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w9</w.rf>
   <form>prvním</form>
   <lemma>první</lemma>
   <tag>CrNS6----------</tag>
  </m>
  <m id="m-ln94208-143-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w10</w.rf>
   <form>čtvrtletí</form>
   <lemma>čtvrtletí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94208-143-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w11</w.rf>
   <form>příštího</form>
   <lemma>příští</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94208-143-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w12</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-ln94208-143-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w13</w.rf>
   <form>neměly</form>
   <lemma>mít</lemma>
   <tag>VpTP---XR-NA---</tag>
  </m>
  <m id="m-ln94208-143-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w14</w.rf>
   <form>zvyšovat</form>
   <lemma>zvyšovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94208-143-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p2s2w15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-143-p3s1">
  <m id="m-ln94208-143-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w1</w.rf>
   <form>Teprve</form>
   <lemma>teprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w2</w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94208-143-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w4</w.rf>
   <form>projeví</form>
   <lemma>projevit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-143-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w5</w.rf>
   <form>stoupající</form>
   <lemma>stoupající_^(*4t)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w6</w.rf>
   <form>poptávka</form>
   <lemma>poptávka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w7</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ln94208-143-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w8</w.rf>
   <form>strany</form>
   <lemma>strana-1_^(v_prostoru)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w9</w.rf>
   <form>Ruska</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w11</w.rf>
   <form>Číny</form>
   <lemma>Čína_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w13</w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PE--1----------</tag>
  </m>
  <m id="m-ln94208-143-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w14</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-ln94208-143-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w15</w.rf>
   <form>působit</form>
   <lemma>působit_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94208-143-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94208-143-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w17</w.rf>
   <form>vzestup</form>
   <lemma>vzestup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w18</w.rf>
   <form>cen</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s1w19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-143-p3s2">
  <m id="m-ln94208-143-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w1</w.rf>
   <form>Jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w2</w.rf>
   <form>pohyb</form>
   <lemma>pohyb</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w3</w.rf>
   <form>směrem</form>
   <lemma>směr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w4</w.rf>
   <form>vzhůru</form>
   <lemma>vzhůru</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w5</w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w6</w.rf>
   <form>podpoří</form>
   <lemma>podpořit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-143-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w7</w.rf>
   <form>nízká</form>
   <lemma>nízký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w8</w.rf>
   <form>úroveň</form>
   <lemma>úroveň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w9</w.rf>
   <form>sklizně</form>
   <lemma>sklizeň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w11</w.rf>
   <form>Kubě</form>
   <lemma>Kuba-2_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w12</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w14</w.rf>
   <form>samotných</form>
   <lemma>samotný</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w15</w.rf>
   <form>zemích</form>
   <lemma>země</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w16</w.rf>
   <form>EU</form>
   <lemma>EU-1_:B_;K_;p_^(Evropská_Unie)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94208-143-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w18</w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w19</w.rf>
   <form>očekávaných</form>
   <lemma>očekávaný_^(*2t)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w20</w.rf>
   <form>17.55</form>
   <lemma>17.55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w21</w.rf>
   <form>mil</form>
   <lemma>milión`1000000_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln94208-143-p3s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w23</w.rf>
   <form>tun</form>
   <lemma>tuna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w24</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w25</w.rf>
   <form>14.8</form>
   <lemma>14.8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-143-p3s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w26</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-143-p3s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-143-p3s2w27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-47-p1s1">
  <m id="m-ln94205-47-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p1s1w1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94205-47-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p1s1w2</w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94205-47-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p1s1w3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94205-47-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p1s1w4</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-ln94205-47-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p1s1w5</w.rf>
   <form>chodit</form>
   <lemma>chodit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-47-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p1s1w6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94205-47-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p1s1w7</w.rf>
   <form>poštu</form>
   <lemma>pošta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
 </s>
 <s id="m-ln94205-47-p2s1A">
  <m id="m-ln94205-47-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Aw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Aw3</w.rf>
   <form>teb</form>
   <lemma>teb-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94205-47-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Aw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Aw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-47-p2s1B">
  <m id="m-ln94205-47-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw2</w.rf>
   <form>poštách</form>
   <lemma>pošta</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw4</w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw5</w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw6</w.rf>
   <form>končí</form>
   <lemma>končit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw7</w.rf>
   <form>omezený</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw8</w.rf>
   <form>prázdninový</form>
   <lemma>prázdninový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw9</w.rf>
   <form>provoz</form>
   <lemma>provoz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw11</w.rf>
   <form>fronty</form>
   <lemma>fronta</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw12</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw13</w.rf>
   <form>poštovních</form>
   <lemma>poštovní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw14</w.rf>
   <form>přepážek</form>
   <lemma>přepážka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw17</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw18</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw19</w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw20</w.rf>
   <form>našich</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSXP2-P1-------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw21</w.rf>
   <form>čtenářů</form>
   <lemma>čtenář</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw22</w.rf>
   <form>stěžovalo</form>
   <lemma>stěžovat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw24</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw25</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw26</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw27</w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw28</w.rf>
   <form>zmenšit</form>
   <lemma>zmenšit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-47-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p2s1Bw29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-47-p3s1">
  <m id="m-ln94205-47-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w1</w.rf>
   <form>Průběh</form>
   <lemma>průběh</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w2</w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w3</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94205-47-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w4</w.rf>
   <form>front</form>
   <lemma>fronta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w5</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-47-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w6</w.rf>
   <form>ředitelství</form>
   <lemma>ředitelství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w7</w.rf>
   <form>pošt</form>
   <lemma>pošta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-47-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w9</w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w10</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-47-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w11</w.rf>
   <form>přislíbit</form>
   <lemma>přislíbit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w12</w.rf>
   <form>nemůže</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-ln94205-47-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-47-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w14</w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94205-47-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w15</w.rf>
   <form>pražská</form>
   <lemma>pražský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w16</w.rf>
   <form>pošta</form>
   <lemma>pošta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w17</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-47-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w18</w.rf>
   <form>značný</form>
   <lemma>značný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w19</w.rf>
   <form>nedostatek</form>
   <lemma>nedostatek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w20</w.rf>
   <form>personálu</form>
   <lemma>personál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s1w21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-47-p3s2">
  <m id="m-ln94205-47-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w1</w.rf>
   <form>Chybí</form>
   <lemma>chybět_:T_^(někde_něco_chybí)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-47-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w2</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94205-47-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w3</w.rf>
   <form>160</form>
   <lemma>160</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94205-47-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w4</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-47-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w6</w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94205-47-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w7</w.rf>
   <form>doručovatelů</form>
   <lemma>doručovatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-47-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w9</w.rf>
   <form>zaměstnanců</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w10</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94205-47-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w11</w.rf>
   <form>přepážek</form>
   <lemma>přepážka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94205-47-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-47-p3s2w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-69-p1s1">
  <m id="m-ln94207-69-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p1s1w1</w.rf>
   <form>Atentát</form>
   <lemma>atentát</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-69-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p1s1w2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-69-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p1s1w3</w.rf>
   <form>Babicích</form>
   <lemma>babice</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94207-69-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p1s1w4</w.rf>
   <form>mohl</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94207-69-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p1s1w5</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94207-69-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p1s1w6</w.rf>
   <form>záměrem</form>
   <lemma>záměr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94207-69-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p1s1w7</w.rf>
   <form>StB</form>
   <lemma>StB_:B_;K</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
 </s>
 <s id="m-ln94207-69-p2s1A">
  <m id="m-ln94207-69-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw1</w.rf>
   <form>Odbojová</form>
   <lemma>odbojový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw2</w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw3</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw4</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw5</w.rf>
   <form>počátku</form>
   <lemma>počátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw6</w.rf>
   <form>infiltrována</form>
   <lemma>infiltrovat_:T_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw8</w.rf>
   <form>StB</form>
   <lemma>StB_:B_;K</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw10</w.rf>
   <form>podílela</form>
   <lemma>podílet_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw12</w.rf>
   <form>jejích</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXP6FS3-------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Aw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Aw13</w.rf>
   <form>akcích</form>
   <lemma>akce</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
 </s>
 <s id="m-ln94207-69-p2s1B">
  <m id="m-ln94207-69-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Bw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Bw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Bw3</w.rf>
   <form>js</form>
   <lemma>js-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94207-69-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Bw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Bw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-69-p2s1C">
  <m id="m-ln94207-69-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw1</w.rf>
   <form>Úřad</form>
   <lemma>úřad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw2</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw3</w.rf>
   <form>dokumentaci</form>
   <lemma>dokumentace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw5</w.rf>
   <form>vyšetřování</form>
   <lemma>vyšetřování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw6</w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw7</w.rf>
   <form>StB</form>
   <lemma>StB_:B_;K</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw8</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw9</w.rf>
   <form>ÚDV</form>
   <lemma>ÚDV_:B_;K</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw10</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw12</w.rf>
   <form>pokouší</form>
   <lemma>pokoušet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw13</w.rf>
   <form>objasnit</form>
   <lemma>objasnit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw15</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw16</w.rf>
   <form>jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FS2----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw17</w.rf>
   <form>míry</form>
   <lemma>míra_^(měřítko,poměr)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw18</w.rf>
   <form>StB</form>
   <lemma>StB_:B_;K</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw19</w.rf>
   <form>řídila</form>
   <lemma>řídit_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw21</w.rf>
   <form>kontrolovala</form>
   <lemma>kontrolovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw22</w.rf>
   <form>odbojovou</form>
   <lemma>odbojový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw23</w.rf>
   <form>skupinu</form>
   <lemma>skupina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw25</w.rf>
   <form>Jihlavsku</form>
   <lemma>Jihlavsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw27</w.rf>
   <form>jejíž</form>
   <lemma>jenž_^(který...[ve_vedl._větě])</lemma>
   <tag>P1XP1FS3-------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw28</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw29</w.rf>
   <form>členové</form>
   <lemma>člen</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw30</w.rf>
   <form>zastřelili</form>
   <lemma>zastřelit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw31</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw32</w.rf>
   <form>červenci</form>
   <lemma>červenec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw33</w.rf>
   <form>1951</form>
   <lemma>1951</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw34</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw35</w.rf>
   <form>vsi</form>
   <lemma>ves</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw36</w.rf>
   <form>Babice</form>
   <lemma>Babice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw37</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw38</w.rf>
   <form>funkcionáře</form>
   <lemma>funkcionář</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw39</w.rf>
   <form>národního</form>
   <lemma>národní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw40">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw40</w.rf>
   <form>výboru</form>
   <lemma>výbor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw41">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw41</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw42">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw42</w.rf>
   <form>KSČ</form>
   <lemma>KSČ-1_:B_;K_^(Komunistická_strana_Československa)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94207-69-p2s1Cw43">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p2s1Cw43</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-69-p3s1">
  <m id="m-ln94207-69-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w1</w.rf>
   <form>Komunistický</form>
   <lemma>komunistický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94207-69-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w2</w.rf>
   <form>režim</form>
   <lemma>režim</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-69-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w3</w.rf>
   <form>prezentoval</form>
   <lemma>prezentovat_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94207-69-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w4</w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-ln94207-69-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w5</w.rf>
   <form>akci</form>
   <lemma>akce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94207-69-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w6</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94207-69-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w7</w.rf>
   <form>čin</form>
   <lemma>čin</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94207-69-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w8</w.rf>
   <form>řízený</form>
   <lemma>řízený_^(*4dit)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94207-69-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w9</w.rf>
   <form>agenty</form>
   <lemma>agent</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-ln94207-69-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w10</w.rf>
   <form>západních</form>
   <lemma>západní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94207-69-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w11</w.rf>
   <form>špionážních</form>
   <lemma>špionážní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94207-69-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w12</w.rf>
   <form>organizací</form>
   <lemma>organizace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-69-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s1w13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-69-p3s2">
  <m id="m-ln94207-69-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w1</w.rf>
   <form>Atentát</form>
   <lemma>atentát</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-69-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94207-69-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w3</w.rf>
   <form>stal</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94207-69-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w4</w.rf>
   <form>záminkou</form>
   <lemma>záminka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94207-69-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w5</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94207-69-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w6</w.rf>
   <form>represím</form>
   <lemma>represe</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-ln94207-69-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w7</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94207-69-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w8</w.rf>
   <form>místním</form>
   <lemma>místní</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m-ln94207-69-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w9</w.rf>
   <form>rolníkům</form>
   <lemma>rolník</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ln94207-69-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-69-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w11</w.rf>
   <form>katolické</form>
   <lemma>katolický</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ln94207-69-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w12</w.rf>
   <form>církvi</form>
   <lemma>církev</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94207-69-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-69-p3s2w13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-098-p1s1">
  <m id="m-mf920925-098-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p1s1w1</w.rf>
   <form>Výhry</form>
   <lemma>výhra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf920925-098-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p1s1w2</w.rf>
   <form>loterie</form>
   <lemma>loterie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-mf920925-098-p2s1">
  <m id="m-mf920925-098-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s1w1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s1w2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-098-p2s2A">
  <m id="m-mf920925-098-p2s2Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Aw1</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Aw2</w.rf>
   <form>Slosování</form>
   <lemma>slosování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Aw3</w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Aw4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Aw5</w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Aw6</w.rf>
   <form>1992</form>
   <lemma>1992</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Aw7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Aw8</w.rf>
   <form>Topoľčiankách</form>
   <form_change>spell</form_change>
   <lemma>Topoľčianky_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Aw9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Aw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Aw10</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-098-p2s2B">
  <m id="m-mf920925-098-p2s2Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw1</w.rf>
   <form>Prémie</form>
   <lemma>prémie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw2</w.rf>
   <form>1000000</form>
   <form_change>num_normalization</form_change>
   <lemma>1000000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw3</w.rf>
   <form>Kčs</form>
   <lemma>Kčs-1_:B_^(Koruna_čs.)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw4</w.rf>
   <form>připadá</form>
   <lemma>připadat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw6</w.rf>
   <form>los</form>
   <lemma>los-2_^(výherní)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw7</w.rf>
   <form>série</form>
   <lemma>série</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw9</w.rf>
   <form>číslo</form>
   <lemma>číslo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw11</w.rf>
   <form>K</form>
   <lemma>k-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw13</w.rf>
   <form>020</form>
   <lemma>020</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw14</w.rf>
   <form>611</form>
   <lemma>611</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Bw15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-098-p2s2C">
  <m id="m-mf920925-098-p2s2Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw1</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw2</w.rf>
   <form>výhry</form>
   <lemma>výhra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw4</w.rf>
   <form>100000</form>
   <form_change>num_normalization</form_change>
   <lemma>100000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw7</w.rf>
   <form>Kčs</form>
   <lemma>Kčs-1_:B_^(Koruna_čs.)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw8</w.rf>
   <form>připadají</form>
   <lemma>připadat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw10</w.rf>
   <form>losy</form>
   <lemma>los-2_^(výherní)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw11</w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw12</w.rf>
   <form>sérií</form>
   <lemma>série</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw14</w.rf>
   <form>čísel</form>
   <lemma>číslo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw15</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw16</w.rf>
   <form>B</form>
   <lemma>b-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw17</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw18</w.rf>
   <form>034</form>
   <lemma>034</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw19</w.rf>
   <form>185</form>
   <lemma>185</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw21</w.rf>
   <form>D</form>
   <lemma>d-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw22</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw23</w.rf>
   <form>068</form>
   <lemma>068</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw24</w.rf>
   <form>947</form>
   <lemma>947</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s2Cw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s2Cw25</w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-098-p2s3">
  <m id="m-mf920925-098-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w1</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w2</w.rf>
   <form>výhry</form>
   <lemma>výhra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w4</w.rf>
   <form>50000</form>
   <form_change>num_normalization</form_change>
   <lemma>50000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w5</w.rf>
   <form>Kčs</form>
   <lemma>Kčs-1_:B_^(Koruna_čs.)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-mf920925-098-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w6</w.rf>
   <form>připadají</form>
   <lemma>připadat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf920925-098-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w8</w.rf>
   <form>losy</form>
   <lemma>los-2_^(výherní)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w9</w.rf>
   <form>A</form>
   <lemma>a-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w11</w.rf>
   <form>055</form>
   <lemma>055</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w12</w.rf>
   <form>953</form>
   <lemma>953</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w14</w.rf>
   <form>A</form>
   <lemma>a-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w15</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w16</w.rf>
   <form>071</form>
   <lemma>071</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w17</w.rf>
   <form>728</form>
   <lemma>728</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w19</w.rf>
   <form>D</form>
   <lemma>d-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w21</w.rf>
   <form>011</form>
   <lemma>011</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w22</w.rf>
   <form>627</form>
   <lemma>627</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w24</w.rf>
   <form>K</form>
   <lemma>k-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w25</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w26</w.rf>
   <form>085</form>
   <lemma>085</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w27</w.rf>
   <form>329</form>
   <lemma>329</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s3w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s3w28</w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-098-p2s4">
  <m id="m-mf920925-098-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w1</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w2</w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-098-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w4</w.rf>
   <form>10000</form>
   <form_change>num_normalization</form_change>
   <lemma>10000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w5</w.rf>
   <form>Kčs</form>
   <lemma>Kčs-1_:B_^(Koruna_čs.)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-mf920925-098-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w6</w.rf>
   <form>připadá</form>
   <lemma>připadat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920925-098-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-mf920925-098-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w8</w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP6----------</tag>
  </m>
  <m id="m-mf920925-098-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w9</w.rf>
   <form>sériích</form>
   <lemma>série</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920925-098-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w11</w.rf>
   <form>číslo</form>
   <lemma>číslo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w12</w.rf>
   <form>losu</form>
   <lemma>los-2_^(výherní)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920925-098-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w13</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w14</w.rf>
   <form>53094</form>
   <form_change>num_normalization</form_change>
   <lemma>53094</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-098-p2s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-098-p2s4w15</w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930713-139-p1s1">
  <m id="m-mf930713-139-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p1s1w1</w.rf>
   <form>Divošské</form>
   <lemma>divošský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-mf930713-139-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p1s1w2</w.rf>
   <form>násilí</form>
   <lemma>násilí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930713-139-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p1s1w3</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf930713-139-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p1s1w4</w.rf>
   <form>Johannesburgu</form>
   <lemma>Johannesburg_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-mf930713-139-p2s1">
  <m id="m-mf930713-139-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w1</w.rf>
   <form>Nová</form>
   <lemma>nový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w2</w.rf>
   <form>vlna</form>
   <lemma>vlna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w3</w.rf>
   <form>násilí</form>
   <lemma>násilí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf930713-139-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w5</w.rf>
   <form>vyvalila</form>
   <lemma>vyvalit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930713-139-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w7</w.rf>
   <form>sídlištích</form>
   <lemma>sídliště</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w8</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf930713-139-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w9</w.rf>
   <form>Johannesburgu</form>
   <lemma>Johannesburg_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w10</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930713-139-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w11</w.rf>
   <form>minulém</form>
   <lemma>minulý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w12</w.rf>
   <form>pátku</form>
   <lemma>pátek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w14</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w15</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w16</w.rf>
   <form>vyhlášeno</form>
   <lemma>vyhlásit</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-mf930713-139-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w17</w.rf>
   <form>datum</form>
   <lemma>datum_^(kalendářní)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w18</w.rf>
   <form>voleb</form>
   <lemma>volba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s1w19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930713-139-p2s2">
  <m id="m-mf930713-139-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w1</w.rf>
   <form>Bezprostředním</form>
   <lemma>bezprostřední</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w2</w.rf>
   <form>důvodem</form>
   <lemma>důvod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w3</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w4</w.rf>
   <form>erupci</form>
   <lemma>erupce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w5</w.rf>
   <form>nových</form>
   <lemma>nový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w6</w.rf>
   <form>násilností</form>
   <lemma>násilnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w8</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w10</w.rf>
   <form>zdá</form>
   <lemma>zdát</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w12</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w13</w.rf>
   <form>přepadení</form>
   <lemma>přepadení_^(*3nout)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w14</w.rf>
   <form>pohřebního</form>
   <lemma>pohřební</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w15</w.rf>
   <form>průvodu</form>
   <lemma>průvod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w17</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w18</w.rf>
   <form>míjel</form>
   <lemma>míjet_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w20</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w21</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w23</w.rf>
   <form>července</form>
   <lemma>červenec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w24</w.rf>
   <form>ubytovnu</form>
   <lemma>ubytovna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w26</w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w27</w.rf>
   <form>žili</form>
   <lemma>žít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w28</w.rf>
   <form>převážně</form>
   <lemma>převážně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w29</w.rf>
   <form>členové</form>
   <lemma>člen</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w30</w.rf>
   <form>Svobodné</form>
   <lemma>svobodný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w31</w.rf>
   <form>strany</form>
   <lemma>strana-2_^(politická)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w32</w.rf>
   <form>Inkatha</form>
   <lemma>Inkatha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s2w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s2w33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930713-139-p2s3">
  <m id="m-mf930713-139-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w1</w.rf>
   <form>Politické</form>
   <lemma>politický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w2</w.rf>
   <form>napětí</form>
   <lemma>napětí_^(elektrické,_mechanické,_ve_vztazích)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w3</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w4</w.rf>
   <form>volbami</form>
   <lemma>volba</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w6</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w8</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w9</w.rf>
   <form>konat</form>
   <lemma>konat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w10</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w12</w.rf>
   <form>dubnu</form>
   <lemma>duben</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w13</w.rf>
   <form>příštího</form>
   <lemma>příští</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w14</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-mf930713-139-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w16</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w17</w.rf>
   <form>začíná</form>
   <lemma>začínat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w18</w.rf>
   <form>stupňovat</form>
   <lemma>stupňovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w19</w.rf>
   <form>už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w20</w.rf>
   <form>nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w22</w.rf>
   <form>nabývá</form>
   <lemma>nabývat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w23</w.rf>
   <form>postupně</form>
   <lemma>postupně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w24</w.rf>
   <form>takového</form>
   <lemma>takový</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w25</w.rf>
   <form>rozměru</form>
   <lemma>rozměr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w27</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w28</w.rf>
   <form>stačí</form>
   <lemma>stačit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s3w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w29</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w30</w.rf>
   <form>jiskra</form>
   <lemma>jiskra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w31</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w32</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w34</w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-mf930713-139-p2s3w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w35</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-mf930713-139-p2s3w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w36</w.rf>
   <form>velkému</form>
   <lemma>velký</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w37</w.rf>
   <form>celonárodnímu</form>
   <lemma>celonárodní</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w38</w.rf>
   <form>požáru</form>
   <lemma>požár</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-mf930713-139-p2s3w39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-139-p2s3w39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
