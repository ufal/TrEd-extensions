<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="sample8.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94207-76-p1s1">
  <m id="m-ln94207-76-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p1s1w1</w.rf>
   <form>Sic</form>
   <lemma>sic_,t</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-76-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p1s1w2</w.rf>
   <form>transit</form>
   <lemma>transit_,t</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94207-76-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p1s1w3</w.rf>
   <form>gloria</form>
   <lemma>gloria_,t</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-76-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p1s1w4</w.rf>
   <form>mundi</form>
   <lemma>mundi_,t</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p1s1w5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p1s1w6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p1s1w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-76-p2s1A">
  <m id="m-ln94207-76-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw2</w.rf>
   <form>pamětí</form>
   <lemma>paměť</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw3</w.rf>
   <form>Ladislava</form>
   <lemma>Ladislav_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw4</w.rf>
   <form>Fukse</form>
   <lemma>Fuks_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw5</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw6</w.rf>
   <form>+</form>
   <lemma>+</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw7</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw9</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw11</w.rf>
   <form>1994</form>
   <lemma>1994</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s1Aw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Aw12</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-76-p2s1B">
  <m id="m-ln94207-76-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Bw1</w.rf>
   <form>Rusko</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94207-76-p2s1C">
  <m id="m-ln94207-76-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Cw1</w.rf>
   <form>Hřbitov</form>
   <lemma>hřbitov</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Cw2</w.rf>
   <form>Novoděvičí</form>
   <lemma>Novoděvičí_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Cw3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94207-76-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Cw4</w.rf>
   <form>památný</form>
   <lemma>památný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94207-76-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s1Cw5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-76-p2s2">
  <m id="m-ln94207-76-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w1</w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94207-76-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w2</w.rf>
   <form>tu</form>
   <lemma>tady</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-ln94207-76-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w3</w.rf>
   <form>pohřbeny</form>
   <lemma>pohřbít</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-ln94207-76-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w4</w.rf>
   <form>významné</form>
   <lemma>významný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln94207-76-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w5</w.rf>
   <form>osobnosti</form>
   <lemma>osobnost</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w6</w.rf>
   <form>zvláště</form>
   <lemma>zvláště</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-76-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w8</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w10</w.rf>
   <form>století</form>
   <lemma>století</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s2w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-76-p2s3">
  <m id="m-ln94207-76-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w2</w.rf>
   <form>právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w3</w.rf>
   <form>zde</form>
   <lemma>zde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w5</w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w6</w.rf>
   <form>hřbitově</form>
   <lemma>hřbitov</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w7</w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-ln94207-76-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w8</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94207-76-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w9</w.rf>
   <form>svědky</form>
   <lemma>svědek</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w10</w.rf>
   <form>něčeho</form>
   <lemma>něco</lemma>
   <tag>PZ--2----------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w11</w.rf>
   <form>nečekaného</form>
   <lemma>čekaný_^(*2t)</lemma>
   <tag>AANS2----1N----</tag>
  </m>
  <m id="m-ln94207-76-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w13</w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_př.:_o_těch,_co_odešli/co_je_znal)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w14</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w15</w.rf>
   <form>zapsalo</form>
   <lemma>zapsat</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94207-76-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w16</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w17</w.rf>
   <form>našeho</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSZS2-P1-------</tag>
  </m>
  <m id="m-ln94207-76-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w18</w.rf>
   <form>vědomí</form>
   <lemma>vědomí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s3w19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-76-p2s4">
  <m id="m-ln94207-76-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w1</w.rf>
   <form>Průvodkyně</form>
   <lemma>průvodkyně_^(*4ce)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w2</w.rf>
   <form>nás</form>
   <lemma>já</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m-ln94207-76-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w3</w.rf>
   <form>zavedla</form>
   <lemma>zavést</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94207-76-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w4</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94207-76-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w5</w.rf>
   <form>hrobu</form>
   <lemma>hrob</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w6</w.rf>
   <form>Nikity</form>
   <lemma>Nikita_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w7</w.rf>
   <form>Sergejeviče</form>
   <lemma>Sergejevič_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w8</w.rf>
   <form>Chruščova</form>
   <lemma>Chruščov_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w10</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94207-76-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w11</w.rf>
   <form>vystřídal</form>
   <lemma>vystřídat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94207-76-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w12</w.rf>
   <form>Stalina</form>
   <lemma>Stalin_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w14</w.rf>
   <form>přispěl</form>
   <lemma>přispět</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94207-76-p2s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w15</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94207-76-p2s4w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w16</w.rf>
   <form>odeznění</form>
   <lemma>odeznění_^(*3ít)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s4w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w17</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln94207-76-p2s4w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w18</w.rf>
   <form>kultu</form>
   <lemma>kult</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s4w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s4w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w20</w.rf>
   <form>oddechu</form>
   <lemma>oddech</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s4w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w21</w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s4w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s4w22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-76-p2s5">
  <m id="m-ln94207-76-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w1</w.rf>
   <form>Chruščov</form>
   <lemma>Chruščov_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w2</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ln94207-76-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w3</w.rf>
   <form>pohřben</form>
   <lemma>pohřbít</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ln94207-76-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w4</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-76-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w5</w.rf>
   <form>kremelské</form>
   <lemma>kremelský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94207-76-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w6</w.rf>
   <form>zdi</form>
   <lemma>zeď</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w8</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w9</w.rf>
   <form>zde</form>
   <lemma>zde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s5w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s5w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s5w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w12</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln94207-76-p2s5w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w13</w.rf>
   <form>hrob</form>
   <lemma>hrob</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s5w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w14</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94207-76-p2s5w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w15</w.rf>
   <form>hrobem</form>
   <lemma>hrob</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94207-76-p2s5w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w16</w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s5w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w17</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-76-p2s5w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w18</w.rf>
   <form>nedal</form>
   <lemma>dát</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ln94207-76-p2s5w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w19</w.rf>
   <form>nazvat</form>
   <lemma>nazvat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94207-76-p2s5w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-76-p2s5w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-42-p1s1">
  <m id="m-ln94206-42-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p1s1w1</w.rf>
   <form>Důchody</form>
   <lemma>důchod</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94206-42-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p1s1w2</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94206-42-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p1s1w3</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94206-42-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p1s1w4</w.rf>
   <form>zvýšeny</form>
   <lemma>zvýšit</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
 </s>
 <s id="m-ln94206-42-p2s1A">
  <m id="m-ln94206-42-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Aw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-42-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Aw3</w.rf>
   <form>ika</form>
   <lemma>ika-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94206-42-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Aw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-42-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Aw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-42-p2s1B">
  <m id="m-ln94206-42-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw1</w.rf>
   <form>Vláda</form>
   <lemma>vláda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw2</w.rf>
   <form>navrhuje</form>
   <lemma>navrhovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw3</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw4</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw6</w.rf>
   <form>října</form>
   <lemma>říjen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw7</w.rf>
   <form>zvýšení</form>
   <lemma>zvýšení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw8</w.rf>
   <form>státního</form>
   <lemma>státní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw9</w.rf>
   <form>vyrovnávacího</form>
   <lemma>vyrovnávací_^(*5at)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw10</w.rf>
   <form>příspěvku</form>
   <lemma>příspěvek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw11</w.rf>
   <form>nezaopatřeným</form>
   <lemma>zaopatřený_^(*3it)</lemma>
   <tag>AAFP3----1N----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw12</w.rf>
   <form>dětem</form>
   <lemma>dítě</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw14</w.rf>
   <form>některých</form>
   <lemma>některý</lemma>
   <tag>PZXP2----------</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw15</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw16</w.rf>
   <form>sociálních</form>
   <lemma>sociální</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw17</w.rf>
   <form>dávek</form>
   <lemma>dávka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s1Bw18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-42-p2s2">
  <m id="m-ln94206-42-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w1</w.rf>
   <form>Návrh</form>
   <lemma>návrh</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w2</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-42-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w4</w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m-ln94206-42-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94206-42-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w6</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-42-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w7</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94206-42-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w8</w.rf>
   <form>stát</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-42-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w10</w.rf>
   <form>doporučil</form>
   <lemma>doporučit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94206-42-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w11</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-42-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w12</w.rf>
   <form>Poslanecké</form>
   <lemma>poslanecký</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w13</w.rf>
   <form>sněmovně</form>
   <lemma>sněmovna</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94206-42-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w15</w.rf>
   <form>přijetí</form>
   <lemma>přijetí-2_^(např._návrh)_(*5mout-2)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w16</w.rf>
   <form>parlamentní</form>
   <lemma>parlamentní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w17</w.rf>
   <form>výbor</form>
   <lemma>výbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w18</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94206-42-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w19</w.rf>
   <form>sociální</form>
   <lemma>sociální</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w20</w.rf>
   <form>politiku</form>
   <lemma>politika_^(věda)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94206-42-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w22</w.rf>
   <form>zdravotnictví</form>
   <lemma>zdravotnictví</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94206-42-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p2s2w23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-42-p3s1">
  <m id="m-ln94206-42-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w2</w.rf>
   <form>předlohy</form>
   <lemma>předloha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w3</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w5</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94206-42-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w6</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w7</w.rf>
   <form>zvýšit</form>
   <lemma>zvýšit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w8</w.rf>
   <form>státní</form>
   <lemma>státní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w9</w.rf>
   <form>vyrovnávací</form>
   <lemma>vyrovnávací_^(*5at)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w10</w.rf>
   <form>příspěvek</form>
   <lemma>příspěvek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w12</w.rf>
   <form>SVP</form>
   <lemma>SVP-2_:B_^(státní_vyrovnávací_příspěvek)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln94206-42-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w13</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w14</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w15</w.rf>
   <form>děti</form>
   <lemma>dítě</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w16</w.rf>
   <form>žijící</form>
   <lemma>žijící_^(*5ít)</lemma>
   <tag>AGFP4-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w18</w.rf>
   <form>rodině</form>
   <lemma>rodina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w19</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w20</w.rf>
   <form>příjmem</form>
   <lemma>příjem</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w21</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w22</w.rf>
   <form>1.5</form>
   <form_change>num_normalization</form_change>
   <lemma>1.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w23</w.rf>
   <form>násobku</form>
   <lemma>násobek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w24</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w25</w.rf>
   <form>minima</form>
   <lemma>minimum</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w26</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w27</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w28</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w29</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w30</w.rf>
   <form>částku</form>
   <lemma>částka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w31</w.rf>
   <form>320</form>
   <lemma>320</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94206-42-p3s1w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w32</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w33</w.rf>
   <form>měsíčně</form>
   <lemma>měsíčně_^(arch.;_př._měsíčná_noc)_(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94206-42-p3s1w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-42-p3s1w34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-051-p2s1">
  <m id="m-cmpr9415-051-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p2s1w1</w.rf>
   <form>Sen</form>
   <lemma>sen</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p2s1w2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9415-051-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p2s1w3</w.rf>
   <form>Švýcarsku</form>
   <lemma>Švýcarsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p2s1w4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9415-051-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p2s1w5</w.rf>
   <form>rozplývá</form>
   <lemma>rozplývat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
 </s>
 <s id="m-cmpr9415-051-p3s1">
  <m id="m-cmpr9415-051-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9415-051-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w2</w.rf>
   <form>Slovensku</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w3</w.rf>
   <form>chybí</form>
   <lemma>chybět_:T_^(někde_něco_chybí)</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-cmpr9415-051-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w4</w.rf>
   <form>stimulující</form>
   <lemma>stimulující_^(*5ovat)</lemma>
   <tag>AGIP1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w5</w.rf>
   <form>faktory</form>
   <lemma>faktor</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w7</w.rf>
   <form>investice</form>
   <lemma>investice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w8</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9415-051-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w9</w.rf>
   <form>rozvoj</form>
   <lemma>rozvoj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w10</w.rf>
   <form>cestovního</form>
   <lemma>cestovní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p3s1w11</w.rf>
   <form>ruchu</form>
   <lemma>ruch</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-cmpr9415-051-p4s1">
  <m id="m-cmpr9415-051-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w1</w.rf>
   <form>Rozlohou</form>
   <lemma>rozloha</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w2</w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w4</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w6</w.rf>
   <form>přírodní</form>
   <lemma>přírodní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w7</w.rf>
   <form>krásy</form>
   <lemma>krása</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w9</w.rf>
   <form>kulturní</form>
   <lemma>kulturní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w11</w.rf>
   <form>historické</form>
   <lemma>historický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w12</w.rf>
   <form>památky</form>
   <lemma>památka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w13</w.rf>
   <form>bohaté</form>
   <lemma>bohatý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w14</w.rf>
   <form>Slovensko</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w16</w.rf>
   <form>láká</form>
   <lemma>lákat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w17</w.rf>
   <form>každoročně</form>
   <lemma>každoročně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w18</w.rf>
   <form>statisíce</form>
   <lemma>stotisíc`100000</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w19</w.rf>
   <form>zahraničních</form>
   <lemma>zahraniční</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w20</w.rf>
   <form>turistů</form>
   <lemma>turista</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s1w21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-051-p4s2">
  <m id="m-cmpr9415-051-p4s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w1</w.rf>
   <form>Zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w2</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w3</w.rf>
   <form>světě</form>
   <lemma>svět</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w4</w.rf>
   <form>méně</form>
   <lemma>málo-3</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w5</w.rf>
   <form>známá</form>
   <lemma>známý-2_^(co_[ne]známe)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w6</w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w7</w.rf>
   <form>chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w8</w.rf>
   <form>svými</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8XP7----------</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w9</w.rf>
   <form>krásami</form>
   <lemma>krása</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w10</w.rf>
   <form>přitahovat</form>
   <form_change>spell</form_change>
   <lemma>přitahovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w11</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w12</w.rf>
   <form>návštěvníky</form>
   <lemma>návštěvník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p4s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p4s2w13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-051-p5s1">
  <m id="m-cmpr9415-051-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w1</w.rf>
   <form>Rozvoj</form>
   <lemma>rozvoj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w2</w.rf>
   <form>cestovního</form>
   <lemma>cestovní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w3</w.rf>
   <form>ruchu</form>
   <lemma>ruch</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w5</w.rf>
   <form>stal</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-cmpr9415-051-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w6</w.rf>
   <form>aktuálním</form>
   <lemma>aktuální</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w7</w.rf>
   <form>zejména</form>
   <lemma>zejména</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w8</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w9</w.rf>
   <form>listopadu</form>
   <lemma>listopad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w10</w.rf>
   <form>1989</form>
   <lemma>1989</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s1w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-051-p5s2">
  <m id="m-cmpr9415-051-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w1</w.rf>
   <form>Otevření</form>
   <lemma>otevření_^(*3ít)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w3</w.rf>
   <form>světu</form>
   <lemma>svět</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w4</w.rf>
   <form>našlo</form>
   <lemma>najít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w5</w.rf>
   <form>odezvu</form>
   <lemma>odezva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w7</w.rf>
   <form>růstu</form>
   <lemma>růst-1</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w8</w.rf>
   <form>návštěvnosti</form>
   <lemma>návštěvnost</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w9</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w10</w.rf>
   <form>západních</form>
   <lemma>západní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w11</w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w13</w.rf>
   <form>statistiky</form>
   <lemma>statistika_^(věda)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w14</w.rf>
   <form>nepřinášejí</form>
   <lemma>přinášet_:T</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w15</w.rf>
   <form>údaje</form>
   <lemma>údaj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w17</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w18</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w19</w.rf>
   <form>potěšily</form>
   <lemma>potěšit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-cmpr9415-051-p5s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s2w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-051-p5s3">
  <m id="m-cmpr9415-051-p5s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w1</w.rf>
   <form>Slovensko</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w2</w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-cmpr9415-051-p5s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w3</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w4</w.rf>
   <form>turisty</form>
   <lemma>turista</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w5</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w6</w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w8</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w10</w.rf>
   <form>předpokládalo</form>
   <lemma>předpokládat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-cmpr9415-051-p5s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s3w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-051-p5s4">
  <m id="m-cmpr9415-051-p5s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s4w1</w.rf>
   <form>Sen</form>
   <lemma>sen</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s4w2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s4w3</w.rf>
   <form>malém</form>
   <lemma>malý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s4w4</w.rf>
   <form>Švýcarsku</form>
   <lemma>Švýcarsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-cmpr9415-051-p5s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s4w5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9415-051-p5s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s4w6</w.rf>
   <form>rozplývá</form>
   <lemma>rozplývat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9415-051-p5s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-051-p5s4w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-137-p1s1">
  <m id="m-ln94202-137-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p1s1w1</w.rf>
   <form>Podnikatelská</form>
   <lemma>podnikatelský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94202-137-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p1s1w2</w.rf>
   <form>banka</form>
   <lemma>banka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-137-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p1s1w3</w.rf>
   <form>nabírá</form>
   <lemma>nabírat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-137-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p1s1w4</w.rf>
   <form>dech</form>
   <lemma>dech</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
 </s>
 <s id="m-ln94202-137-p2s1A">
  <m id="m-ln94202-137-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Aw1</w.rf>
   <form>Mimořádná</form>
   <lemma>mimořádný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Aw2</w.rf>
   <form>valná</form>
   <lemma>valný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Aw3</w.rf>
   <form>hromada</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Aw4</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-ln94202-137-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Aw5</w.rf>
   <form>rozhodovat</form>
   <lemma>rozhodovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Aw6</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-137-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Aw7</w.rf>
   <form>zvýšení</form>
   <lemma>zvýšení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Aw8</w.rf>
   <form>základního</form>
   <lemma>základní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Aw9</w.rf>
   <form>jmění</form>
   <lemma>jmění</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln94202-137-p2s1B">
  <m id="m-ln94202-137-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Bw1</w.rf>
   <form>Ivana</form>
   <lemma>Ivana_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Bw2</w.rf>
   <form>Krčálová</form>
   <lemma>Krčálová_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94202-137-p2s1C">
  <m id="m-ln94202-137-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw1</w.rf>
   <form>Mimořádná</form>
   <lemma>mimořádný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw2</w.rf>
   <form>valná</form>
   <lemma>valný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw3</w.rf>
   <form>hromada</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw4</w.rf>
   <form>Podnikatelské</form>
   <lemma>podnikatelský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw5</w.rf>
   <form>banky</form>
   <lemma>banka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw7</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw9</w.rf>
   <form>konala</form>
   <lemma>konat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw10</w.rf>
   <form>minulý</form>
   <lemma>minulý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw11</w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw13</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw14</w.rf>
   <form>přerušena</form>
   <lemma>přerušit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ln94202-137-p2s1Cw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s1Cw15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-137-p2s2">
  <m id="m-ln94202-137-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w1</w.rf>
   <form>Důvodem</form>
   <lemma>důvod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w2</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-137-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w3</w.rf>
   <form>návrh</form>
   <lemma>návrh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w4</w.rf>
   <form>generálního</form>
   <lemma>generální</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln94202-137-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w5</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w6</w.rf>
   <form>banky</form>
   <lemma>banka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w7</w.rf>
   <form>zvýšit</form>
   <lemma>zvýšit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94202-137-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w8</w.rf>
   <form>základní</form>
   <lemma>základní_,s</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94202-137-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w9</w.rf>
   <form>jmění</form>
   <lemma>jmění</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w10</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94202-137-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w11</w.rf>
   <form>150</form>
   <lemma>150</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94202-137-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w12</w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94202-137-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w13</w.rf>
   <form>300</form>
   <lemma>300</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94202-137-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w14</w.rf>
   <form>milionů</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w15</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p2s2w16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-137-p3s1">
  <m id="m-ln94202-137-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w1</w.rf>
   <form>Chceme</form>
   <lemma>chtít</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-ln94202-137-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w2</w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w3</w.rf>
   <form>banku</form>
   <lemma>banka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w4</w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w6</w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w7</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w8</w.rf>
   <form>svého</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w9</w.rf>
   <form>jména</form>
   <lemma>jméno</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w11</w.rf>
   <form>záměru</form>
   <lemma>záměr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w12</w.rf>
   <form>zakladatelů</form>
   <lemma>zakladatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w13</w.rf>
   <form>patří</form>
   <lemma>patřit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-137-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w15</w.rf>
   <form>říká</form>
   <lemma>říkat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-137-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w16</w.rf>
   <form>generální</form>
   <lemma>generální</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w17</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w18</w.rf>
   <form>Podnikatelské</form>
   <lemma>podnikatelský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w19</w.rf>
   <form>banky</form>
   <lemma>banka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w20</w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w21</w.rf>
   <form>Fantík</form>
   <lemma>Fantík_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w23</w.rf>
   <form>dodává</form>
   <lemma>dodávat_:T_^(*4at)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-137-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w25</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w26</w.rf>
   <form>jejím</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSZS7FS3-------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w27</w.rf>
   <form>základním</form>
   <lemma>základní</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w28</w.rf>
   <form>posláním</form>
   <lemma>poslání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w29</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-137-p3s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w30</w.rf>
   <form>poskytovat</form>
   <lemma>poskytovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w31</w.rf>
   <form>univerzální</form>
   <lemma>univerzální</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w32</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w33</w.rf>
   <form>především</form>
   <lemma>především</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-137-p3s1w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w34</w.rf>
   <form>středním</form>
   <lemma>střední</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w35</w.rf>
   <form>podnikatelům</form>
   <lemma>podnikatel</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ln94202-137-p3s1w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p3s1w36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-137-p4s1">
  <m id="m-ln94202-137-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w1</w.rf>
   <form>Jedním</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS7----------</tag>
  </m>
  <m id="m-ln94202-137-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-137-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w3</w.rf>
   <form>předpokladů</form>
   <lemma>předpoklad</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-137-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w5</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-137-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w6</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln94202-137-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w7</w.rf>
   <form>slov</form>
   <lemma>slovo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94202-137-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w8</w.rf>
   <form>právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-137-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w9</w.rf>
   <form>dostatečné</form>
   <lemma>dostatečný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94202-137-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w10</w.rf>
   <form>kapitálové</form>
   <lemma>kapitálový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94202-137-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w11</w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94202-137-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-137-p4s1w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94203-27-p1s1">
  <m id="m-ln94203-27-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p1s1w1</w.rf>
   <form>Krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
 </s>
 <s id="m-ln94203-27-p2s1">
  <m id="m-ln94203-27-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w1</w.rf>
   <form>Osmnáctiměsíční</form>
   <lemma>osmnáctiměsíční</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w2</w.rf>
   <form>bosenské</form>
   <lemma>bosenský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w3</w.rf>
   <form>děvčátko</form>
   <lemma>děvčátko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w4</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94203-27-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w5</w.rf>
   <form>maminkou</form>
   <lemma>maminka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w6</w.rf>
   <form>přicestovalo</form>
   <lemma>přicestovat_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94203-27-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94203-27-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w8</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w9</w.rf>
   <form>vojenským</form>
   <lemma>vojenský</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w10</w.rf>
   <form>letadlem</form>
   <lemma>letadlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94203-27-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w12</w.rf>
   <form>italské</form>
   <lemma>italský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w13</w.rf>
   <form>Ancony</form>
   <lemma>Ancona_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w14</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94203-27-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w15</w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94203-27-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w17</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94203-27-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w19</w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>PHZS3--3-------</tag>
  </m>
  <m id="m-ln94203-27-p2s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w20</w.rf>
   <form>lékaři</form>
   <lemma>lékař</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w21</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94203-27-p2s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w22</w.rf>
   <form>Fakultní</form>
   <lemma>fakultní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w23</w.rf>
   <form>nemocnici</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94203-27-p2s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w25</w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w26</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94203-27-p2s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w27</w.rf>
   <form>Motole</form>
   <lemma>Motol_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w28</w.rf>
   <form>poskytli</form>
   <lemma>poskytnout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-ln94203-27-p2s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w29</w.rf>
   <form>potřebnou</form>
   <lemma>potřebný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w30</w.rf>
   <form>zdravotnickou</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w31</w.rf>
   <form>péči</form>
   <lemma>péče</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94203-27-p2s1w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p2s1w32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94203-27-p3s1">
  <m id="m-ln94203-27-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w1</w.rf>
   <form>Nová</form>
   <lemma>nový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94203-27-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w2</w.rf>
   <form>střední</form>
   <lemma>střední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94203-27-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w3</w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94203-27-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94203-27-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w5</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln94203-27-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w6</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-ln94203-27-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w7</w.rf>
   <form>vychovávat</form>
   <lemma>vychovávat_:T_^(*4at)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94203-27-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w8</w.rf>
   <form>manažery</form>
   <lemma>manažer</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94203-27-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94203-27-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w10</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94203-27-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w11</w.rf>
   <form>dopravy</form>
   <lemma>doprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94203-27-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w13</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94203-27-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w14</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94203-27-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w15</w.rf>
   <form>otevřena</form>
   <lemma>otevřít</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ln94203-27-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94203-27-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w17</w.rf>
   <form>Hrádku</form>
   <lemma>hrádek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94203-27-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w18</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94203-27-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w19</w.rf>
   <form>Nisou</form>
   <lemma>Nisa_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94203-27-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94203-27-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w21</w.rf>
   <form>Liberecku</form>
   <lemma>Liberecko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94203-27-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s1w22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94203-27-p3s2">
  <m id="m-ln94203-27-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s2w1</w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94203-27-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s2w2</w.rf>
   <form>prvního</form>
   <lemma>první</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m-ln94203-27-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s2w3</w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s2w4</w.rf>
   <form>nastoupí</form>
   <lemma>nastoupit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94203-27-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s2w5</w.rf>
   <form>třicet</form>
   <lemma>třicet`30</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-ln94203-27-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s2w6</w.rf>
   <form>studentů</form>
   <lemma>student</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p3s2w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94203-27-p4s1">
  <m id="m-ln94203-27-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s1w1</w.rf>
   <form>Časopis</form>
   <lemma>časopis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94203-27-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s1w2</w.rf>
   <form>Kinorevue</form>
   <lemma>Kinorevue_;R</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-ln94203-27-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s1w3</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-ln94203-27-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s1w4</w.rf>
   <form>připomíná</form>
   <lemma>připomínat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94203-27-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s1w5</w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94203-27-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s1w6</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s1w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94203-27-p4s2">
  <m id="m-ln94203-27-p4s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94203-27-p4s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w2</w.rf>
   <form>obálce</form>
   <lemma>obálka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94203-27-p4s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w3</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln94203-27-p4s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w4</w.rf>
   <form>prvního</form>
   <lemma>první</lemma>
   <tag>CrNS2----------</tag>
  </m>
  <m id="m-ln94203-27-p4s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w5</w.rf>
   <form>čísla</form>
   <lemma>číslo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p4s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94203-27-p4s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w7</w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94203-27-p4s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94203-27-p4s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w9</w.rf>
   <form>srpna</form>
   <lemma>srpen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p4s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w10</w.rf>
   <form>1934</form>
   <lemma>1934</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94203-27-p4s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w11</w.rf>
   <form>objevila</form>
   <lemma>objevit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94203-27-p4s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w12</w.rf>
   <form>tvář</form>
   <lemma>tvář</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94203-27-p4s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w13</w.rf>
   <form>populární</form>
   <lemma>populární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94203-27-p4s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w14</w.rf>
   <form>české</form>
   <lemma>český</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94203-27-p4s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w15</w.rf>
   <form>herečky</form>
   <lemma>herečka_^(^FM*3c)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p4s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w16</w.rf>
   <form>Antonie</form>
   <lemma>Antonie_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p4s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w17</w.rf>
   <form>Nedošínské</form>
   <lemma>Nedošínská_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94203-27-p4s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94203-27-p4s2w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-101-p1s1">
  <m id="m-mf930709-101-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p1s1w1</w.rf>
   <form>Křehké</form>
   <lemma>křehký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-mf930709-101-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p1s1w2</w.rf>
   <form>lodě</form>
   <lemma>loď</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf930709-101-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p1s1w3</w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930709-101-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p1s1w4</w.rf>
   <form>víc</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-mf930709-101-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p1s1w5</w.rf>
   <form>polepené</form>
   <lemma>polepený_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
 </s>
 <s id="m-mf930709-101-p2s1A">
  <m id="m-mf930709-101-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Aw1</w.rf>
   <form>KAJAKÁŘ</form>
   <lemma>kajakář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Aw2</w.rf>
   <form>HILGERT</form>
   <lemma>Hilgert_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Aw3</w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Aw4</w.rf>
   <form>VLÁSEK</form>
   <lemma>vlásek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Aw5</w.rf>
   <form>UNIKL</form>
   <lemma>uniknout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-mf930709-101-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Aw6</w.rf>
   <form>DISKVALIFIKACI</form>
   <lemma>diskvalifikace</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
 </s>
 <s id="m-mf930709-101-p2s1B">
  <m id="m-mf930709-101-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Bw1</w.rf>
   <form>Mezzana</form>
   <form_change>spell</form_change>
   <lemma>Mezzana_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Bw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-101-p2s1C">
  <m id="m-mf930709-101-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw1</w.rf>
   <form>Luboši</form>
   <lemma>Luboš_;Y</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw2</w.rf>
   <form>Hilgertovi</form>
   <lemma>Hilgert_;S</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw4</w.rf>
   <form>českému</form>
   <lemma>český</lemma>
   <tag>AAMS3----1A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw5</w.rf>
   <form>kajakáři</form>
   <lemma>kajakář</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw8</w.rf>
   <form>zastavil</form>
   <lemma>zastavit-1_:W_^([také_z._se];_uvést_do_klidu:_auto,...)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw9</w.rf>
   <form>dech</form>
   <lemma>dech</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw11</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw12</w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>PHZS3--3-------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw14</w.rf>
   <form>cíli</form>
   <lemma>cíl</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw15</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw16</w.rf>
   <form>jízdy</form>
   <lemma>jízda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw17</w.rf>
   <form>kvalifikace</form>
   <lemma>kvalifikace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw19</w.rf>
   <form>mistrovství</form>
   <lemma>mistrovství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw20</w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw21</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw22</w.rf>
   <form>vodním</form>
   <lemma>vodní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw23</w.rf>
   <form>slalomu</form>
   <lemma>slalom</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw24</w.rf>
   <form>zvážili</form>
   <lemma>zvážit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw25</w.rf>
   <form>loď</form>
   <lemma>loď</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s1Cw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s1Cw26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-101-p2s2">
  <m id="m-mf930709-101-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w1</w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf930709-101-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930709-101-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w3</w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w4</w.rf>
   <form>gramů</form>
   <lemma>gram</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w5</w.rf>
   <form>méně</form>
   <lemma>málo-3</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-mf930709-101-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w7</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w8</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf930709-101-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w9</w.rf>
   <form>nejnižší</form>
   <lemma>nízký</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m-mf930709-101-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w10</w.rf>
   <form>přípustná</form>
   <lemma>přípustný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf930709-101-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w11</w.rf>
   <form>hmotnost</form>
   <lemma>hmotnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w12</w.rf>
   <form>kajaků</form>
   <lemma>kajak</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w14</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w15</w.rf>
   <form>kg</form>
   <lemma>kg-1`kilogram_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-mf930709-101-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s2w16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-101-p2s3">
  <m id="m-mf930709-101-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s3w1</w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-mf930709-101-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s3w2</w.rf>
   <form>mohlo</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-mf930709-101-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s3w3</w.rf>
   <form>znamenat</form>
   <lemma>znamenat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf930709-101-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s3w4</w.rf>
   <form>diskvalifikaci</form>
   <lemma>diskvalifikace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s3w5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-101-p2s4">
  <m id="m-mf930709-101-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-101-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w2</w.rf>
   <form>trojnásobném</form>
   <lemma>trojnásobný`3</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf930709-101-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w3</w.rf>
   <form>kontrolním</form>
   <lemma>kontrolní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf930709-101-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w4</w.rf>
   <form>měření</form>
   <lemma>měření_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w5</w.rf>
   <form>ukazovala</form>
   <lemma>ukazovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf930709-101-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w6</w.rf>
   <form>váha</form>
   <lemma>váha_^(na_vážení;_hmotnost)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w7</w.rf>
   <form>dvakrát</form>
   <lemma>dvakrát`2</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w8</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930709-101-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w9</w.rf>
   <form>čtyřicet</form>
   <lemma>čtyřicet`40</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-mf930709-101-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w11</w.rf>
   <form>jednou</form>
   <lemma>jednou</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-mf930709-101-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w12</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930709-101-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w13</w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-mf930709-101-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w14</w.rf>
   <form>gramů</form>
   <lemma>gram</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w15</w.rf>
   <form>méně</form>
   <lemma>málo-3</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-mf930709-101-p2s4w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s4w16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-101-p2s5">
  <m id="m-mf930709-101-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s5w1</w.rf>
   <form>Odborné</form>
   <lemma>odborný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-mf930709-101-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s5w2</w.rf>
   <form>znalosti</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s5w3</w.rf>
   <form>tu</form>
   <lemma>tady</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-mf930709-101-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s5w4</w.rf>
   <form>uplatnil</form>
   <lemma>uplatnit_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-mf930709-101-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s5w5</w.rf>
   <form>předseda</form>
   <lemma>předseda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s5w6</w.rf>
   <form>Českého</form>
   <lemma>český</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf930709-101-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s5w7</w.rf>
   <form>svazu</form>
   <lemma>svaz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s5w8</w.rf>
   <form>Jaroslav</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s5w9</w.rf>
   <form>Pollert</form>
   <lemma>Pollert_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-101-p2s5w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-101-p2s5w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-113-p1s1">
  <m id="m-ln95048-113-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p1s1w1</w.rf>
   <form>Ruské</form>
   <lemma>ruský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln95048-113-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p1s1w2</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-113-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p1s1w3</w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95048-113-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p1s1w4</w.rf>
   <form>ostřelovaly</form>
   <lemma>ostřelovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-113-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p1s1w5</w.rf>
   <form>jižní</form>
   <lemma>jižní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln95048-113-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p1s1w6</w.rf>
   <form>předměstí</form>
   <lemma>předměstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95048-113-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p1s1w7</w.rf>
   <form>Grozného</form>
   <lemma>Groznyj_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln95048-113-p2s1A">
  <m id="m-ln95048-113-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Aw1</w.rf>
   <form>Groznyj</form>
   <lemma>Groznyj_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Aw2</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-113-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Aw3</w.rf>
   <form>Moskva</form>
   <lemma>Moskva_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Aw4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-113-p2s1B">
  <m id="m-ln95048-113-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw1</w.rf>
   <form>Výbuchy</form>
   <lemma>výbuch</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw2</w.rf>
   <form>dělostřeleckých</form>
   <lemma>dělostřelecký</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw3</w.rf>
   <form>granátů</form>
   <lemma>granát</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw5</w.rf>
   <form>tříštivé</form>
   <lemma>tříštivý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw6</w.rf>
   <form>exploze</form>
   <lemma>exploze</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw7</w.rf>
   <form>raket</form>
   <lemma>raketa</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw9</w.rf>
   <form>rozléhaly</form>
   <lemma>rozléhat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw11</w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw13</w.rf>
   <form>včerejšek</form>
   <lemma>včerejšek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw15</w.rf>
   <form>jižním</form>
   <lemma>jižní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw16</w.rf>
   <form>předměstí</form>
   <lemma>předměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw17</w.rf>
   <form>Grozného</form>
   <lemma>Groznyj_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s1Bw18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-113-p2s2">
  <m id="m-ln95048-113-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-113-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w2</w.rf>
   <form>svědků</form>
   <lemma>svědek</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95048-113-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w4</w.rf>
   <form>ruské</form>
   <lemma>ruský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w5</w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w6</w.rf>
   <form>ostřelováním</form>
   <lemma>ostřelování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w7</w.rf>
   <form>čečenských</form>
   <lemma>čečenský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w8</w.rf>
   <form>pozic</form>
   <lemma>pozice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w9</w.rf>
   <form>pokusily</form>
   <lemma>pokusit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-113-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w10</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95048-113-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w11</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95048-113-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w12</w.rf>
   <form>rozbřeskem</form>
   <lemma>rozbřesk</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w13</w.rf>
   <form>vytlačit</form>
   <lemma>vytlačit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w14</w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w15</w.rf>
   <form>obránce</form>
   <lemma>obránce</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w16</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-113-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w17</w.rf>
   <form>čečenského</form>
   <lemma>čečenský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w18</w.rf>
   <form>hlavního</form>
   <lemma>hlavní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w19</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s2w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-113-p2s3">
  <m id="m-ln95048-113-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w1</w.rf>
   <form>Zahraniční</form>
   <lemma>zahraniční_,a</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w2</w.rf>
   <form>novináři</form>
   <lemma>novinář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w3</w.rf>
   <form>hlásili</form>
   <lemma>hlásit_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-113-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-113-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w5</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95048-113-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w6</w.rf>
   <form>dělostřelecké</form>
   <lemma>dělostřelecký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w7</w.rf>
   <form>baterie</form>
   <lemma>baterie</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w8</w.rf>
   <form>ruské</form>
   <lemma>ruský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w9</w.rf>
   <form>armády</form>
   <lemma>armáda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w10</w.rf>
   <form>rozmístěné</form>
   <lemma>rozmístěný_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95048-113-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w12</w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w13</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w14</w.rf>
   <form>Gojty</form>
   <lemma>Gojta_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-113-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w16</w.rf>
   <form>vzdáleného</form>
   <lemma>vzdálený_^(*3it)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w17</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95048-113-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w18</w.rf>
   <form>kilometrů</form>
   <lemma>kilometr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w19</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-113-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w20</w.rf>
   <form>Grozného</form>
   <lemma>Groznyj_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-113-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w22</w.rf>
   <form>téměř</form>
   <lemma>téměř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95048-113-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w23</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-ln95048-113-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w24</w.rf>
   <form>hodiny</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w25</w.rf>
   <form>ostřelovaly</form>
   <lemma>ostřelovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-113-p2s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w26</w.rf>
   <form>pozice</form>
   <lemma>pozice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w27</w.rf>
   <form>separatistů</form>
   <lemma>separatista</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w28</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95048-113-p2s3w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w29</w.rf>
   <form>jihu</form>
   <lemma>jih</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w30</w.rf>
   <form>hlavního</form>
   <lemma>hlavní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w31</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95048-113-p2s3w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-113-p2s3w32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-150-p1s1">
  <m id="m-ln94200-150-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p1s1w1</w.rf>
   <form>Smlouva</form>
   <lemma>smlouva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p1s1w2</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94200-150-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p1s1w3</w.rf>
   <form>Teleaxisem</form>
   <lemma>Teleaxis_;K</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94200-150-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p1s1w4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94200-150-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p1s1w5</w.rf>
   <form>rukou</form>
   <lemma>ruka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94200-150-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p1s1w6</w.rf>
   <form>předsedy</form>
   <lemma>předseda</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p1s1w7</w.rf>
   <form>ČTS</form>
   <lemma>ČTS_:B_;K_^(Český_tenisový_svaz)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
 </s>
 <s id="m-ln94200-150-p2s1A">
  <m id="m-ln94200-150-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Aw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-150-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Aw3</w.rf>
   <form>ad</form>
   <lemma>ad-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94200-150-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Aw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-150-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Aw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-150-p2s1B">
  <m id="m-ln94200-150-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw1</w.rf>
   <form>Osud</form>
   <lemma>osud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw2</w.rf>
   <form>marketingové</form>
   <lemma>marketingový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw3</w.rf>
   <form>smlouvy</form>
   <lemma>smlouva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw4</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw5</w.rf>
   <form>Českým</form>
   <lemma>český</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw6</w.rf>
   <form>tenisovým</form>
   <lemma>tenisový</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw7</w.rf>
   <form>svazem</form>
   <lemma>svaz</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw9</w.rf>
   <form>firmou</form>
   <lemma>firma</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw10</w.rf>
   <form>Teleaxis</form>
   <lemma>Teleaxis_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw11</w.rf>
   <form>leží</form>
   <lemma>ležet</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw13</w.rf>
   <form>rukou</form>
   <lemma>ruka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw14</w.rf>
   <form>předsedy</form>
   <lemma>předseda</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw15</w.rf>
   <form>ČTS</form>
   <lemma>ČTS_:B_;K_^(Český_tenisový_svaz)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw16</w.rf>
   <form>Milana</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw17</w.rf>
   <form>Matzenauera</form>
   <lemma>Matzenauer_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw19</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw20</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw21</w.rf>
   <form>výkonným</form>
   <lemma>výkonný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw22</w.rf>
   <form>výborem</form>
   <lemma>výbor</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw23</w.rf>
   <form>pověřen</form>
   <lemma>pověřit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw24</w.rf>
   <form>jednat</form>
   <lemma>jednat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw25</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw26</w.rf>
   <form>šéfem</form>
   <lemma>šéf</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw27</w.rf>
   <form>Teleaxisu</form>
   <lemma>Teleaxis_;K</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw28</w.rf>
   <form>Petrem</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw29</w.rf>
   <form>Kovarčíkem</form>
   <lemma>Kovarčík_;S</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s1Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s1Bw30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-150-p2s2">
  <m id="m-ln94200-150-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w1</w.rf>
   <form>Vypovězení</form>
   <lemma>vypovězení_^(*4dět)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w2</w.rf>
   <form>marketingové</form>
   <lemma>marketingový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94200-150-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w3</w.rf>
   <form>smlouvy</form>
   <lemma>smlouva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w4</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-150-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w5</w.rf>
   <form>platí</form>
   <lemma>platit_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94200-150-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94200-150-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w7</w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w8</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-ln94200-150-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w9</w.rf>
   <form>1995</form>
   <lemma>1995</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94200-150-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w10</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-150-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w11</w.rf>
   <form>funkcionářům</form>
   <lemma>funkcionář</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w12</w.rf>
   <form>doporučil</form>
   <lemma>doporučit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94200-150-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w13</w.rf>
   <form>prezident</form>
   <lemma>prezident</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w14</w.rf>
   <form>ČTS</form>
   <lemma>ČTS_:B_;K_^(Český_tenisový_svaz)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln94200-150-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w15</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w16</w.rf>
   <form>Kodeš</form>
   <lemma>Kodeš_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-150-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w18</w.rf>
   <form>neboť</form>
   <lemma>neboť</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94200-150-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w19</w.rf>
   <form>Teleaxis</form>
   <lemma>Teleaxis_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w20</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94200-150-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w21</w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>P5ZS2--3-------</tag>
  </m>
  <m id="m-ln94200-150-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w22</w.rf>
   <form>smlouvu</form>
   <lemma>smlouva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94200-150-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w23</w.rf>
   <form>neplní</form>
   <lemma>plnit_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-ln94200-150-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p2s2w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-150-p3s1">
  <m id="m-ln94200-150-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w1</w.rf>
   <form>Urovnání</form>
   <lemma>urovnání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w2</w.rf>
   <form>vztahů</form>
   <lemma>vztah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-150-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w4</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m-ln94200-150-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w5</w.rf>
   <form>pošramotily</form>
   <lemma>pošramotit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln94200-150-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w6</w.rf>
   <form>nedávné</form>
   <lemma>dávný</lemma>
   <tag>AAIP1----1N----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w7</w.rf>
   <form>Kodešovy</form>
   <lemma>Kodešův_;S_^(*2)</lemma>
   <tag>AUIP1M---------</tag>
  </m>
  <m id="m-ln94200-150-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w8</w.rf>
   <form>výroky</form>
   <lemma>výrok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94200-150-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w10</w.rf>
   <form>následná</form>
   <lemma>následný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w11</w.rf>
   <form>varovná</form>
   <lemma>varovný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w12</w.rf>
   <form>odpověď</form>
   <lemma>odpověď</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w13</w.rf>
   <form>Teleaxisu</form>
   <lemma>Teleaxis_;K</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-150-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w15</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-ln94200-150-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w16</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94200-150-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w17</w.rf>
   <form>zlomkem</form>
   <lemma>zlomek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w18</w.rf>
   <form>jednání</form>
   <lemma>jednání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w19</w.rf>
   <form>M</form>
   <lemma>M-0_:B_;Y</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-ln94200-150-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-150-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w21</w.rf>
   <form>Matzenauera</form>
   <lemma>Matzenauer_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w22</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94200-150-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w23</w.rf>
   <form>P</form>
   <lemma>P-0_:B_;Y</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-ln94200-150-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-150-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w25</w.rf>
   <form>Kovarčíkem</form>
   <lemma>Kovarčík_;S</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94200-150-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-150-p3s1w26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
