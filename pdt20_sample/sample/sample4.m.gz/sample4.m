<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="sample4.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94206-79-p1s1">
  <m id="m-ln94206-79-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p1s1w1</w.rf>
   <form>Příměří</form>
   <lemma>příměří</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94206-79-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p1s1w2</w.rf>
   <form>vstoupilo</form>
   <lemma>vstoupit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94206-79-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p1s1w3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94206-79-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p1s1w4</w.rf>
   <form>platnost</form>
   <lemma>platnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
 </s>
 <s id="m-ln94206-79-p2s1A">
  <m id="m-ln94206-79-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Aw1</w.rf>
   <form>Irská</form>
   <lemma>irský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Aw2</w.rf>
   <form>republikánská</form>
   <lemma>republikánský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Aw3</w.rf>
   <form>armáda</form>
   <lemma>armáda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Aw4</w.rf>
   <form>vyhlášený</form>
   <lemma>vyhlášený_,a_^(*4sit)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Aw5</w.rf>
   <form>klid</form>
   <lemma>klid</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Aw6</w.rf>
   <form>zbraní</form>
   <lemma>zbraň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Aw7</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Aw8</w.rf>
   <form>dodržuje</form>
   <lemma>dodržovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
 </s>
 <s id="m-ln94206-79-p2s1B">
  <m id="m-ln94206-79-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Bw1</w.rf>
   <form>Belfast</form>
   <lemma>Belfast_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Bw2</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Bw3</w.rf>
   <form>Londýn</form>
   <lemma>Londýn_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Bw4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-79-p2s1C">
  <m id="m-ln94206-79-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw1</w.rf>
   <form>Příměří</form>
   <lemma>příměří</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw3</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw4</w.rf>
   <form>vyhlásila</form>
   <lemma>vyhlásit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw5</w.rf>
   <form>Irská</form>
   <lemma>irský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw6</w.rf>
   <form>republikánská</form>
   <lemma>republikánský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw7</w.rf>
   <form>armáda</form>
   <lemma>armáda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw8</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw9</w.rf>
   <form>IRA</form>
   <lemma>IRA-1_;K_,t_^(Irská_republikánská_armáda)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw10</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw12</w.rf>
   <form>vstoupilo</form>
   <lemma>vstoupit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw14</w.rf>
   <form>Severním</form>
   <lemma>severní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw15</w.rf>
   <form>Irsku</form>
   <lemma>Irsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw17</w.rf>
   <form>platnost</form>
   <lemma>platnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw18</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw20</w.rf>
   <form>0.00</form>
   <form_change>num_normalization</form_change>
   <lemma>0.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw21</w.rf>
   <form>místního</form>
   <lemma>místní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw22</w.rf>
   <form>času</form>
   <lemma>čas</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s1Cw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s1Cw23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-79-p2s2">
  <m id="m-ln94206-79-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w1</w.rf>
   <form>Stalo</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94206-79-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94206-79-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w3</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w4</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w5</w.rf>
   <form>hodin</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w6</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w8</w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94206-79-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w9</w.rf>
   <form>IRA</form>
   <lemma>IRA-1_;K_,t_^(Irská_republikánská_armáda)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94206-79-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w10</w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-ln94206-79-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w11</w.rf>
   <form>svůj</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8IS4----------</tag>
  </m>
  <m id="m-ln94206-79-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w12</w.rf>
   <form>krok</form>
   <lemma>krok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94206-79-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w13</w.rf>
   <form>oznámila</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94206-79-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p2s2w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-79-p3s1">
  <m id="m-ln94206-79-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-79-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w2</w.rf>
   <form>informací</form>
   <lemma>informace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w3</w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94206-79-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94206-79-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w6</w.rf>
   <form>Belfastu</form>
   <lemma>Belfast_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w7</w.rf>
   <form>noc</form>
   <lemma>noc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94206-79-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w9</w.rf>
   <form>včerejšek</form>
   <lemma>včerejšek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w10</w.rf>
   <form>obešla</form>
   <lemma>obejít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94206-79-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w11</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-79-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w12</w.rf>
   <form>větších</form>
   <lemma>velký</lemma>
   <tag>AAIP2----2A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w13</w.rf>
   <form>incidentů</form>
   <lemma>incident</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-79-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w15</w.rf>
   <form>kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-79-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w16</w.rf>
   <form>výstřelů</form>
   <lemma>výstřel</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-79-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w18</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m-ln94206-79-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w19</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94206-79-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w20</w.rf>
   <form>slyšet</form>
   <lemma>slyšet</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w21</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94206-79-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w22</w.rf>
   <form>východní</form>
   <lemma>východní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w23</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w24</w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s1w25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-79-p3s2">
  <m id="m-ln94206-79-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s2w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94206-79-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s2w2</w.rf>
   <form>ulicích</form>
   <lemma>ulice</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s2w3</w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-79-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s2w4</w.rf>
   <form>hlídkují</form>
   <lemma>hlídkovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94206-79-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s2w5</w.rf>
   <form>britští</form>
   <lemma>britský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94206-79-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s2w6</w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s2w7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94206-79-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s2w8</w.rf>
   <form>obrněných</form>
   <lemma>obrněný_^(*3it)</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-ln94206-79-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s2w9</w.rf>
   <form>vozidlech</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-ln94206-79-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-79-p3s2w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-013-p1s1">
  <m id="m-ln95049-013-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p1s1w1</w.rf>
   <form>Rasisté</form>
   <lemma>rasista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p1s1w2</w.rf>
   <form>útočí</form>
   <lemma>útočit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95049-013-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p1s1w3</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln95049-013-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p1s1w4</w.rf>
   <form>skupinách</form>
   <lemma>skupina</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
 </s>
 <s id="m-ln95049-013-p2s1A">
  <m id="m-ln95049-013-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Aw2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-013-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Aw3</w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Aw4</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-013-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Aw5</w.rf>
   <form>toh</form>
   <lemma>toh-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln95049-013-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Aw6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-013-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Aw7</w.rf>
   <form>vet</form>
   <lemma>vet-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln95049-013-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Aw8</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-013-p2s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Aw9</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-013-p2s1B">
  <m id="m-ln95049-013-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw1</w.rf>
   <form>Pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw2</w.rf>
   <form>vlivem</form>
   <lemma>vliv</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw3</w.rf>
   <form>rasové</form>
   <lemma>rasový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw4</w.rf>
   <form>nesnášenlivosti</form>
   <lemma>snášenlivost_^(*3ý)</lemma>
   <tag>NNFS2-----N----</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw5</w.rf>
   <form>páchají</form>
   <form_change>spell</form_change>
   <lemma>páchat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw7</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw8</w.rf>
   <form>trestnou</form>
   <lemma>trestný_^(čin)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw9</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw10</w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw11</w.rf>
   <form>organizované</form>
   <lemma>organizovaný_^(*2t)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw12</w.rf>
   <form>skupiny</form>
   <lemma>skupina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s1Bw13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-013-p2s2">
  <m id="m-ln95049-013-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s2w1</w.rf>
   <form>Nejčastěji</form>
   <lemma>často</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-ln95049-013-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s2w2</w.rf>
   <form>takto</form>
   <lemma>takto</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-013-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s2w3</w.rf>
   <form>útočí</form>
   <lemma>útočit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95049-013-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s2w4</w.rf>
   <form>deseti</form>
   <lemma>deset`10</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-ln95049-013-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s2w5</w.rf>
   <form>až</form>
   <lemma>až-1_^(2_až_3)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95049-013-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s2w6</w.rf>
   <form>třicetičlenné</form>
   <lemma>třicetičlenný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln95049-013-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s2w7</w.rf>
   <form>party</form>
   <lemma>parta</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s2w8</w.rf>
   <form>pachatelů</form>
   <lemma>pachatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s2w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-013-p2s3">
  <m id="m-ln95049-013-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w1</w.rf>
   <form>LN</form>
   <lemma>LN-1_:B_;R_^(Lidové_noviny,_deník)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-ln95049-013-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-ln95049-013-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w3</w.rf>
   <form>řekla</form>
   <lemma>říci_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln95049-013-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w4</w.rf>
   <form>poradkyně</form>
   <lemma>poradkyně_^(*4ce)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w5</w.rf>
   <form>náměstka</form>
   <lemma>náměstek</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w6</w.rf>
   <form>ministra</form>
   <lemma>ministr</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w7</w.rf>
   <form>vnitra</form>
   <lemma>vnitro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w8</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95049-013-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w9</w.rf>
   <form>oblast</form>
   <lemma>oblast</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w10</w.rf>
   <form>bezpečnosti</form>
   <lemma>bezpečnost-1_^(*5ý-1)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w11</w.rf>
   <form>Jitka</form>
   <lemma>Jitka-1_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w12</w.rf>
   <form>Gjuričová</form>
   <lemma>Gjuričová_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-013-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w14</w.rf>
   <form>autorka</form>
   <lemma>autorka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w15</w.rf>
   <form>zprávy</form>
   <lemma>zpráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w16</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-013-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w17</w.rf>
   <form>Interetnické</form>
   <lemma>interetnický</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w18</w.rf>
   <form>konflikty</form>
   <lemma>konflikt</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w19</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-013-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p2s3w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-013-p3s1">
  <m id="m-ln95049-013-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w1</w.rf>
   <form>Právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-013-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w2</w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-ln95049-013-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w3</w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w4</w.rf>
   <form>napadla</form>
   <lemma>napadnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-ln95049-013-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w5</w.rf>
   <form>čtyřčlenná</form>
   <lemma>čtyřčlenný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w6</w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w7</w.rf>
   <form>mladíků</form>
   <lemma>mladík</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w8</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95049-013-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w9</w.rf>
   <form>obušky</form>
   <lemma>obušek</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95049-013-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w11</w.rf>
   <form>sečnou</form>
   <lemma>sečný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w12</w.rf>
   <form>zbraní</form>
   <lemma>zbraň</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w13</w.rf>
   <form>podobnou</form>
   <lemma>podobný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w14</w.rf>
   <form>mačetě</form>
   <lemma>mačeta</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-013-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w16</w.rf>
   <form>Centrálním</form>
   <lemma>centrální</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w17</w.rf>
   <form>autobusovém</form>
   <lemma>autobusový</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w18</w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-013-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w20</w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w21</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-ln95049-013-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w22</w.rf>
   <form>Romy</form>
   <lemma>Rom-4_;E</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s1w23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-013-p3s2">
  <m id="m-ln95049-013-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s2w1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-013-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s2w2</w.rf>
   <form>útoku</form>
   <lemma>útok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s2w3</w.rf>
   <form>utržil</form>
   <lemma>utržit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95049-013-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s2w4</w.rf>
   <form>dvaadvacetiletý</form>
   <lemma>dvaadvacetiletý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln95049-013-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s2w5</w.rf>
   <form>Rom</form>
   <lemma>Rom-4_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s2w6</w.rf>
   <form>sečnou</form>
   <lemma>sečný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln95049-013-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s2w7</w.rf>
   <form>ránu</form>
   <lemma>rána</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s2w8</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95049-013-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s2w9</w.rf>
   <form>krku</form>
   <lemma>krk</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s2w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-013-p3s3">
  <m id="m-ln95049-013-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s3w1</w.rf>
   <form>Přihlížející</form>
   <lemma>přihlížející_^(*4t)</lemma>
   <tag>AGMP1-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s3w2</w.rf>
   <form>přivolali</form>
   <lemma>přivolat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln95049-013-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s3w3</w.rf>
   <form>lékaře</form>
   <lemma>lékař</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s3w4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95049-013-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s3w5</w.rf>
   <form>ihned</form>
   <lemma>ihned</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-013-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s3w6</w.rf>
   <form>poté</form>
   <lemma>poté</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-013-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s3w7</w.rf>
   <form>policii</form>
   <lemma>policie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95049-013-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-013-p3s3w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-76-p1s1">
  <m id="m-ln94205-76-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p1s1w1</w.rf>
   <form>Odchod</form>
   <lemma>odchod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p1s1w2</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ln94205-76-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p1s1w3</w.rf>
   <form>SRN</form>
   <lemma>SRN_:B_;G</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94205-76-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p1s1w4</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-76-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p1s1w5</w.rf>
   <form>konec</form>
   <lemma>konec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p1s1w6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-76-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p1s1w7</w.rf>
   <form>počátek</form>
   <lemma>počátek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94205-76-p2s1A">
  <m id="m-ln94205-76-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Aw1</w.rf>
   <form>Helmut</form>
   <lemma>Helmut_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Aw2</w.rf>
   <form>Kohl</form>
   <lemma>Kohl_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Aw3</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-76-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Aw4</w.rf>
   <form>Budoucnost</form>
   <lemma>budoucnost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Aw5</w.rf>
   <form>Evropy</form>
   <lemma>Evropa_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Aw6</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94205-76-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Aw7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-76-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Aw8</w.rf>
   <form>součinnosti</form>
   <lemma>součinnost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Aw9</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94205-76-p2s1Aw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Aw10</w.rf>
   <form>Ruskem</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-ln94205-76-p2s1B">
  <m id="m-ln94205-76-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Bw1</w.rf>
   <form>Berlín</form>
   <lemma>Berlín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Bw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-76-p2s1C">
  <m id="m-ln94205-76-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw1</w.rf>
   <form>Včerejší</form>
   <lemma>včerejší</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw2</w.rf>
   <form>den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw4</w.rf>
   <form>posledním</form>
   <lemma>poslední</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw5</w.rf>
   <form>dnem</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw6</w.rf>
   <form>minulosti</form>
   <lemma>minulost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw8</w.rf>
   <form>naším</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSZS7-P1-------</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw9</w.rf>
   <form>úsilím</form>
   <lemma>úsilí</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw11</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw12</w.rf>
   <form>stát</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw13</w.rf>
   <form>prvním</form>
   <lemma>první</lemma>
   <tag>CrIS7----------</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw14</w.rf>
   <form>dnem</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw15</w.rf>
   <form>společné</form>
   <lemma>společný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw16</w.rf>
   <form>budoucnosti</form>
   <lemma>budoucnost</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s1Cw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s1Cw17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-76-p2s2">
  <m id="m-ln94205-76-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w1</w.rf>
   <form>Současně</form>
   <lemma>současně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-76-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w3</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94205-76-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w4</w.rf>
   <form>den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w5</w.rf>
   <form>definitivního</form>
   <lemma>definitivní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w6</w.rf>
   <form>usmíření</form>
   <lemma>usmíření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-76-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w8</w.rf>
   <form>řekl</form>
   <lemma>říci_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94205-76-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w9</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-76-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-76-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w11</w.rf>
   <form>Berlíně</form>
   <lemma>Berlín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w12</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-76-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w13</w.rf>
   <form>slavnostním</form>
   <lemma>slavnostní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w14</w.rf>
   <form>ukončení</form>
   <lemma>ukončení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w15</w.rf>
   <form>odchodu</form>
   <lemma>odchod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w16</w.rf>
   <form>ruských</form>
   <lemma>ruský</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w17</w.rf>
   <form>vojsk</form>
   <lemma>vojsko</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w18</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94205-76-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w19</w.rf>
   <form>Německa</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w20</w.rf>
   <form>ruský</form>
   <lemma>ruský</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w21</w.rf>
   <form>prezident</form>
   <lemma>prezident</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w22</w.rf>
   <form>Boris</form>
   <lemma>Boris_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w23</w.rf>
   <form>Jelcin</form>
   <lemma>Jelcin_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p2s2w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-76-p3s1">
  <m id="m-ln94205-76-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w1</w.rf>
   <form>Vyzdvihl</form>
   <lemma>vyzdvihnout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94205-76-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w2</w.rf>
   <form>podíl</form>
   <lemma>podíl</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94205-76-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w3</w.rf>
   <form>sovětských</form>
   <lemma>sovětský</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ln94205-76-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w4</w.rf>
   <form>vojsk</form>
   <lemma>vojsko</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-76-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w6</w.rf>
   <form>porážce</form>
   <lemma>porážka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94205-76-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w7</w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m-ln94205-76-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w8</w.rf>
   <form>říše</form>
   <lemma>říše</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-76-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w10</w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-76-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w11</w.rf>
   <form>dodal</form>
   <lemma>dodat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94205-76-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w12</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-76-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w13</w.rf>
   <form>Už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-76-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w14</w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-76-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w15</w.rf>
   <form>nesmíme</form>
   <lemma>smět_:T</lemma>
   <tag>VB-P---1P-NA---</tag>
  </m>
  <m id="m-ln94205-76-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w16</w.rf>
   <form>připustit</form>
   <lemma>připustit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-76-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w17</w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94205-76-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w18</w.rf>
   <form>rozdělení</form>
   <lemma>rozdělení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94205-76-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w19</w.rf>
   <form>Evropy</form>
   <lemma>Evropa_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s1w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-76-p3s2">
  <m id="m-ln94205-76-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w1</w.rf>
   <form>Ruští</form>
   <lemma>ruský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94205-76-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w2</w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94205-76-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w4</w.rf>
   <form>vracejí</form>
   <lemma>vracet_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94205-76-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w5</w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-76-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w6</w.rf>
   <form>přesvědčeni</form>
   <lemma>přesvědčit_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-ln94205-76-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-76-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w8</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94205-76-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w9</w.rf>
   <form>Rusku</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94205-76-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w10</w.rf>
   <form>už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-76-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w11</w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-76-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w12</w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NA---</tag>
  </m>
  <m id="m-ln94205-76-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w13</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94205-76-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w14</w.rf>
   <form>německé</form>
   <lemma>německý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94205-76-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w15</w.rf>
   <form>půdy</form>
   <lemma>půda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-76-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w16</w.rf>
   <form>hrozit</form>
   <lemma>hrozit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-76-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w17</w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94205-76-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-76-p3s2w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-119-p1s1">
  <m id="m-ln95049-119-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p1s1w1</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p1s1w2</w.rf>
   <form>zadržela</form>
   <lemma>zadržet</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln95049-119-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p1s1w3</w.rf>
   <form>Kolumbijce</form>
   <lemma>Kolumbijec_;E</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln95049-119-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p1s1w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-119-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p1s1w5</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln95049-119-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p1s1w6</w.rf>
   <form>pašoval</form>
   <lemma>pašovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95049-119-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p1s1w7</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-ln95049-119-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p1s1w8</w.rf>
   <form>kilogramy</form>
   <lemma>kilogram</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln95049-119-p1s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p1s1w9</w.rf>
   <form>kokainu</form>
   <lemma>kokain</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln95049-119-p2s1A">
  <m id="m-ln95049-119-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-119-p2s1B">
  <m id="m-ln95049-119-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw1</w.rf>
   <form>Dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw2</w.rf>
   <form>kilogramy</form>
   <lemma>kilogram</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw3</w.rf>
   <form>kokainu</form>
   <lemma>kokain</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw4</w.rf>
   <form>zadrželi</form>
   <lemma>zadržet</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw5</w.rf>
   <form>celníci</form>
   <lemma>celník-1_^(úřední_osoba)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw7</w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw9</w.rf>
   <form>ruzyňském</form>
   <lemma>ruzyňský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw10</w.rf>
   <form>letišti</form>
   <lemma>letiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw12</w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s1Bw13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-119-p2s2">
  <m id="m-ln95049-119-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w1</w.rf>
   <form>Informoval</form>
   <lemma>informovat_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95049-119-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-119-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w3</w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-ln95049-119-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w4</w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w5</w.rf>
   <form>protidrogového</form>
   <lemma>protidrogový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln95049-119-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w6</w.rf>
   <form>oddělení</form>
   <lemma>oddělení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w7</w.rf>
   <form>Generálního</form>
   <lemma>generální</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln95049-119-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w8</w.rf>
   <form>ředitelství</form>
   <lemma>ředitelství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w9</w.rf>
   <form>cel</form>
   <lemma>clo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w10</w.rf>
   <form>Bohumír</form>
   <lemma>Bohumír_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w11</w.rf>
   <form>Marek</form>
   <lemma>Marek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s2w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-119-p2s3">
  <m id="m-ln95049-119-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w1</w.rf>
   <form>Droga</form>
   <lemma>droga</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-119-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w3</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln95049-119-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w4</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95049-119-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-119-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w6</w.rf>
   <form>černém</form>
   <lemma>černý-2_^(ilegální)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln95049-119-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w7</w.rf>
   <form>trhu</form>
   <lemma>trh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w8</w.rf>
   <form>hodnotu</form>
   <lemma>hodnota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w9</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln95049-119-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w10</w.rf>
   <form>4.5</form>
   <form_change>num_normalization</form_change>
   <lemma>4.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95049-119-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w11</w.rf>
   <form>miliónu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w12</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-119-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w14</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln95049-119-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w15</w.rf>
   <form>nalezena</form>
   <lemma>naleznout</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ln95049-119-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-119-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w17</w.rf>
   <form>zavazadle</form>
   <lemma>zavazadlo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w18</w.rf>
   <form>kolumbijského</form>
   <lemma>kolumbijský</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln95049-119-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w19</w.rf>
   <form>občana</form>
   <lemma>občan</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p2s3w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-119-p3s1">
  <m id="m-ln95049-119-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w1</w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-ln95049-119-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95049-119-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w3</w.rf>
   <form>pražské</form>
   <lemma>pražský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln95049-119-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w4</w.rf>
   <form>letiště</form>
   <lemma>letiště</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w5</w.rf>
   <form>přicestoval</form>
   <lemma>přicestovat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95049-119-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w6</w.rf>
   <form>letadlem</form>
   <lemma>letadlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w7</w.rf>
   <form>pravidelné</form>
   <lemma>pravidelný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95049-119-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w8</w.rf>
   <form>linky</form>
   <lemma>linka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w9</w.rf>
   <form>Bogota</form>
   <lemma>Bogota_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-119-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w11</w.rf>
   <form>Frankfurt</form>
   <lemma>Frankfurt_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w12</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-119-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w13</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s1w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-119-p3s2">
  <m id="m-ln95049-119-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w1</w.rf>
   <form>Drogu</form>
   <lemma>droga</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w2</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95049-119-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w3</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95049-119-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w4</w.rf>
   <form>Marka</form>
   <lemma>Marek_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w5</w.rf>
   <form>ukrytou</form>
   <lemma>ukrytý_^(*3ýt)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln95049-119-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln95049-119-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w7</w.rf>
   <form>dvojitých</form>
   <lemma>dvojitý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-ln95049-119-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w8</w.rf>
   <form>stěnách</form>
   <lemma>stěna</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w9</w.rf>
   <form>skořepinového</form>
   <lemma>skořepinový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln95049-119-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w10</w.rf>
   <form>kufru</form>
   <lemma>kufr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s2w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-119-p3s3">
  <m id="m-ln95049-119-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-119-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w2</w.rf>
   <form>odhalení</form>
   <lemma>odhalení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95049-119-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w4</w.rf>
   <form>celníky</form>
   <lemma>celník-1_^(úřední_osoba)</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w5</w.rf>
   <form>spolupracovali</form>
   <lemma>spolupracovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln95049-119-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w6</w.rf>
   <form>pracovníci</form>
   <lemma>pracovník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w7</w.rf>
   <form>protidrogové</form>
   <lemma>protidrogový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95049-119-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w8</w.rf>
   <form>brigády</form>
   <lemma>brigáda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w9</w.rf>
   <form>Policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95049-119-p3s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w10</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln95049-119-p3s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-119-p3s3w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-031-p1s1">
  <m id="m-ln95049-031-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p1s1w1</w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-ln95049-031-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p1s1w2</w.rf>
   <form>dál</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-031-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p1s1w3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95049-031-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p1s1w4</w.rf>
   <form>Českým</form>
   <lemma>český</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln95049-031-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p1s1w5</w.rf>
   <form>pohárem</form>
   <lemma>pohár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln95049-031-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p1s1w6</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-031-p2s1">
  <m id="m-ln95049-031-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w1</w.rf>
   <form>Český</form>
   <lemma>český</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln95049-031-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w2</w.rf>
   <form>pohár</form>
   <lemma>pohár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w3</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln95049-031-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w4</w.rf>
   <form>volejbalu</form>
   <lemma>volejbal</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln95049-031-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w5</w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-031-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w6</w.rf>
   <form>probíhal</form>
   <lemma>probíhat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95049-031-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w7</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95049-031-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w8</w.rf>
   <form>okrajová</form>
   <lemma>okrajový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln95049-031-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w9</w.rf>
   <form>záležitost</form>
   <lemma>záležitost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-031-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w11</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS2----------</tag>
  </m>
  <m id="m-ln95049-031-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w12</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95049-031-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w13</w.rf>
   <form>nezúčastnila</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-ln95049-031-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w14</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95049-031-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w15</w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln95049-031-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w16</w.rf>
   <form>naše</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m-ln95049-031-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w17</w.rf>
   <form>špička</form>
   <lemma>špička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s1w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-031-p2s2">
  <m id="m-ln95049-031-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w2</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w3</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w5</w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w6</w.rf>
   <form>nedostatku</form>
   <lemma>nedostatek</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w7</w.rf>
   <form>termínů</form>
   <lemma>termín</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w8</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w9</w.rf>
   <form>poháru</form>
   <lemma>pohár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w10</w.rf>
   <form>započítaly</form>
   <lemma>započítat_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95049-031-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w11</w.rf>
   <form>výsledky</form>
   <lemma>výsledek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w12</w.rf>
   <form>ligových</form>
   <lemma>ligový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w13</w.rf>
   <form>zápasů</form>
   <lemma>zápas</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w15</w.rf>
   <form>teprve</form>
   <lemma>teprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w16</w.rf>
   <form>sobotní</form>
   <lemma>sobotní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w17</w.rf>
   <form>finále</form>
   <lemma>finále</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w19</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w20</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w21</w.rf>
   <form>Labem</form>
   <lemma>Labe_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w22</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w23</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w24</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w25</w.rf>
   <form>průběhu</form>
   <lemma>průběh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w26</w.rf>
   <form>píšeme</form>
   <lemma>psát</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-ln95049-031-p2s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w27</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w28</w.rf>
   <form>jiném</form>
   <lemma>jiný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w29</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w30</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95049-031-p2s2w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w31</w.rf>
   <form>mělo</form>
   <lemma>mít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln95049-031-p2s2w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w32</w.rf>
   <form>důstojnou</form>
   <lemma>důstojný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w33</w.rf>
   <form>úroveň</form>
   <lemma>úroveň</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s2w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s2w34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-031-p2s3">
  <m id="m-ln95049-031-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s3w1</w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-ln95049-031-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s3w2</w.rf>
   <form>dál</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95049-031-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s3w3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95049-031-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s3w4</w.rf>
   <form>Českým</form>
   <lemma>český</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln95049-031-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s3w5</w.rf>
   <form>pohárem</form>
   <lemma>pohár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s3w6</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95049-031-p2s4">
  <m id="m-ln95049-031-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s4w1</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95049-031-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s4w2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-ln95049-031-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s4w3</w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-ln95049-031-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s4w4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95049-031-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s4w5</w.rf>
   <form>zajímali</form>
   <lemma>zajímat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln95049-031-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s4w6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95049-031-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s4w7</w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s4w8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95049-031-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s4w9</w.rf>
   <form>Ústí</form>
   <lemma>Ústí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95049-031-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95049-031-p2s4w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-084-p1s1">
  <m id="m-ln95048-084-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p1s1w1</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95048-084-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p1s1w2</w.rf>
   <form>záchranou</form>
   <lemma>záchrana</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln95048-084-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p1s1w3</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-084-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p1s1w4</w.rf>
   <form>prémií</form>
   <lemma>prémie</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
 </s>
 <s id="m-ln95048-084-p2s1A">
  <m id="m-ln95048-084-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Aw1</w.rf>
   <form>Drnovice</form>
   <lemma>Drnovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Aw2</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95048-084-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Aw3</w.rf>
   <form>stadión</form>
   <lemma>stadión</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Aw4</w.rf>
   <form>srovnatelný</form>
   <lemma>srovnatelný_^(*4)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Aw5</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Aw6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95048-084-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Aw7</w.rf>
   <form>Letnou</form>
   <lemma>Letná_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
 </s>
 <s id="m-ln95048-084-p2s1B">
  <m id="m-ln95048-084-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Bw1</w.rf>
   <form>Drnovice</form>
   <lemma>Drnovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Bw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-084-p2s1C">
  <m id="m-ln95048-084-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw1</w.rf>
   <form>Jedině</form>
   <lemma>jedině_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw2</w.rf>
   <form>záchrana</form>
   <lemma>záchrana</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw3</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw4</w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw5</w.rf>
   <form>heslo</form>
   <lemma>heslo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw6</w.rf>
   <form>platí</form>
   <lemma>platit_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw7</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw8</w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw9</w.rf>
   <form>jarní</form>
   <lemma>jarní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw10</w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw11</w.rf>
   <form>ligy</form>
   <lemma>liga</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw13</w.rf>
   <form>Drnovicích</form>
   <lemma>Drnovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s1Cw14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-084-p2s2">
  <m id="m-ln95048-084-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s2w1</w.rf>
   <form>Žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP4----------</tag>
  </m>
  <m id="m-ln95048-084-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s2w2</w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s2w3</w.rf>
   <form>prémie</form>
   <lemma>prémie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s2w4</w.rf>
   <form>přitom</form>
   <lemma>přitom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s2w5</w.rf>
   <form>klub</form>
   <lemma>klub</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s2w6</w.rf>
   <form>nevypsal</form>
   <lemma>vypsat</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ln95048-084-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s2w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-084-p2s3">
  <m id="m-ln95048-084-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w2</w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w3</w.rf>
   <form>udělám</form>
   <lemma>udělat_:W</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-ln95048-084-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w4</w.rf>
   <form>chybu</form>
   <lemma>chyba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w6</w.rf>
   <form>napravím</form>
   <lemma>napravit_:W</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-ln95048-084-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w7</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-ln95048-084-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w9</w.rf>
   <form>jedu</form>
   <lemma>jet-1_^(pohybovat_se,_ne_však_chůzí)</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-ln95048-084-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w10</w.rf>
   <form>dál</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w12</w.rf>
   <form>nemyslíte</form>
   <lemma>myslit_:T</lemma>
   <tag>VB-P---2P-NA---</tag>
  </m>
  <m id="m-ln95048-084-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w13</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w14</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w15</w.rf>
   <form>konstatoval</form>
   <lemma>konstatovat_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95048-084-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w16</w.rf>
   <form>řečnicky</form>
   <lemma>řečnicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w17</w.rf>
   <form>předseda</form>
   <lemma>předseda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w18</w.rf>
   <form>správní</form>
   <lemma>správní_^(např._poplatek;_rada;_řád;...)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w19</w.rf>
   <form>rady</form>
   <lemma>rada-3_^(poradní_sbor;_př._Česká_národní_r.)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w20</w.rf>
   <form>FC</form>
   <lemma>FC-1_:B_;K_;w_^(Football_Club,_př._FC_Sparta)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln95048-084-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w21</w.rf>
   <form>Petra</form>
   <lemma>Petra_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w22</w.rf>
   <form>Drnovice</form>
   <lemma>Drnovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w24</w.rf>
   <form>generální</form>
   <lemma>generální</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w25</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w26</w.rf>
   <form>Chemapolu</form>
   <lemma>Chemapol_;K</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w27</w.rf>
   <form>Václav</form>
   <lemma>Václav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w28</w.rf>
   <form>Junek</form>
   <lemma>Junek_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s3w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s3w29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-084-p2s4">
  <m id="m-ln95048-084-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w1</w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w2</w.rf>
   <form>předsezónní</form>
   <lemma>předsezónní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w3</w.rf>
   <form>ambice</form>
   <lemma>ambice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w4</w.rf>
   <form>oddílu</form>
   <lemma>oddíl</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w5</w.rf>
   <form>vyústily</form>
   <lemma>vyústit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-084-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w6</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w7</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln95048-084-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95048-084-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w9</w.rf>
   <form>předposlední</form>
   <lemma>předposlední</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w10</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w11</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95048-084-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w12</w.rf>
   <form>podzimní</form>
   <lemma>podzimní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln95048-084-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w13</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w14</w.rf>
   <form>ligy</form>
   <lemma>liga</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95048-084-p2s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p2s4w15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-084-p3s1">
  <m id="m-ln95048-084-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p3s1w1</w.rf>
   <form>Žádné</form>
   <lemma>žádný</lemma>
   <tag>PWNS4----------</tag>
  </m>
  <m id="m-ln95048-084-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p3s1w2</w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln95048-084-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p3s1w3</w.rf>
   <form>zemětřesení</form>
   <lemma>zemětřesení</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95048-084-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p3s1w4</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln95048-084-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p3s1w5</w.rf>
   <form>ovšem</form>
   <lemma>ovšem-1_^(avšak,_však;_odporovací_spojka)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-084-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p3s1w6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95048-084-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p3s1w7</w.rf>
   <form>klubu</form>
   <lemma>klub</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln95048-084-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p3s1w8</w.rf>
   <form>nepřineslo</form>
   <lemma>přinést</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-ln95048-084-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-084-p3s1w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-21-p1s1">
  <m id="m-ln94211-21-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p1s1w1</w.rf>
   <form>Major</form>
   <lemma>Major_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94211-21-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p1s1w2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94211-21-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p1s1w3</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94211-21-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p1s1w4</w.rf>
   <form>pevnému</form>
   <lemma>pevný</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-ln94211-21-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p1s1w5</w.rf>
   <form>jádru</form>
   <lemma>jádro</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
 </s>
 <s id="m-ln94211-21-p2s1A">
  <m id="m-ln94211-21-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Aw1</w.rf>
   <form>Leiden</form>
   <lemma>Leiden_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-21-p2s1B">
  <m id="m-ln94211-21-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw1</w.rf>
   <form>Proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw2</w.rf>
   <form>ideji</form>
   <lemma>idea</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw3</w.rf>
   <form>dvourychlostní</form>
   <lemma>dvourychlostní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw4</w.rf>
   <form>Evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw5</w.rf>
   <form>unie</form>
   <lemma>unie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw7</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw8</w.rf>
   <form>vyslovil</form>
   <lemma>vyslovit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw9</w.rf>
   <form>britský</form>
   <lemma>britský</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw10</w.rf>
   <form>premiér</form>
   <lemma>premiér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw11</w.rf>
   <form>John</form>
   <lemma>John-2_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw12</w.rf>
   <form>Major</form>
   <lemma>Major_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s1Bw13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-21-p2s2">
  <m id="m-ln94211-21-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w1</w.rf>
   <form>Reagoval</form>
   <lemma>reagovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94211-21-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w2</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94211-21-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94211-21-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w4</w.rf>
   <form>výroky</form>
   <lemma>výrok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w5</w.rf>
   <form>německých</form>
   <lemma>německý</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94211-21-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w7</w.rf>
   <form>francouzských</form>
   <lemma>francouzský</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w8</w.rf>
   <form>politiků</form>
   <lemma>politik</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w9</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94211-21-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w10</w.rf>
   <form>potřebě</form>
   <lemma>potřeba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w11</w.rf>
   <form>vzniku</form>
   <lemma>vznik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w12</w.rf>
   <form>pevného</form>
   <lemma>pevný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w13</w.rf>
   <form>jádra</form>
   <lemma>jádro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w14</w.rf>
   <form>EU</form>
   <lemma>EU-1_:B_;K_;p_^(Evropská_Unie)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94211-21-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w15</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94211-21-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w16</w.rf>
   <form>ose</form>
   <lemma>osa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w17</w.rf>
   <form>Paříž</form>
   <lemma>Paříž_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-21-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w19</w.rf>
   <form>Bonn</form>
   <lemma>Bonn_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s2w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-21-p2s3">
  <m id="m-ln94211-21-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94211-21-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w2</w.rf>
   <form>Majora</form>
   <lemma>Major_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94211-21-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94211-21-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w5</w.rf>
   <form>pořádku</form>
   <lemma>pořádek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-21-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w7</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94211-21-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94211-21-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w9</w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZIP1----------</tag>
  </m>
  <m id="m-ln94211-21-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w10</w.rf>
   <form>státy</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w11</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94211-21-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w12</w.rf>
   <form>skupiny</form>
   <lemma>skupina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w13</w.rf>
   <form>států</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w14</w.rf>
   <form>dohodnou</form>
   <lemma>dohodnout_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94211-21-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94211-21-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w16</w.rf>
   <form>určitých</form>
   <lemma>určitý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-ln94211-21-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w17</w.rf>
   <form>oblastech</form>
   <lemma>oblast</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w18</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94211-21-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w19</w.rf>
   <form>rychlejší</form>
   <lemma>rychlý</lemma>
   <tag>AAFS6----2A----</tag>
  </m>
  <m id="m-ln94211-21-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w20</w.rf>
   <form>integraci</form>
   <lemma>integrace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w21</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94211-21-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w22</w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ln94211-21-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s3w23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-21-p2s4">
  <m id="m-ln94211-21-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s4w1</w.rf>
   <form>Všechny</form>
   <lemma>všechen</lemma>
   <tag>PLIP1----------</tag>
  </m>
  <m id="m-ln94211-21-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s4w2</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94211-21-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s4w3</w.rf>
   <form>musejí</form>
   <lemma>muset</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94211-21-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s4w4</w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94211-21-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s4w5</w.rf>
   <form>právo</form>
   <lemma>právo_^(právo_na_něco;_také_jako_obor)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s4w6</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-ln94211-21-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s4w7</w.rf>
   <form>vybrat</form>
   <lemma>vybrat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94211-21-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s4w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-21-p2s5">
  <m id="m-ln94211-21-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s5w1</w.rf>
   <form>Rozhodnout</form>
   <lemma>rozhodnout_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94211-21-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s5w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94211-21-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s5w3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94211-21-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s5w4</w.rf>
   <form>neúčasti</form>
   <lemma>neúčast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s5w5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94211-21-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s5w6</w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>ClFS1----------</tag>
  </m>
  <m id="m-ln94211-21-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s5w7</w.rf>
   <form>věc</form>
   <lemma>věc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s5w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-21-p2s6">
  <m id="m-ln94211-21-p2s6w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s6w1</w.rf>
   <form>Něco</form>
   <lemma>něco</lemma>
   <tag>PZ--1----------</tag>
  </m>
  <m id="m-ln94211-21-p2s6w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s6w2</w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94211-21-p2s6w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s6w3</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94211-21-p2s6w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s6w4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94211-21-p2s6w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s6w5</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94211-21-p2s6w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s6w6</w.rf>
   <form>možnosti</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94211-21-p2s6w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s6w7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94211-21-p2s6w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s6w8</w.rf>
   <form>účastnit</form>
   <lemma>účastnit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94211-21-p2s6w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s6w9</w.rf>
   <form>zbaven</form>
   <lemma>zbavit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ln94211-21-p2s6w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-21-p2s6w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-65-p1s1">
  <m id="m-ln94200-65-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p1s1w1</w.rf>
   <form>Ames</form>
   <lemma>Ames_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-65-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p1s1w2</w.rf>
   <form>našeho</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSMS4-P1-------</tag>
  </m>
  <m id="m-ln94200-65-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p1s1w3</w.rf>
   <form>agenta</form>
   <lemma>agent</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94200-65-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p1s1w4</w.rf>
   <form>KGB</form>
   <lemma>KGB_:B_;K_;p_^(Sov._státní_tajná_bezpečnost)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94200-65-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p1s1w5</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94200-65-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p1s1w6</w.rf>
   <form>nevydal</form>
   <lemma>vydat-2_:W_^(někomu_konkrétnímu:_př._zločince,_v._věc_zpět)</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
 </s>
 <s id="m-ln94200-65-p2s1A">
  <m id="m-ln94200-65-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-65-p2s1B">
  <m id="m-ln94200-65-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw1</w.rf>
   <form>Ministr</form>
   <lemma>ministr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw2</w.rf>
   <form>vnitra</form>
   <lemma>vnitro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw3</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw4</w.rf>
   <form>Ruml</form>
   <lemma>Ruml_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw5</w.rf>
   <form>nechce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw6</w.rf>
   <form>vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw7</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw8</w.rf>
   <form>probíhajícímu</form>
   <lemma>probíhající_^(*4t)</lemma>
   <tag>AGNS3-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw9</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw10</w.rf>
   <form>komentovat</form>
   <lemma>komentovat_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw11</w.rf>
   <form>tvrzení</form>
   <lemma>tvrzení_^(*4dit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw13</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw14</w.rf>
   <form>bývalý</form>
   <lemma>bývalý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw15</w.rf>
   <form>funkcionář</form>
   <lemma>funkcionář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw16</w.rf>
   <form>CIA</form>
   <lemma>CIA-1_:B_;K_;p_,t_^(Central_Intelligence_Agency,_USA)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw17</w.rf>
   <form>A</form>
   <lemma>A-0_:B_;Y</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw19</w.rf>
   <form>Ames</form>
   <lemma>Ames_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw21</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw22</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw23</w.rf>
   <form>přiznal</form>
   <lemma>přiznat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw24</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw25</w.rf>
   <form>dlouholeté</form>
   <lemma>dlouholetý</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw26</w.rf>
   <form>spolupráci</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw27</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw28</w.rf>
   <form>KGB</form>
   <lemma>KGB_:B_;K_;p_^(Sov._státní_tajná_bezpečnost)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw30</w.rf>
   <form>vydal</form>
   <lemma>vydat-2_:W_^(někomu_konkrétnímu:_př._zločince,_v._věc_zpět)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw31</w.rf>
   <form>Sovětům</form>
   <lemma>sovět-2_^(občan_SSSR)</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw32</w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>ClMS4----------</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw33</w.rf>
   <form>československého</form>
   <lemma>československý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw34</w.rf>
   <form>agenta</form>
   <lemma>agent</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw35</w.rf>
   <form>CIA</form>
   <lemma>CIA-1_:B_;K_;p_,t_^(Central_Intelligence_Agency,_USA)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94200-65-p2s1Bw36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s1Bw36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-65-p2s2">
  <m id="m-ln94200-65-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s2w1</w.rf>
   <form>Ames</form>
   <lemma>Ames_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s2w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94200-65-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s2w3</w.rf>
   <form>nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94200-65-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s2w4</w.rf>
   <form>nachází</form>
   <lemma>nacházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94200-65-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s2w5</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94200-65-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s2w6</w.rf>
   <form>vězení</form>
   <lemma>vězení_,a_^(místo_výkonu_trestu)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s2w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-65-p2s3">
  <m id="m-ln94200-65-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w1</w.rf>
   <form>Vydání</form>
   <lemma>vydání-2_^(někomu_konkrétnímu:_př._zločince,_v._věc_zpět)_(*5at-2)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w2</w.rf>
   <form>našeho</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSZS2-P1-------</tag>
  </m>
  <m id="m-ln94200-65-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w3</w.rf>
   <form>agenta</form>
   <lemma>agent</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w4</w.rf>
   <form>prý</form>
   <lemma>prý</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94200-65-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w5</w.rf>
   <form>naznačuje</form>
   <lemma>naznačovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94200-65-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w6</w.rf>
   <form>dopis</form>
   <lemma>dopis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w7</w.rf>
   <form>KGB</form>
   <lemma>KGB_:B_;K_;p_^(Sov._státní_tajná_bezpečnost)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94200-65-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w8</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94200-65-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w9</w.rf>
   <form>Amese</form>
   <lemma>Ames_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-65-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w11</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m-ln94200-65-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w12</w.rf>
   <form>zabavila</form>
   <lemma>zabavit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94200-65-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w13</w.rf>
   <form>americká</form>
   <lemma>americký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94200-65-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w14</w.rf>
   <form>FBI</form>
   <lemma>FBI_:B_;K</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94200-65-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s3w15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-65-p2s4">
  <m id="m-ln94200-65-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94200-65-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w2</w.rf>
   <form>ministerstva</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w3</w.rf>
   <form>vnitra</form>
   <lemma>vnitro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w4</w.rf>
   <form>Ames</form>
   <lemma>Ames_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w5</w.rf>
   <form>nepřišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ln94200-65-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94200-65-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w7</w.rf>
   <form>československými</form>
   <lemma>československý</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln94200-65-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w8</w.rf>
   <form>polistopadovými</form>
   <lemma>polistopadový</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln94200-65-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w9</w.rf>
   <form>tajnými</form>
   <lemma>tajný</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln94200-65-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w10</w.rf>
   <form>službami</form>
   <lemma>služba</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w11</w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94200-65-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w12</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94200-65-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w13</w.rf>
   <form>styku</form>
   <lemma>styk</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94200-65-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-65-p2s4w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
