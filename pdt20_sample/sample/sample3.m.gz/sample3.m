<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="sample3.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94205-34-p1s1">
  <m id="m-ln94205-34-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p1s1w1</w.rf>
   <form>Referendum</form>
   <lemma>referendum</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94205-34-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p1s1w2</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94205-34-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p1s1w3</w.rf>
   <form>léčka</form>
   <lemma>léčka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94205-34-p2s1A">
  <m id="m-ln94205-34-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s1Aw1</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s1Aw2</w.rf>
   <form>Dudek</form>
   <lemma>Dudek_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94205-34-p2s1B">
  <m id="m-ln94205-34-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s1Bw1</w.rf>
   <form>Bosenští</form>
   <lemma>bosenský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94205-34-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s1Bw2</w.rf>
   <form>Srbové</form>
   <lemma>Srb-4_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s1Bw3</w.rf>
   <form>učinili</form>
   <lemma>učinit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94205-34-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s1Bw4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-34-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s1Bw5</w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-ln94205-34-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s1Bw6</w.rf>
   <form>předem</form>
   <lemma>předem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-34-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s1Bw7</w.rf>
   <form>slibovali</form>
   <lemma>slibovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94205-34-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s1Bw8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-34-p2s2">
  <m id="m-ln94205-34-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-34-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w2</w.rf>
   <form>referendu</form>
   <lemma>referendum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w3</w.rf>
   <form>odmítli</form>
   <lemma>odmítnout_:W</lemma>
   <tag>VpMP---XR-AA--1</tag>
  </m>
  <m id="m-ln94205-34-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w4</w.rf>
   <form>navrhovanou</form>
   <lemma>navrhovaný_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94205-34-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w5</w.rf>
   <form>mapu</form>
   <lemma>mapa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w6</w.rf>
   <form>rozdělující</form>
   <lemma>rozdělující_^(*5ovat)</lemma>
   <tag>AGFS4-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w7</w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w8</w.rf>
   <form>Bosny</form>
   <lemma>Bosna_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-34-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w10</w.rf>
   <form>Hercegoviny</form>
   <lemma>Hercegovina_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s2w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-34-p2s3">
  <m id="m-ln94205-34-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w1</w.rf>
   <form>Před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94205-34-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w2</w.rf>
   <form>kontaktní</form>
   <lemma>kontaktní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94205-34-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w3</w.rf>
   <form>skupinou</form>
   <lemma>skupina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-34-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w5</w.rf>
   <form>spojující</form>
   <lemma>spojující_^(*5ovat)</lemma>
   <tag>AGFS7-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w6</w.rf>
   <form>čtveřici</form>
   <lemma>čtveřice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w7</w.rf>
   <form>západních</form>
   <lemma>západní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94205-34-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w8</w.rf>
   <form>velmocí</form>
   <lemma>velmoc</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-34-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w10</w.rf>
   <form>Rusko</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-34-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w12</w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-ln94205-34-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w13</w.rf>
   <form>pádem</form>
   <lemma>pád</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w14</w.rf>
   <form>stojí</form>
   <lemma>stát-3_^(někdo/něco_stojí,_např._na_nohou)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94205-34-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w15</w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-ln94205-34-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w16</w.rf>
   <form>možnosti</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94205-34-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p2s3w17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-34-p3s1">
  <m id="m-ln94205-34-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w1</w.rf>
   <form>Jednak</form>
   <lemma>jednak</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-34-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w2</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-34-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w3</w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w4</w.rf>
   <form>společenství</form>
   <lemma>společenství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w5</w.rf>
   <form>vyjít</form>
   <lemma>vyjít</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w6</w.rf>
   <form>vstříc</form>
   <lemma>vstříc</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94205-34-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w7</w.rf>
   <form>požadavkům</form>
   <lemma>požadavek</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w8</w.rf>
   <form>Radovana</form>
   <lemma>Radovan_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w9</w.rf>
   <form>Karadžiče</form>
   <form_change>spell</form_change>
   <lemma>Karadžič_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-34-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w11</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln94205-34-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w12</w.rf>
   <form>nacionalistické</form>
   <lemma>nacionalistický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w13</w.rf>
   <form>kliky</form>
   <lemma>klika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-34-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w15</w.rf>
   <form>začít</form>
   <lemma>začít-1</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w16</w.rf>
   <form>navrhovanou</form>
   <lemma>navrhovaný_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w17</w.rf>
   <form>mapu</form>
   <lemma>mapa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w18</w.rf>
   <form>překreslovat</form>
   <lemma>překreslovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w19</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-34-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-34-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w21</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94205-34-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w23</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w24</w.rf>
   <form>vyhovovala</form>
   <lemma>vyhovovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94205-34-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w25</w.rf>
   <form>poměrům</form>
   <lemma>poměry_^(stav,_uspořádání_věcí)</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w26</w.rf>
   <form>nastoleným</form>
   <lemma>nastolený_^(*3it)</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w27</w.rf>
   <form>vojenskou</form>
   <lemma>vojenský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w28</w.rf>
   <form>silou</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s1w29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-34-p3s2">
  <m id="m-ln94205-34-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w1</w.rf>
   <form>Jinými</form>
   <lemma>jiný</lemma>
   <tag>AANP7----1A----</tag>
  </m>
  <m id="m-ln94205-34-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w2</w.rf>
   <form>slovy</form>
   <lemma>slovo</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-34-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w4</w.rf>
   <form>odměnit</form>
   <lemma>odměnit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-34-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w5</w.rf>
   <form>bosenské</form>
   <lemma>bosenský</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-ln94205-34-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w6</w.rf>
   <form>Srby</form>
   <lemma>Srb-4_;E</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-34-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w8</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-ln94205-34-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w9</w.rf>
   <form>nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-34-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w10</w.rf>
   <form>ovládají</form>
   <lemma>ovládat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94205-34-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w11</w.rf>
   <form>sedmdesát</form>
   <lemma>sedmdesát`70</lemma>
   <tag>Cn-S4----------</tag>
  </m>
  <m id="m-ln94205-34-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w12</w.rf>
   <form>procent</form>
   <lemma>procento</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w13</w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-34-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w15</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94205-34-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w16</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-ln94205-34-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w17</w.rf>
   <form>agresi</form>
   <lemma>agrese</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94205-34-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-34-p3s2w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-20-p1s1">
  <m id="m-ln94202-20-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p1s1w1</w.rf>
   <form>Rusko</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94202-20-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p1s1w2</w.rf>
   <form>zve</form>
   <lemma>zvát</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-20-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p1s1w3</w.rf>
   <form>zahraniční</form>
   <lemma>zahraniční_,a</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-ln94202-20-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p1s1w4</w.rf>
   <form>investory</form>
   <lemma>investor</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
 </s>
 <s id="m-ln94202-20-p2s1A">
  <m id="m-ln94202-20-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Aw1</w.rf>
   <form>Premiérův</form>
   <lemma>premiérův_^(*2)</lemma>
   <tag>AUIS1M---------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Aw2</w.rf>
   <form>návrh</form>
   <lemma>návrh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Aw3</w.rf>
   <form>láme</form>
   <lemma>lámat</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-20-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Aw4</w.rf>
   <form>legislativu</form>
   <lemma>legislativa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Aw5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Aw6</w.rf>
   <form>tradiční</form>
   <lemma>tradiční</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Aw7</w.rf>
   <form>myšlení</form>
   <lemma>myšlení_^(*5slet)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Aw8</w.rf>
   <form>Rusů</form>
   <lemma>Rus_;E</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
 </s>
 <s id="m-ln94202-20-p2s1B">
  <m id="m-ln94202-20-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw1</w.rf>
   <form>Určitá</form>
   <lemma>určitý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw2</w.rf>
   <form>stabilizace</form>
   <lemma>stabilizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw3</w.rf>
   <form>hospodářského</form>
   <lemma>hospodářský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw4</w.rf>
   <form>života</form>
   <lemma>život</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw6</w.rf>
   <form>Rusku</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw8</w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw9</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw12</w.rf>
   <form>porovnání</form>
   <lemma>porovnání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw13</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw14</w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw15</w.rf>
   <form>neutěšenou</form>
   <lemma>utěšený_^(*3it)</lemma>
   <tag>AAFS7----1N----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw16</w.rf>
   <form>situací</form>
   <lemma>situace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw17</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw18</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--7----------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw19</w.rf>
   <form>málo</form>
   <lemma>málo-1_^(málo_+_2._p.,_málo_peněz)</lemma>
   <tag>Ca--7----------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw20</w.rf>
   <form>lety</form>
   <lemma>rok</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw22</w.rf>
   <form>zvětšuje</form>
   <lemma>zvětšovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw23</w.rf>
   <form>přitažlivost</form>
   <lemma>přitažlivost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw24</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw25</w.rf>
   <form>postkomunistické</form>
   <lemma>postkomunistický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw26</w.rf>
   <form>velmoci</form>
   <lemma>velmoc</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw27</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw28</w.rf>
   <form>zahraniční</form>
   <lemma>zahraniční_,a</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw29</w.rf>
   <form>investory</form>
   <lemma>investor</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s1Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s1Bw30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-20-p2s2">
  <m id="m-ln94202-20-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w1</w.rf>
   <form>Mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w2</w.rf>
   <form>měnový</form>
   <lemma>měnový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w3</w.rf>
   <form>fond</form>
   <lemma>fond</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w4</w.rf>
   <form>kladně</form>
   <lemma>kladně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w5</w.rf>
   <form>hodnotí</form>
   <lemma>hodnotit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-20-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w6</w.rf>
   <form>pokles</form>
   <lemma>pokles</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w7</w.rf>
   <form>inflace</form>
   <lemma>inflace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w9</w.rf>
   <form>zreálnění</form>
   <lemma>zreálnění_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w10</w.rf>
   <form>úrokových</form>
   <lemma>úrokový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w11</w.rf>
   <form>sazeb</form>
   <lemma>sazba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w13</w.rf>
   <form>postupující</form>
   <lemma>postupující_^(*5ovat)</lemma>
   <tag>AGFS4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w14</w.rf>
   <form>privatizaci</form>
   <lemma>privatizace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w16</w.rf>
   <form>restriktivní</form>
   <lemma>restriktivní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w17</w.rf>
   <form>politiku</form>
   <lemma>politika_^(věda)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w18</w.rf>
   <form>Černomyrdinovy</form>
   <lemma>Černomyrdinův_;S_^(*2)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w19</w.rf>
   <form>vlády</form>
   <lemma>vláda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w22</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w23</w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w25</w.rf>
   <form>dubnu</form>
   <lemma>duben</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w26</w.rf>
   <form>uvolnil</form>
   <lemma>uvolnit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-20-p2s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w27</w.rf>
   <form>Rusku</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w28</w.rf>
   <form>druhou</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w29</w.rf>
   <form>polovinu</form>
   <lemma>polovina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w30</w.rf>
   <form>slíbené</form>
   <lemma>slíbený_^(*3it)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w31</w.rf>
   <form>půjčky</form>
   <lemma>půjčka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w32</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w33</w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w34</w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>ClXP2----------</tag>
  </m>
  <m id="m-ln94202-20-p2s2w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w35</w.rf>
   <form>miliard</form>
   <lemma>miliarda`1000000000</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w36</w.rf>
   <form>dolarů</form>
   <lemma>dolar_;b</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s2w37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s2w37</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-20-p2s3">
  <m id="m-ln94202-20-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w1</w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-ln94202-20-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94202-20-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w3</w.rf>
   <form>otevřel</form>
   <lemma>otevřít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-20-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w4</w.rf>
   <form>kanál</form>
   <lemma>kanál</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-20-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w6</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94202-20-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w7</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w8</w.rf>
   <form>zahraniční</form>
   <lemma>zahraniční_,a</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w9</w.rf>
   <form>pomoci</form>
   <lemma>pomoc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w10</w.rf>
   <form>ruské</form>
   <lemma>ruský</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ln94202-20-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w11</w.rf>
   <form>ekonomice</form>
   <lemma>ekonomika</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94202-20-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-20-p2s3w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94210-37-p1s1">
  <m id="m-ln94210-37-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p1s1w1</w.rf>
   <form>Nová</form>
   <lemma>nový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94210-37-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p1s1w2</w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní_,a</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94210-37-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p1s1w3</w.rf>
   <form>pojišťovna</form>
   <lemma>pojišťovna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94210-37-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p1s1w4</w.rf>
   <form>upřednostňuje</form>
   <lemma>upřednostňovat_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94210-37-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p1s1w5</w.rf>
   <form>prevenci</form>
   <lemma>prevence</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
 </s>
 <s id="m-ln94210-37-p2s1A">
  <m id="m-ln94210-37-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Aw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Aw3</w.rf>
   <form>pech</form>
   <lemma>pech-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94210-37-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Aw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Aw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94210-37-p2s1B">
  <m id="m-ln94210-37-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw1</w.rf>
   <form>Prevence</form>
   <lemma>prevence</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw3</w.rf>
   <form>léčba</form>
   <lemma>léčba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw4</w.rf>
   <form>urgentních</form>
   <lemma>urgentní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw5</w.rf>
   <form>stavů</form>
   <lemma>stav</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw7</w.rf>
   <form>rekondiční</form>
   <lemma>rekondiční</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw8</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw9</w.rf>
   <form>rehabilitační</form>
   <lemma>rehabilitační</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw10</w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw11</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw12</w.rf>
   <form>základem</form>
   <lemma>základ</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw13</w.rf>
   <form>medicínského</form>
   <lemma>medicínský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw14</w.rf>
   <form>programu</form>
   <lemma>program-1</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw15</w.rf>
   <form>České</form>
   <lemma>český</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw16</w.rf>
   <form>národní</form>
   <lemma>národní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw17</w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní_,a</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw18</w.rf>
   <form>pojišťovny</form>
   <lemma>pojišťovna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw19</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw20</w.rf>
   <form>ČNZP</form>
   <lemma>ČNZP-1_:B_;K_^(Česká_národní_zdravotní_pojišťovna)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw21</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw23</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw24</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw25</w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw26</w.rf>
   <form>oficiálně</form>
   <lemma>oficiálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw27</w.rf>
   <form>zahájila</form>
   <lemma>zahájit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw28</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw29</w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s1Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s1Bw30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94210-37-p2s2">
  <m id="m-ln94210-37-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w1</w.rf>
   <form>Její</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSZS1FS3-------</tag>
  </m>
  <m id="m-ln94210-37-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w2</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w3</w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w4</w.rf>
   <form>Bek</form>
   <lemma>Bek_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w5</w.rf>
   <form>řekl</form>
   <lemma>říci_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94210-37-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w7</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w8</w.rf>
   <form>pojišťovna</form>
   <lemma>pojišťovna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w9</w.rf>
   <form>nabízí</form>
   <lemma>nabízet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94210-37-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w10</w.rf>
   <form>svým</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8XP3----------</tag>
  </m>
  <m id="m-ln94210-37-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w11</w.rf>
   <form>klientům</form>
   <lemma>klient</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w12</w.rf>
   <form>princip</form>
   <lemma>princip</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w13</w.rf>
   <form>individuálního</form>
   <lemma>individuální</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w14</w.rf>
   <form>účtu</form>
   <lemma>účet</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s2w15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94210-37-p2s3">
  <m id="m-ln94210-37-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s3w1</w.rf>
   <form>Vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s3w2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94210-37-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s3w3</w.rf>
   <form>lednu</form>
   <lemma>leden</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s3w4</w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PPXP3--3-------</tag>
  </m>
  <m id="m-ln94210-37-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s3w5</w.rf>
   <form>zašle</form>
   <lemma>zaslat</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94210-37-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s3w6</w.rf>
   <form>celkové</form>
   <lemma>celkový</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s3w7</w.rf>
   <form>vyúčtování</form>
   <lemma>vyúčtování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s3w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94210-37-p2s4">
  <m id="m-ln94210-37-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94210-37-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w2</w.rf>
   <form>Pavla</form>
   <lemma>Pavel-1_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w3</w.rf>
   <form>Zacha</form>
   <lemma>Zach_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w4</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94210-37-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w5</w.rf>
   <form>ČNZP</form>
   <lemma>ČNZP-1_:B_;K_^(Česká_národní_zdravotní_pojišťovna)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94210-37-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w6</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94210-37-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w7</w.rf>
   <form>prevenci</form>
   <lemma>prevence</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94210-37-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w9</w.rf>
   <form>svém</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS6----------</tag>
  </m>
  <m id="m-ln94210-37-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w10</w.rf>
   <form>programu</form>
   <lemma>program-1</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w11</w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m-ln94210-37-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w12</w.rf>
   <form>pojišťovny</form>
   <lemma>pojišťovna</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w14</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w15</w.rf>
   <form>málokdo</form>
   <lemma>málokdo</lemma>
   <tag>PZM-1----------</tag>
  </m>
  <m id="m-ln94210-37-p2s4w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94210-37-p2s4w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w17</w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w18</w.rf>
   <form>letech</form>
   <lemma>rok</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w19</w.rf>
   <form>absolvoval</form>
   <lemma>absolvovat_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94210-37-p2s4w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w20</w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w21</w.rf>
   <form>důkladné</form>
   <lemma>důkladný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w22</w.rf>
   <form>preventivní</form>
   <lemma>preventivní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w23</w.rf>
   <form>vyšetření</form>
   <lemma>vyšetření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s4w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s4w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94210-37-p2s5">
  <m id="m-ln94210-37-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w1</w.rf>
   <form>Přitom</form>
   <lemma>přitom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w2</w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94210-37-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w3</w.rf>
   <form>většinu</form>
   <lemma>většina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w4</w.rf>
   <form>zhoubných</form>
   <lemma>zhoubný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w5</w.rf>
   <form>nádorů</form>
   <lemma>nádor</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w6</w.rf>
   <form>lze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94210-37-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w7</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94210-37-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w8</w.rf>
   <form>včasném</form>
   <lemma>včasný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94210-37-p2s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w9</w.rf>
   <form>podchycení</form>
   <lemma>podchycení_^(*4tit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94210-37-p2s5w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w10</w.rf>
   <form>léčit</form>
   <lemma>léčit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94210-37-p2s5w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-37-p2s5w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-72-p1s1">
  <m id="m-ln94209-72-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p1s1w1</w.rf>
   <form>Talichovci</form>
   <lemma>Talichovec_;m</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p1s1w2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-72-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p1s1w3</w.rf>
   <form>Míčovně</form>
   <lemma>míčovna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
 </s>
 <s id="m-ln94209-72-p2s1A">
  <m id="m-ln94209-72-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Aw1</w.rf>
   <form>Recenze</form>
   <lemma>recenze</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94209-72-p2s1B">
  <m id="m-ln94209-72-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw1</w.rf>
   <form>HUDBA</form>
   <lemma>hudba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw3</w.rf>
   <form>Jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw4</w.rf>
   <form>Talich</form>
   <lemma>Talich_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw5</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw7</w.rf>
   <form>české</form>
   <lemma>český</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw8</w.rf>
   <form>hudební</form>
   <lemma>hudební</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw9</w.rf>
   <form>kultuře</form>
   <lemma>kultura</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw10</w.rf>
   <form>výsadní</form>
   <lemma>výsadní_,s</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw11</w.rf>
   <form>postavení</form>
   <lemma>postavení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s1Bw12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-72-p2s2">
  <m id="m-ln94209-72-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w1</w.rf>
   <form>Václav</form>
   <lemma>Václav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w2</w.rf>
   <form>Talich</form>
   <lemma>Talich_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w3</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94209-72-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w5</w.rf>
   <form>naší</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSFS6-P1-------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w6</w.rf>
   <form>historii</form>
   <lemma>historie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w7</w.rf>
   <form>podobnou</form>
   <lemma>podobný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w8</w.rf>
   <form>pozici</form>
   <lemma>pozice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w9</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w10</w.rf>
   <form>Arturo</form>
   <lemma>Arturo_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w11</w.rf>
   <form>Toscanini</form>
   <lemma>Toscanini_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w13</w.rf>
   <form>Itálii</form>
   <lemma>Itálie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w15</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w16</w.rf>
   <form>synovec</form>
   <lemma>synovec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w18</w.rf>
   <form>violista</form>
   <lemma>violista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w19</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w20</w.rf>
   <form>Talich</form>
   <lemma>Talich_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w22</w.rf>
   <form>založil</form>
   <lemma>založit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94209-72-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w23</w.rf>
   <form>slavné</form>
   <lemma>slavný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w24</w.rf>
   <form>Talichovo</form>
   <lemma>Talichův_;S_^(*2)</lemma>
   <tag>AUNS4M---------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w25</w.rf>
   <form>kvarteto</form>
   <lemma>kvarteto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w27</w.rf>
   <form>prasynovec</form>
   <lemma>prasynovec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w28</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w29</w.rf>
   <form>houslista</form>
   <lemma>houslista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w30</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w31</w.rf>
   <form>Talich</form>
   <lemma>Talich_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w32</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w33</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94209-72-p2s2w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w34</w.rf>
   <form>zakladatelem</form>
   <lemma>zakladatel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w35</w.rf>
   <form>ambiciózního</form>
   <lemma>ambiciózní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w36</w.rf>
   <form>mladého</form>
   <lemma>mladý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w37</w.rf>
   <form>souboru</form>
   <lemma>soubor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w38</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w39</w.rf>
   <form>Talichova</form>
   <lemma>Talichův_;S_^(*2)</lemma>
   <tag>AUIS2M---------</tag>
  </m>
  <m id="m-ln94209-72-p2s2w40">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w40</w.rf>
   <form>komorního</form>
   <lemma>komorní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w41">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w41</w.rf>
   <form>orchestru</form>
   <lemma>orchestr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94209-72-p2s2w42">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p2s2w42</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-72-p3s1">
  <m id="m-ln94209-72-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w1</w.rf>
   <form>Dramaturgie</form>
   <lemma>dramaturgie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w2</w.rf>
   <form>festivalu</form>
   <lemma>festival</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w3</w.rf>
   <form>Pocta</form>
   <lemma>pocta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w4</w.rf>
   <form>katedrále</form>
   <lemma>katedrála</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w5</w.rf>
   <form>pozvala</form>
   <lemma>pozvat</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94209-72-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94209-72-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w7</w.rf>
   <form>nádherného</form>
   <lemma>nádherný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w8</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w9</w.rf>
   <form>renesanční</form>
   <lemma>renesanční</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w10</w.rf>
   <form>Míčovny</form>
   <lemma>míčovna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w11</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-72-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w12</w.rf>
   <form>Pražském</form>
   <lemma>pražský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w13</w.rf>
   <form>hradě</form>
   <lemma>hrad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w14</w.rf>
   <form>Talichovce</form>
   <lemma>Talichovec_;m</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w15</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94209-72-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w16</w.rf>
   <form>repertoárem</form>
   <lemma>repertoár</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w17</w.rf>
   <form>krásným</form>
   <lemma>krásný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-72-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w19</w.rf>
   <form>efektním</form>
   <lemma>efektní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94209-72-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s1w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-72-p3s2">
  <m id="m-ln94209-72-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w1</w.rf>
   <form>Úvod</form>
   <lemma>úvod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w2</w.rf>
   <form>patřil</form>
   <lemma>patřit_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94209-72-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w3</w.rf>
   <form>Orchestrálnímu</form>
   <lemma>orchestrální</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w4</w.rf>
   <form>kvartetu</form>
   <lemma>kvarteto</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w5</w.rf>
   <form>G</form>
   <lemma>g-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w6</w.rf>
   <form>dur</form>
   <lemma>dur_^(typ_stupnice,_hudební)</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w7</w.rf>
   <form>prominentního</form>
   <lemma>prominentní</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w8</w.rf>
   <form>skladatele</form>
   <lemma>skladatel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w9</w.rf>
   <form>mannheimské</form>
   <lemma>mannheimský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w10</w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w11</w.rf>
   <form>Karla</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w12</w.rf>
   <form>Stamice</form>
   <lemma>Stamic_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94209-72-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-72-p3s2w13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-043-p2s1">
  <m id="m-cmpr9410-043-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p2s1w1</w.rf>
   <form>Slunce</form>
   <lemma>slunce</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p2s1w2</w.rf>
   <form>vyjde</form>
   <lemma>vyjít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-043-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p2s1w3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-043-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p2s1w4</w.rf>
   <form>Západě</form>
   <lemma>západ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p2s1w5</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-043-p3s1">
  <m id="m-cmpr9410-043-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p3s1w1</w.rf>
   <form>Profit</form>
   <lemma>profit</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p3s1w2</w.rf>
   <form>přemýšlí</form>
   <lemma>přemýšlet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-043-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p3s1w3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-043-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p3s1w4</w.rf>
   <form>důsledcích</form>
   <lemma>důsledek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p3s1w5</w.rf>
   <form>změn</form>
   <lemma>změna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p3s1w6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-043-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p3s1w7</w.rf>
   <form>evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p3s1w8</w.rf>
   <form>ekonomice</form>
   <lemma>ekonomika</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
 </s>
 <s id="m-cmpr9410-043-p4s1">
  <m id="m-cmpr9410-043-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w1</w.rf>
   <form>Zdá</form>
   <lemma>zdát</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w4</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w5</w.rf>
   <form>hlasy</form>
   <lemma>hlas</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w7</w.rf>
   <form>nepřeceňující</form>
   <lemma>přeceňující_^(*5ovat)</lemma>
   <tag>AGIP1-----N----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w8</w.rf>
   <form>vliv</form>
   <lemma>vliv</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w9</w.rf>
   <form>stavu</form>
   <lemma>stav</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w10</w.rf>
   <form>západoevropských</form>
   <lemma>západoevropský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w11</w.rf>
   <form>ekonomik</form>
   <lemma>ekonomika</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w13</w.rf>
   <form>ekonomiku</form>
   <lemma>ekonomika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w14</w.rf>
   <form>českou</form>
   <lemma>český</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w16</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w17</w.rf>
   <form>racionální</form>
   <lemma>racionální</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w18</w.rf>
   <form>jádro</form>
   <lemma>jádro</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w20</w.rf>
   <form>členy</form>
   <lemma>člen</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w21</w.rf>
   <form>Evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w22</w.rf>
   <form>unie</form>
   <lemma>unie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w23</w.rf>
   <form>nejsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-NA---</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w25</w.rf>
   <form>patrně</form>
   <lemma>patrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w26</w.rf>
   <form>ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w27</w.rf>
   <form>dlouho</form>
   <lemma>dlouho_^(o_čase;_př._dlouhá_doba)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w28</w.rf>
   <form>ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w29</w.rf>
   <form>nebudeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-NA---</tag>
  </m>
  <m id="m-cmpr9410-043-p4s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s1w30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-043-p4s2A">
  <m id="m-cmpr9410-043-p4s2Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw1</w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw2</w.rf>
   <form>míra</form>
   <lemma>míra_^(měřítko,poměr)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw3</w.rf>
   <form>exportního</form>
   <lemma>exportní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw4</w.rf>
   <form>výkonu</form>
   <lemma>výkon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw6</w.rf>
   <form>vztahující</form>
   <lemma>vztahující_^(*5ovat)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw7</w.rf>
   <form>objem</form>
   <lemma>objem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw8</w.rf>
   <form>vývozu</form>
   <lemma>vývoz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw10</w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>ClMS4----------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw11</w.rf>
   <form>obyvatele</form>
   <lemma>obyvatel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw13</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw14</w.rf>
   <form>žalostná</form>
   <lemma>žalostný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Aw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Aw15</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-043-p4s2B">
  <m id="m-cmpr9410-043-p4s2Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw1</w.rf>
   <form>Česká</form>
   <lemma>český</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw2</w.rf>
   <form>ekonomika</form>
   <lemma>ekonomika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw3</w.rf>
   <form>vloni</form>
   <lemma>vloni</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw4</w.rf>
   <form>vyvezla</form>
   <lemma>vyvézt</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw5</w.rf>
   <form>zboží</form>
   <lemma>zboží</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw6</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw7</w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw8</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-2`1000</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw9</w.rf>
   <form>dolarů</form>
   <lemma>dolar_;b</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw11</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw12</w.rf>
   <form>srovnatelné</form>
   <lemma>srovnatelný_^(*4)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw13</w.rf>
   <form>Portugalsko</form>
   <lemma>Portugalsko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw14</w.rf>
   <form>dvakrát</form>
   <lemma>dvakrát`2</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw16</w.rf>
   <form>Itálie</form>
   <lemma>Itálie_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw17</w.rf>
   <form>třikrát</form>
   <lemma>třikrát`3</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw19</w.rf>
   <form>Finsko</form>
   <lemma>Finsko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw20</w.rf>
   <form>pětkrát</form>
   <lemma>pětkrát`5</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw22</w.rf>
   <form>Rakousko</form>
   <lemma>Rakousko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw23</w.rf>
   <form>šestkrát</form>
   <lemma>šestkrát`6_^(*6`6)</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw25</w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw26</w.rf>
   <form>Beneluxu</form>
   <lemma>benelux</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw27</w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw28</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw29</w.rf>
   <form>dvanáctkrát</form>
   <lemma>dvanáctkrát`12_^(*7`12)</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw30</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-cmpr9410-043-p4s2Bw31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p4s2Bw31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-043-p6s1">
  <m id="m-cmpr9410-043-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p6s1w1</w.rf>
   <form>Jaroslav</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-043-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-043-p6s1w2</w.rf>
   <form>Šulc</form>
   <lemma>Šulc_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94209-75-p1s1">
  <m id="m-ln94209-75-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p1s1w1</w.rf>
   <form>Rakušané</form>
   <lemma>Rakušan_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p1s1w2</w.rf>
   <form>nezklamali</form>
   <lemma>zklamat</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
 </s>
 <s id="m-ln94209-75-p2s1A">
  <m id="m-ln94209-75-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Aw1</w.rf>
   <form>Recenze</form>
   <lemma>recenze</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94209-75-p2s1B">
  <m id="m-ln94209-75-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw1</w.rf>
   <form>HUDBA</form>
   <lemma>hudba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw3</w.rf>
   <form>Několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw4</w.rf>
   <form>ministrů</form>
   <lemma>ministr</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw6</w.rf>
   <form>řada</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw7</w.rf>
   <form>velvyslanců</form>
   <lemma>velvyslanec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw9</w.rf>
   <form>kulturních</form>
   <lemma>kulturní</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw10</w.rf>
   <form>radů</form>
   <lemma>rada-2_^(člověk;_např._soudní_rada)</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw12</w.rf>
   <form>vzorek</form>
   <lemma>vzorek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw13</w.rf>
   <form>prelátů</form>
   <lemma>prelát</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw15</w.rf>
   <form>šlechty</form>
   <lemma>šlechta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw18</w.rf>
   <form>neposlední</form>
   <lemma>poslední</lemma>
   <tag>AAFS6----1N----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw19</w.rf>
   <form>řadě</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw20</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw21</w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw22</w.rf>
   <form>Havlová</form>
   <lemma>Havlová_;S</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw23</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw24</w.rf>
   <form>ozdobou</form>
   <lemma>ozdoba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw25</w.rf>
   <form>slavnostního</form>
   <lemma>slavnostní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw26</w.rf>
   <form>zakončení</form>
   <lemma>zakončení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw27</w.rf>
   <form>festivalu</form>
   <lemma>festival</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw28</w.rf>
   <form>Pocta</form>
   <lemma>pocta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw29</w.rf>
   <form>katedrále</form>
   <lemma>katedrála</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s1Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s1Bw30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-75-p2s2">
  <m id="m-ln94209-75-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w1</w.rf>
   <form>Úspěšnou</form>
   <lemma>úspěšný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w2</w.rf>
   <form>tečku</form>
   <lemma>tečka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w3</w.rf>
   <form>skvěle</form>
   <lemma>skvěle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w4</w.rf>
   <form>připraveného</form>
   <lemma>připravený_^(*3it)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w5</w.rf>
   <form>festivalu</form>
   <lemma>festival</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w6</w.rf>
   <form>udělal</form>
   <lemma>udělat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94209-75-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w7</w.rf>
   <form>svým</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m-ln94209-75-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w8</w.rf>
   <form>vystoupením</form>
   <lemma>vystoupení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w9</w.rf>
   <form>Niederösterreichisches</form>
   <lemma>Niederösterreichisches_;K_,t</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w10</w.rf>
   <form>Tonkünstlerorchester</form>
   <lemma>Tonkünstlerorchester_;K_,t</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w12</w.rf>
   <form>jenž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>PJYS1----------</tag>
  </m>
  <m id="m-ln94209-75-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w13</w.rf>
   <form>působí</form>
   <lemma>působit_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94209-75-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w14</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94209-75-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w15</w.rf>
   <form>Vídni</form>
   <lemma>Vídeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w16</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-75-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w18</w.rf>
   <form>Dolním</form>
   <lemma>dolní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w19</w.rf>
   <form>Rakousku</form>
   <lemma>Rakousko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-75-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w22</w.rf>
   <form>dirigent</form>
   <lemma>dirigent</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w23</w.rf>
   <form>Alfred</form>
   <lemma>Alfréd_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w24</w.rf>
   <form>Eschwé</form>
   <lemma>Eschwé_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p2s2w25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-75-p3s1">
  <m id="m-ln94209-75-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w1</w.rf>
   <form>Úvodní</form>
   <lemma>úvodní_,s</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w2</w.rf>
   <form>číslo</form>
   <lemma>číslo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w3</w.rf>
   <form>koncertu</form>
   <lemma>koncert</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w5</w.rf>
   <form>předehru</form>
   <lemma>předehra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w6</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94209-75-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w7</w.rf>
   <form>opeře</form>
   <lemma>opera</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w8</w.rf>
   <form>Don</form>
   <lemma>don</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w9</w.rf>
   <form>Giovanni</form>
   <lemma>Giovanni_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w10</w.rf>
   <form>W</form>
   <lemma>W-0_:B_;Y</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-ln94209-75-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w12</w.rf>
   <form>A</form>
   <lemma>A-0_:B_;Y</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-ln94209-75-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w14</w.rf>
   <form>Mozarta</form>
   <lemma>Mozart_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w16</w.rf>
   <form>zahráli</form>
   <lemma>zahrát</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94209-75-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w17</w.rf>
   <form>Rakušané</form>
   <lemma>Rakušan_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w18</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94209-75-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w19</w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w21</w.rf>
   <form>hra</form>
   <lemma>hra_^(dětská;_v_divadle;...)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w22</w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94209-75-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w23</w.rf>
   <form>patřičný</form>
   <lemma>patřičný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w24</w.rf>
   <form>švih</form>
   <lemma>švih</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-75-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w26</w.rf>
   <form>barevnost</form>
   <lemma>barevnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w27</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-75-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w28</w.rf>
   <form>plasticitu</form>
   <lemma>plasticita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94209-75-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-75-p3s1w29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-25-p1s1">
  <m id="m-ln94206-25-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p1s1w1</w.rf>
   <form>Kolínská</form>
   <lemma>kolínský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94206-25-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p1s1w2</w.rf>
   <form>mlékárna</form>
   <lemma>mlékárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94206-25-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p1s1w3</w.rf>
   <form>nadále</form>
   <lemma>nadále</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-25-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p1s1w4</w.rf>
   <form>ztrátová</form>
   <lemma>ztrátový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
 </s>
 <s id="m-ln94206-25-p2s1A">
  <m id="m-ln94206-25-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Aw1</w.rf>
   <form>Místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-25-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Aw2</w.rf>
   <form>sušárny</form>
   <lemma>sušárna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Aw3</w.rf>
   <form>mléka</form>
   <lemma>mléko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Aw4</w.rf>
   <form>plánuje</form>
   <lemma>plánovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94206-25-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Aw5</w.rf>
   <form>podnik</form>
   <lemma>podnik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Aw6</w.rf>
   <form>zavedení</form>
   <lemma>zavedení_^(*5ést)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Aw7</w.rf>
   <form>efektivnější</form>
   <lemma>efektivní</lemma>
   <tag>AAFS2----2A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Aw8</w.rf>
   <form>výroby</form>
   <lemma>výroba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Aw9</w.rf>
   <form>sýrů</form>
   <lemma>sýr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
 </s>
 <s id="m-ln94206-25-p2s1B">
  <m id="m-ln94206-25-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Bw1</w.rf>
   <form>Kolín</form>
   <lemma>Kolín-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Bw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-25-p2s1C">
  <m id="m-ln94206-25-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw1</w.rf>
   <form>Až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw2</w.rf>
   <form>130</form>
   <lemma>130</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw3</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw4</w.rf>
   <form>litrů</form>
   <lemma>l-1`litr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw5</w.rf>
   <form>mléka</form>
   <lemma>mléko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw6</w.rf>
   <form>vykoupí</form>
   <lemma>vykoupit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw7</w.rf>
   <form>denně</form>
   <lemma>denně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw8</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw9</w.rf>
   <form>zemědělců</form>
   <lemma>zemědělec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw10</w.rf>
   <form>akciová</form>
   <lemma>akciový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw11</w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw12</w.rf>
   <form>Kolínská</form>
   <lemma>kolínský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw13</w.rf>
   <form>mlékárna</form>
   <lemma>mlékárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s1Cw14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-25-p2s2">
  <m id="m-ln94206-25-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-25-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w2</w.rf>
   <form>včerejší</form>
   <lemma>včerejší</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w3</w.rf>
   <form>informace</form>
   <lemma>informace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w4</w.rf>
   <form>výrobního</form>
   <lemma>výrobní</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w5</w.rf>
   <form>náměstka</form>
   <lemma>náměstek</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w6</w.rf>
   <form>Josefa</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w7</w.rf>
   <form>Knotka</form>
   <lemma>Knotek_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w8</w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94206-25-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w9</w.rf>
   <form>určeny</form>
   <lemma>určit</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-ln94206-25-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w10</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94206-25-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w11</w.rf>
   <form>domácí</form>
   <lemma>domácí</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w12</w.rf>
   <form>trh</form>
   <lemma>trh</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w13</w.rf>
   <form>výrobky</form>
   <lemma>výrobek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-25-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w15</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94206-25-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w16</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-ln94206-25-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w17</w.rf>
   <form>litrů</form>
   <lemma>l-1`litr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w18</w.rf>
   <form>mléka</form>
   <lemma>mléko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s2w19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-25-p2s3">
  <m id="m-ln94206-25-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w1</w.rf>
   <form>Ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ln94206-25-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w2</w.rf>
   <form>zbytku</form>
   <lemma>zbytek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w3</w.rf>
   <form>suroviny</form>
   <lemma>surovina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w4</w.rf>
   <form>mlékárna</form>
   <lemma>mlékárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w5</w.rf>
   <form>vyrábí</form>
   <lemma>vyrábět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94206-25-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w6</w.rf>
   <form>sušené</form>
   <lemma>sušený_^(*3it)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94206-25-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w7</w.rf>
   <form>mléko</form>
   <lemma>mléko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-25-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w9</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="m-ln94206-25-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w10</w.rf>
   <form>vyváží</form>
   <lemma>vyvážet_:T_^(zboží_přes_hranice)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94206-25-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-25-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w12</w.rf>
   <form>Asie</form>
   <lemma>Asie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94206-25-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w14</w.rf>
   <form>Jižní</form>
   <lemma>jižní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94206-25-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w15</w.rf>
   <form>Ameriky</form>
   <lemma>Amerika_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p2s3w16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-25-p3s1">
  <m id="m-ln94206-25-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94206-25-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w2</w.rf>
   <form>loňském</form>
   <lemma>loňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94206-25-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w3</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94206-25-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w4</w.rf>
   <form>dosáhla</form>
   <lemma>dosáhnout</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94206-25-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w5</w.rf>
   <form>firma</form>
   <lemma>firma</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94206-25-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w6</w.rf>
   <form>celkového</form>
   <lemma>celkový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94206-25-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w7</w.rf>
   <form>obratu</form>
   <lemma>obrat-1_^(z_prodeje_zboží)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w8</w.rf>
   <form>630</form>
   <lemma>630</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94206-25-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w9</w.rf>
   <form>milionů</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w10</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94206-25-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w12</w.rf>
   <form>hospodařila</form>
   <lemma>hospodařit_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94206-25-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w13</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94206-25-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w14</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-ln94206-25-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w15</w.rf>
   <form>ztrátou</form>
   <lemma>ztráta</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94206-25-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s1w16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94206-25-p3s2">
  <m id="m-ln94206-25-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s2w1</w.rf>
   <form>Způsobil</form>
   <lemma>způsobit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94206-25-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s2w2</w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PPFS4--3-------</tag>
  </m>
  <m id="m-ln94206-25-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s2w3</w.rf>
   <form>pokles</form>
   <lemma>pokles</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94206-25-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s2w4</w.rf>
   <form>cen</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s2w5</w.rf>
   <form>sušeného</form>
   <lemma>sušený_^(*3it)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94206-25-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s2w6</w.rf>
   <form>mléka</form>
   <lemma>mléko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94206-25-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s2w7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94206-25-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s2w8</w.rf>
   <form>světových</form>
   <lemma>světový</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-ln94206-25-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s2w9</w.rf>
   <form>trzích</form>
   <lemma>trh</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln94206-25-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94206-25-p3s2w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95045-110-p1s1">
  <m id="m-ln95045-110-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p1s1w1</w.rf>
   <form>TOP</form>
   <lemma>TOP_:B</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln95045-110-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p1s1w2</w.rf>
   <form>vytřídil</form>
   <lemma>vytřídit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95045-110-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p1s1w3</w.rf>
   <form>nejvýkonnější</form>
   <form_change>spell</form_change>
   <lemma>výkonný</lemma>
   <tag>AAFP4----3A----</tag>
  </m>
  <m id="m-ln95045-110-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p1s1w4</w.rf>
   <form>české</form>
   <lemma>český</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln95045-110-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p1s1w5</w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
 </s>
 <s id="m-ln95045-110-p2s1A">
  <m id="m-ln95045-110-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95045-110-p2s1B">
  <m id="m-ln95045-110-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw1</w.rf>
   <form>Žebříček</form>
   <lemma>žebříček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw2</w.rf>
   <form>nejvýkonnějších</form>
   <lemma>výkonný</lemma>
   <tag>AAFP2----3A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw3</w.rf>
   <form>českých</form>
   <lemma>český</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw4</w.rf>
   <form>firem</form>
   <lemma>firma</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw6</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw7</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw8</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw9</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw10</w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS7----------</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw11</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw12</w.rf>
   <form>základních</form>
   <lemma>základní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw13</w.rf>
   <form>zdrojů</form>
   <lemma>zdroj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw14</w.rf>
   <form>informací</form>
   <lemma>informace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw15</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw16</w.rf>
   <form>rozhodování</form>
   <lemma>rozhodování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw17</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw18</w.rf>
   <form>investování</form>
   <lemma>investování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw19</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw20</w.rf>
   <form>směrech</form>
   <lemma>směr</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw21</w.rf>
   <form>depozitní</form>
   <lemma>depozitní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw22</w.rf>
   <form>politiky</form>
   <lemma>politika_^(věda)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw23</w.rf>
   <form>významných</form>
   <lemma>významný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw24</w.rf>
   <form>peněžních</form>
   <lemma>peněžní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw25</w.rf>
   <form>ústavů</form>
   <lemma>ústav</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw27</w.rf>
   <form>připravuje</form>
   <lemma>připravovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw28</w.rf>
   <form>Sdružení</form>
   <lemma>sdružení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw29</w.rf>
   <form>Czech</form>
   <lemma>Czech-2_,t</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw30</w.rf>
   <form>Top</form>
   <lemma>Top_;K_,t</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw31</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95045-110-p2s1Bw32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s1Bw32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95045-110-p2s2">
  <m id="m-ln95045-110-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w1</w.rf>
   <form>Vyplývá</form>
   <lemma>vyplývat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95045-110-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln95045-110-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95045-110-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w4</w.rf>
   <form>rozhovoru</form>
   <lemma>rozhovor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w5</w.rf>
   <form>iniciátora</form>
   <lemma>iniciátor-1</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w6</w.rf>
   <form>projektu</form>
   <lemma>projekt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-110-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w8</w.rf>
   <form>generálního</form>
   <lemma>generální</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w9</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w10</w.rf>
   <form>pražské</form>
   <lemma>pražský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w11</w.rf>
   <form>pobočky</form>
   <lemma>pobočka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w12</w.rf>
   <form>ING</form>
   <lemma>ING_:B_;K_^(banka)</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-ln95045-110-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w13</w.rf>
   <form>Bank</form>
   <lemma>Bank-1_;K_,t_^(v_cizojaz._názvech_bank)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w14</w.rf>
   <form>Jana</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w15</w.rf>
   <form>Struže</form>
   <lemma>Struž_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-110-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w17</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95045-110-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w18</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95045-110-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-110-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w20</w.rf>
   <form>číslo</form>
   <lemma>číslo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w21</w.rf>
   <form>Českomoravského</form>
   <lemma>českomoravský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w22</w.rf>
   <form>Profitu</form>
   <lemma>profit</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p2s2w23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95045-110-p3s1">
  <m id="m-ln95045-110-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w2</w.rf>
   <form>sběru</form>
   <lemma>sběr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w4</w.rf>
   <form>zpracování</form>
   <lemma>zpracování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w5</w.rf>
   <form>dat</form>
   <lemma>data_^(údaje,_např._v_databázi)</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w6</w.rf>
   <form>sdružení</form>
   <lemma>sdružení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w7</w.rf>
   <form>vychází</form>
   <lemma>vycházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95045-110-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w9</w.rf>
   <form>auditovaných</form>
   <lemma>auditovaný_^(*2t)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w11</w.rf>
   <form>oficiálně</form>
   <lemma>oficiálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w12</w.rf>
   <form>publikovaných</form>
   <lemma>publikovaný_^(*2t)</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w13</w.rf>
   <form>čísel</form>
   <lemma>číslo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w15</w.rf>
   <form>databázích</form>
   <lemma>databáze</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w16</w.rf>
   <form>Střediska</form>
   <lemma>středisko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w17</w.rf>
   <form>cenných</form>
   <lemma>cenný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w18</w.rf>
   <form>papírů</form>
   <lemma>papír</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w20</w.rf>
   <form>pražské</form>
   <lemma>pražský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w21</w.rf>
   <form>burzy</form>
   <lemma>burza</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w23</w.rf>
   <form>Podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w24</w.rf>
   <form>výpočetní</form>
   <lemma>výpočetní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w25</w.rf>
   <form>techniky</form>
   <lemma>technika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w27</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w28</w.rf>
   <form>Obchodního</form>
   <lemma>obchodní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w29</w.rf>
   <form>věstníku</form>
   <lemma>věstník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w30</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w31</w.rf>
   <form>rozhovorů</form>
   <lemma>rozhovor</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w32</w.rf>
   <form>přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w33</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95045-110-p3s1w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w34</w.rf>
   <form>podnicích</form>
   <lemma>podnik</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln95045-110-p3s1w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-110-p3s1w35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-041-p2s1">
  <m id="m-cmpr9415-041-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p2s1w1</w.rf>
   <form>Těžké</form>
   <lemma>těžký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p2s1w2</w.rf>
   <form>zlehčování</form>
   <lemma>zlehčování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-cmpr9415-041-p3s1">
  <m id="m-cmpr9415-041-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w1</w.rf>
   <form>Bezkonkurenčně</form>
   <lemma>bezkonkurenčně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w2</w.rf>
   <form>nejlevnější</form>
   <lemma>levný</lemma>
   <tag>AAFP4----3A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w3</w.rf>
   <form>ceny</form>
   <lemma>cena-1_^(v_penězích,_naturální,_nevyčíslitelná,...)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w4</w.rf>
   <form>najdete</form>
   <lemma>najít</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w5</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w6</w.rf>
   <form>nás</form>
   <lemma>já</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w8</w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w9</w.rf>
   <form>kvalita</form>
   <lemma>kvalita</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w11</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w12</w.rf>
   <form>jedině</form>
   <lemma>jedině_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w13</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w14</w.rf>
   <form>nás</form>
   <lemma>já</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w16</w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w17</w.rf>
   <form>největší</form>
   <lemma>velký</lemma>
   <tag>AAFS4----3A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w18</w.rf>
   <form>tradici</form>
   <lemma>tradice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w20</w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w22</w.rf>
   <form>laciněji</form>
   <lemma>lacino-1</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w23</w.rf>
   <form>nakoupíte</form>
   <lemma>nakoupit_:W</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w24</w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w25</w.rf>
   <form>nás</form>
   <lemma>já</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s1w26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-041-p3s2">
  <m id="m-cmpr9415-041-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w1</w.rf>
   <form>Takové</form>
   <lemma>takový</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w3</w.rf>
   <form>podobné</form>
   <lemma>podobný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w4</w.rf>
   <form>slogany</form>
   <lemma>slogan</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w6</w.rf>
   <form>upoutávky</form>
   <lemma>upoutávka_^(reklama)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w8</w.rf>
   <form>texty</form>
   <lemma>text</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w9</w.rf>
   <form>inzerátů</form>
   <lemma>inzerát</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w10</w.rf>
   <form>můžete</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w11</w.rf>
   <form>číst</form>
   <lemma>číst</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w12</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w13</w.rf>
   <form>denně</form>
   <lemma>denně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s2w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-041-p3s3">
  <m id="m-cmpr9415-041-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w1</w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w2</w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w3</w.rf>
   <form>vypěstovaný</form>
   <lemma>vypěstovaný_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w4</w.rf>
   <form>určitý</form>
   <lemma>určitý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w5</w.rf>
   <form>obranný</form>
   <lemma>obranný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w6</w.rf>
   <form>reflex</form>
   <lemma>reflex</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w7</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w8</w.rf>
   <form>superlativům</form>
   <lemma>superlativ</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w10</w.rf>
   <form>sebechvále</form>
   <lemma>sebechvála</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w12</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w13</w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w14</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w15</w.rf>
   <form>takovému</form>
   <lemma>takový</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w16</w.rf>
   <form>obsahu</form>
   <lemma>obsah</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w17</w.rf>
   <form>částečně</form>
   <lemma>částečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w18</w.rf>
   <form>imunní</form>
   <lemma>imunní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s3w19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-041-p3s4">
  <m id="m-cmpr9415-041-p3s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w1</w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w2</w.rf>
   <form>ovšem</form>
   <lemma>ovšem-1_^(avšak,_však;_odporovací_spojka)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w3</w.rf>
   <form>nemohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-NA--1</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w4</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w5</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w6</w.rf>
   <form>podnikatelé</form>
   <lemma>podnikatel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w8</w.rf>
   <form>oboru</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w10</w.rf>
   <form>neboť</form>
   <lemma>neboť</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w12</w.rf>
   <form>takových</form>
   <lemma>takový</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w13</w.rf>
   <form>případech</form>
   <lemma>případ</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w14</w.rf>
   <form>dochází</form>
   <lemma>docházet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w15</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w16</w.rf>
   <form>porušování</form>
   <lemma>porušování_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w17</w.rf>
   <form>obchodního</form>
   <lemma>obchodní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w18</w.rf>
   <form>zákoníku</form>
   <lemma>zákoník-2_^(předpis)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9415-041-p3s4w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9415-041-p3s4w19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
