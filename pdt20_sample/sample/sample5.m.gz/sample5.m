<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="sample5.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94205-104-p1s1">
  <m id="m-ln94205-104-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p1s1w1</w.rf>
   <form>Dny</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94205-104-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p1s1w2</w.rf>
   <form>americké</form>
   <lemma>americký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94205-104-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p1s1w3</w.rf>
   <form>kultury</form>
   <lemma>kultura</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-104-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p1s1w4</w.rf>
   <form>otevře</form>
   <lemma>otevřít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-104-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p1s1w5</w.rf>
   <form>etnologie</form>
   <lemma>etnologie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94205-104-p2s1">
  <m id="m-ln94205-104-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w1</w.rf>
   <form>Slavnostním</form>
   <lemma>slavnostní</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w2</w.rf>
   <form>zahájením</form>
   <lemma>zahájení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w3</w.rf>
   <form>expozice</form>
   <lemma>expozice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w4</w.rf>
   <form>Kouzlo</form>
   <lemma>kouzlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w5</w.rf>
   <form>dřeva</form>
   <lemma>dřevo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w6</w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-104-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w8</w.rf>
   <form>libereckém</form>
   <lemma>liberecký</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w9</w.rf>
   <form>Severočeském</form>
   <lemma>severočeský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w10</w.rf>
   <form>muzeu</form>
   <lemma>muzeum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w11</w.rf>
   <form>začínají</form>
   <lemma>začínat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94205-104-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w12</w.rf>
   <form>Dny</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w13</w.rf>
   <form>americké</form>
   <lemma>americký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w14</w.rf>
   <form>kultury</form>
   <lemma>kultura</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s1w15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-104-p2s2">
  <m id="m-ln94205-104-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w1</w.rf>
   <form>Zúčastní</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-104-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94205-104-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w3</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS2--3-------</tag>
  </m>
  <m id="m-ln94205-104-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w5</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w6</w.rf>
   <form>Schenka</form>
   <lemma>Schenka_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94205-104-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w8</w.rf>
   <form>Muzea</form>
   <lemma>muzeum</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w9</w.rf>
   <form>umění</form>
   <lemma>umění_^(mít_schopnost_něco_dělat)_(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w10</w.rf>
   <form>Jihu</form>
   <lemma>jih</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94205-104-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w12</w.rf>
   <form>Mobile</form>
   <lemma>Mobile_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-104-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w14</w.rf>
   <form>Alabamě</form>
   <lemma>Alabama_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w16</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-ln94205-104-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w17</w.rf>
   <form>putovní</form>
   <lemma>putovní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w18</w.rf>
   <form>výstavu</form>
   <lemma>výstava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w19</w.rf>
   <form>připravilo</form>
   <lemma>připravit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94205-104-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s2w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-104-p2s3">
  <m id="m-ln94205-104-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w1</w.rf>
   <form>Jedná</form>
   <lemma>jednat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-104-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94205-104-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94205-104-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w4</w.rf>
   <form>dřevěné</form>
   <lemma>dřevěný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w5</w.rf>
   <form>nádoby</form>
   <lemma>nádoba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w7</w.rf>
   <form>figurky</form>
   <lemma>figurka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w9</w.rf>
   <form>vázy</form>
   <lemma>váza_^(na_květiny)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w11</w.rf>
   <form>mísy</form>
   <lemma>mísa</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w13</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-104-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w14</w.rf>
   <form>jejichž</form>
   <lemma>jenž_^(který...[ve_vedl._větě])</lemma>
   <tag>P1XXXXP3-------</tag>
  </m>
  <m id="m-ln94205-104-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w15</w.rf>
   <form>tvorbě</form>
   <lemma>tvorba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w16</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94205-104-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w17</w.rf>
   <form>nechali</form>
   <lemma>nechat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94205-104-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w18</w.rf>
   <form>američtí</form>
   <lemma>americký</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w19</w.rf>
   <form>tvůrci</form>
   <lemma>tvůrce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w20</w.rf>
   <form>inspirovat</form>
   <lemma>inspirovat_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w21</w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w22</w.rf>
   <form>tradičními</form>
   <lemma>tradiční</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w23</w.rf>
   <form>indiánskými</form>
   <lemma>indiánský</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w24</w.rf>
   <form>technikami</form>
   <lemma>technika</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s3w25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-104-p2s4">
  <m id="m-ln94205-104-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s4w1</w.rf>
   <form>Obdivuhodná</form>
   <lemma>obdivuhodný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s4w2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94205-104-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s4w3</w.rf>
   <form>už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s4w4</w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m-ln94205-104-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s4w5</w.rf>
   <form>struktura</form>
   <lemma>struktura</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s4w6</w.rf>
   <form>dřeva</form>
   <lemma>dřevo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s4w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94205-104-p2s5">
  <m id="m-ln94205-104-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w1</w.rf>
   <form>Umělci</form>
   <lemma>umělec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w2</w.rf>
   <form>pracovali</form>
   <lemma>pracovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94205-104-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w3</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94205-104-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w4</w.rf>
   <form>ebenem</form>
   <lemma>eben</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w6</w.rf>
   <form>sekvojí</form>
   <lemma>sekvoje</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w8</w.rf>
   <form>jinými</form>
   <lemma>jiný</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w9</w.rf>
   <form>tropickými</form>
   <lemma>tropický</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w10</w.rf>
   <form>dřevinami</form>
   <lemma>dřevina</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94205-104-p2s5w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w12</w.rf>
   <form>řekl</form>
   <lemma>říci_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94205-104-p2s5w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w13</w.rf>
   <form>LN</form>
   <lemma>LN-1_:B_;R_^(Lidové_noviny,_deník)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-ln94205-104-p2s5w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w14</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w15</w.rf>
   <form>Severočeského</form>
   <lemma>severočeský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w16</w.rf>
   <form>muzea</form>
   <lemma>muzeum</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94205-104-p2s5w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w18</w.rf>
   <form>Liberci</form>
   <lemma>Liberec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w19</w.rf>
   <form>Alois</form>
   <lemma>Alois_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w20</w.rf>
   <form>Čvančara</form>
   <lemma>čvančara_,e</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94205-104-p2s5w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94205-104-p2s5w21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-116-p1s1">
  <m id="m-mf920922-116-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p1s1w1</w.rf>
   <form>Evropa</form>
   <lemma>Evropa_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-116-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p1s1w2</w.rf>
   <form>nabízí</form>
   <lemma>nabízet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-116-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p1s1w3</w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-mf920922-116-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p1s1w4</w.rf>
   <form>jistoty</form>
   <lemma>jistota</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf920922-116-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p1s1w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-116-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p1s1w6</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-mf920922-116-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p1s1w7</w.rf>
   <form>věrohodnost</form>
   <lemma>věrohodnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-116-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p1s1w8</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-116-p1s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p1s1w9</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920922-116-p1s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p1s1w10</w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
 </s>
 <s id="m-mf920922-116-p2s1">
  <m id="m-mf920922-116-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p2s1w1</w.rf>
   <form>komentáře</form>
   <lemma>komentář</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
 </s>
 <s id="m-mf920922-116-p3s1A">
  <m id="m-mf920922-116-p3s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Aw1</w.rf>
   <form>Evropa</form>
   <lemma>Evropa_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-116-p3s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Aw2</w.rf>
   <form>nabízí</form>
   <lemma>nabízet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-116-p3s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Aw3</w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-mf920922-116-p3s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Aw4</w.rf>
   <form>jistoty</form>
   <lemma>jistota</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf920922-116-p3s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Aw5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-116-p3s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Aw6</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-mf920922-116-p3s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Aw7</w.rf>
   <form>věrohodnost</form>
   <lemma>věrohodnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-116-p3s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Aw8</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-116-p3s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Aw9</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920922-116-p3s1Aw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Aw10</w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
 </s>
 <s id="m-mf920922-116-p3s1B">
  <m id="m-mf920922-116-p3s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Bw1</w.rf>
   <form>STOJÍME</form>
   <lemma>stát-3_^(někdo/něco_stojí,_např._na_nohou)</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-mf920922-116-p3s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Bw2</w.rf>
   <form>NA</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920922-116-p3s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Bw3</w.rf>
   <form>HISTORICKÉM</form>
   <lemma>historický</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf920922-116-p3s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p3s1Bw4</w.rf>
   <form>ROZHRANÍ</form>
   <lemma>rozhraní</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
 </s>
 <s id="m-mf920922-116-p4s1">
  <m id="m-mf920922-116-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w1</w.rf>
   <form>Pohled</form>
   <lemma>pohled</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w2</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920922-116-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w3</w.rf>
   <form>výsledky</form>
   <lemma>výsledek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w4</w.rf>
   <form>nedělního</form>
   <lemma>nedělní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w5</w.rf>
   <form>francouzského</form>
   <lemma>francouzský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w6</w.rf>
   <form>referenda</form>
   <lemma>referendum</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w7</w.rf>
   <form>nechtěně</form>
   <lemma>chtěně_^(*3ít)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-mf920922-116-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w8</w.rf>
   <form>vyvolává</form>
   <lemma>vyvolávat_:T_^(*4at)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-116-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w9</w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920922-116-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w11</w.rf>
   <form>léta</form>
   <lemma>rok</lemma>
   <tag>NNNP4-----A---2</tag>
  </m>
  <m id="m-mf920922-116-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w12</w.rf>
   <form>studené</form>
   <lemma>studený</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w13</w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s1w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-116-p4s2">
  <m id="m-mf920922-116-p4s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w1</w.rf>
   <form>Stála</form>
   <lemma>stát-4_^(něco_stojí_peníze)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf920922-116-p4s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w2</w.rf>
   <form>miliardy</form>
   <lemma>miliarda`1000000000</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w3</w.rf>
   <form>dolarů</form>
   <lemma>dolar_;b</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w5</w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-mf920922-116-p4s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w6</w.rf>
   <form>založena</form>
   <lemma>založit_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-mf920922-116-p4s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w8</w.rf>
   <form>žádném</form>
   <lemma>žádný</lemma>
   <tag>PWZS6----------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w9</w.rf>
   <form>racionálním</form>
   <lemma>racionální</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w10</w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w12</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w13</w.rf>
   <form>vzešlo</form>
   <lemma>vzejít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-mf920922-116-p4s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w15</w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>P5FS2--3-------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w16</w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PZ--1----------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w18</w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w19</w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920922-116-p4s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w20</w.rf>
   <form>postrádáme</form>
   <lemma>postrádat_:T</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-mf920922-116-p4s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s2w21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-116-p4s3">
  <m id="m-mf920922-116-p4s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s3w1</w.rf>
   <form>Sice</form>
   <lemma>sice_^(spojka/příslovce;_připouští_se_určitá_fakta)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920922-116-p4s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s3w2</w.rf>
   <form>rozdělená</form>
   <lemma>rozdělený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s3w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-116-p4s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s3w4</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920922-116-p4s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s3w5</w.rf>
   <form>klidná</form>
   <lemma>klidný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s3w6</w.rf>
   <form>Evropa</form>
   <lemma>Evropa_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s3w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-116-p4s4">
  <m id="m-mf920922-116-p4s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w1</w.rf>
   <form>Krach</form>
   <lemma>krach</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w2</w.rf>
   <form>komunistického</form>
   <lemma>komunistický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w3</w.rf>
   <form>systému</form>
   <lemma>systém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-116-p4s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w5</w.rf>
   <form>následný</form>
   <lemma>následný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w6</w.rf>
   <form>demokratizační</form>
   <lemma>demokratizační</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w7</w.rf>
   <form>proces</form>
   <lemma>proces</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-mf920922-116-p4s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w9</w.rf>
   <form>východoevropských</form>
   <lemma>východoevropský</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w10</w.rf>
   <form>zemích</form>
   <lemma>země</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w11</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920922-116-p4s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w12</w.rf>
   <form>složitě</form>
   <lemma>složitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w13</w.rf>
   <form>pokračující</form>
   <lemma>pokračující_^(*5ovat)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w14</w.rf>
   <form>integrace</form>
   <lemma>integrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w15</w.rf>
   <form>západní</form>
   <lemma>západní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w16</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w17</w.rf>
   <form>kontinentu</form>
   <lemma>kontinent</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w18</w.rf>
   <form>nám</form>
   <lemma>já</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m-mf920922-116-p4s4w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w19</w.rf>
   <form>představují</form>
   <lemma>představovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf920922-116-p4s4w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w20</w.rf>
   <form>Evropu</form>
   <lemma>Evropa_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w21</w.rf>
   <form>novou</form>
   <lemma>nový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-mf920922-116-p4s4w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-116-p4s4w22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-131-p1s1">
  <m id="m-ln94202-131-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p1s1w1</w.rf>
   <form>Přepravci</form>
   <lemma>přepravce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94202-131-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p1s1w2</w.rf>
   <form>nebezpečných</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFP2----1N----</tag>
  </m>
  <m id="m-ln94202-131-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p1s1w3</w.rf>
   <form>látek</form>
   <form_change>spell</form_change>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p1s1w3</w.rf>
   <form>od</form>
   <form_change>spell</form_change>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-131-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p1s1w5</w.rf>
   <form>srpna</form>
   <lemma>srpen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p1s1w6</w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94202-131-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p1s1w7</w.rf>
   <form>zostřeným</form>
   <lemma>zostřený_^(*3it)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94202-131-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p1s1w8</w.rf>
   <form>dohledem</form>
   <lemma>dohled</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
 </s>
 <s id="m-ln94202-131-p2s1A">
  <m id="m-ln94202-131-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Aw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-131-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Aw3</w.rf>
   <form>mrk</form>
   <lemma>mrk-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94202-131-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Aw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-131-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Aw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-131-p2s1B">
  <m id="m-ln94202-131-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw1</w.rf>
   <form>Zvýšit</form>
   <lemma>zvýšit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw2</w.rf>
   <form>bezpečnost</form>
   <lemma>bezpečnost-1_^(*5ý-1)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw3</w.rf>
   <form>přepravy</form>
   <lemma>přeprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw4</w.rf>
   <form>nebezpečných</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFP2----1N----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw5</w.rf>
   <form>látek</form>
   <lemma>látka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw6</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw7</w.rf>
   <form>cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw8</w.rf>
   <form>prováděcí</form>
   <lemma>prováděcí_^(^IC**provádět)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw9</w.rf>
   <form>vyhlášky</form>
   <lemma>vyhláška</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw10</w.rf>
   <form>ministerstva</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw11</w.rf>
   <form>dopravy</form>
   <lemma>doprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw13</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw14</w.rf>
   <form>nabyla</form>
   <lemma>nabýt</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw15</w.rf>
   <form>platnosti</form>
   <lemma>platnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw16</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw18</w.rf>
   <form>srpna</form>
   <lemma>srpen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw19</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw20</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw21</w.rf>
   <form>současně</form>
   <lemma>současně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw22</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw23</w.rf>
   <form>novým</form>
   <lemma>nový</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw24</w.rf>
   <form>zákonem</form>
   <lemma>zákon</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw25</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw26</w.rf>
   <form>silniční</form>
   <lemma>silniční</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw27</w.rf>
   <form>přepravě</form>
   <lemma>přeprava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94202-131-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p2s1Bw28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-131-p3s1">
  <m id="m-ln94202-131-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w1</w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w2</w.rf>
   <form>LN</form>
   <lemma>LN-1_:B_;R_^(Lidové_noviny,_deník)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-ln94202-131-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w3</w.rf>
   <form>informoval</form>
   <lemma>informovat_:T_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-131-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w4</w.rf>
   <form>Jaroslav</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w5</w.rf>
   <form>Opletal</form>
   <lemma>Opletal_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w6</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w7</w.rf>
   <form>silničního</form>
   <lemma>silniční</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w8</w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w9</w.rf>
   <form>ministerstva</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w10</w.rf>
   <form>dopravy</form>
   <lemma>doprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w12</w.rf>
   <form>touto</form>
   <lemma>tento</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w13</w.rf>
   <form>vyhláškou</form>
   <lemma>vyhláška</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w14</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w15</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w16</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94202-131-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w17</w.rf>
   <form>zavádí</form>
   <lemma>zavádět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-131-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w18</w.rf>
   <form>platnost</form>
   <lemma>platnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w19</w.rf>
   <form>ustanovení</form>
   <lemma>ustanovení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w20</w.rf>
   <form>Evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w21</w.rf>
   <form>dohody</form>
   <lemma>dohoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w22</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w23</w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w24</w.rf>
   <form>silniční</form>
   <lemma>silniční</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w25</w.rf>
   <form>přepravě</form>
   <lemma>přeprava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w26</w.rf>
   <form>nebezpečných</form>
   <lemma>bezpečný-1</lemma>
   <tag>AAFP2----1N----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w27</w.rf>
   <form>věcí</form>
   <lemma>věc</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w28</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w29</w.rf>
   <form>ADR</form>
   <lemma>ADR-1_:B_;K_,t_^(Mezin._úmluva_o_přepravě_nebezp._zboží)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94202-131-p3s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w30</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w31</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w32</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-131-p3s1w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w33</w.rf>
   <form>vnitrostátní</form>
   <lemma>vnitrostátní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w34</w.rf>
   <form>přepravy</form>
   <lemma>přeprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s1w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s1w35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-131-p3s2">
  <m id="m-ln94202-131-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w1</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94202-131-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w2</w.rf>
   <form>přistoupila</form>
   <lemma>přistoupit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94202-131-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w3</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94202-131-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w4</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m-ln94202-131-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w5</w.rf>
   <form>dohodě</form>
   <lemma>dohoda</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w6</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-131-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-131-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w8</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94202-131-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w9</w.rf>
   <form>1987</form>
   <lemma>1987</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94202-131-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-131-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w11</w.rf>
   <form>ovšem</form>
   <lemma>ovšem-1_^(avšak,_však;_odporovací_spojka)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-131-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w12</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-131-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-131-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w14</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w15</w.rf>
   <form>přepravy</form>
   <lemma>přeprava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-131-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w16</w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-131-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-131-p3s2w17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-87-p1s1">
  <m id="m-ln94204-87-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p1s1w1</w.rf>
   <form>Alžírští</form>
   <lemma>alžírský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94204-87-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p1s1w2</w.rf>
   <form>extremisté</form>
   <lemma>extremista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94204-87-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p1s1w3</w.rf>
   <form>vyhrožují</form>
   <lemma>vyhrožovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94204-87-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p1s1w4</w.rf>
   <form>Maroku</form>
   <lemma>Maroko_;G</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
 </s>
 <s id="m-ln94204-87-p2s1A">
  <m id="m-ln94204-87-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Aw1</w.rf>
   <form>Alžír</form>
   <lemma>Alžír_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-87-p2s1B">
  <m id="m-ln94204-87-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw1</w.rf>
   <form>Islámští</form>
   <lemma>islámský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw2</w.rf>
   <form>fundamentalisté</form>
   <lemma>fundamentalista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw4</w.rf>
   <form>Alžírska</form>
   <lemma>Alžírsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw5</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw6</w.rf>
   <form>zveřejnili</form>
   <lemma>zveřejnit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw7</w.rf>
   <form>výhrůžku</form>
   <lemma>výhrůžka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw9</w.rf>
   <form>adresu</form>
   <lemma>adresa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw10</w.rf>
   <form>Maroka</form>
   <lemma>Maroko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw12</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw13</w.rf>
   <form>sáhnou</form>
   <lemma>sáhnout_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw14</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw15</w.rf>
   <form>násilí</form>
   <lemma>násilí</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw17</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw19</w.rf>
   <form>li</form>
   <lemma>li</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw20</w.rf>
   <form>Alžířané</form>
   <lemma>Alžířan_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw22</w.rf>
   <form>Marockém</form>
   <lemma>marocký</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw23</w.rf>
   <form>království</form>
   <lemma>království</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw24</w.rf>
   <form>vystaveni</form>
   <lemma>vystavit_:W_^(např._potvrzení)</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw25</w.rf>
   <form>špatnému</form>
   <lemma>špatný</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw26</w.rf>
   <form>zacházení</form>
   <lemma>zacházení_^(*2t)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s1Bw27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-87-p2s2">
  <m id="m-ln94204-87-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w1</w.rf>
   <form>Výhrůžku</form>
   <lemma>výhrůžka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w2</w.rf>
   <form>vydala</form>
   <lemma>vydat-1_:W_^(emitovat:_cenné_papíry,_knihu,_zvuk,...)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94204-87-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w3</w.rf>
   <form>Islámská</form>
   <lemma>islámský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w4</w.rf>
   <form>fronta</form>
   <lemma>fronta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w5</w.rf>
   <form>spásy</form>
   <lemma>spása</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w6</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w7</w.rf>
   <form>FIS</form>
   <lemma>FIS_:B_;K</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94204-87-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w8</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w10</w.rf>
   <form>jejíž</form>
   <lemma>jenž_^(který...[ve_vedl._větě])</lemma>
   <tag>P1ZS1FS3-------</tag>
  </m>
  <m id="m-ln94204-87-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w11</w.rf>
   <form>zákaz</form>
   <lemma>zákaz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w12</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-87-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w13</w.rf>
   <form>volbách</form>
   <lemma>volba</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-87-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w15</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94204-87-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w16</w.rf>
   <form>1992</form>
   <lemma>1992</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w17</w.rf>
   <form>vyvolal</form>
   <lemma>vyvolat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-87-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-87-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w19</w.rf>
   <form>Alžírsku</form>
   <lemma>Alžírsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w20</w.rf>
   <form>katastrofální</form>
   <lemma>katastrofální</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w21</w.rf>
   <form>vlnu</form>
   <lemma>vlna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w22</w.rf>
   <form>násilí</form>
   <lemma>násilí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w23</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w24</w.rf>
   <form>teroru</form>
   <lemma>teror</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s2w25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-87-p2s3">
  <m id="m-ln94204-87-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w1</w.rf>
   <form>Maroko</form>
   <lemma>Maroko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w2</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w3</w.rf>
   <form>poněkud</form>
   <lemma>poněkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w4</w.rf>
   <form>zmírnilo</form>
   <lemma>zmírnit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-87-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w5</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-ln94204-87-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w6</w.rf>
   <form>vízovou</form>
   <lemma>vízový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94204-87-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w7</w.rf>
   <form>politiku</form>
   <lemma>politika_^(věda)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w8</w.rf>
   <form>vůči</form>
   <lemma>vůči</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94204-87-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w9</w.rf>
   <form>Alžířanům</form>
   <lemma>Alžířan_;E</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w11</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94204-87-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-87-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w13</w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m-ln94204-87-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w14</w.rf>
   <form>marockých</form>
   <lemma>marocký</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-ln94204-87-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w15</w.rf>
   <form>městech</form>
   <lemma>město</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w16</w.rf>
   <form>zazněly</form>
   <lemma>zaznít</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln94204-87-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w17</w.rf>
   <form>hrozby</form>
   <lemma>hrozba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w18</w.rf>
   <form>pumových</form>
   <lemma>pumový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94204-87-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w19</w.rf>
   <form>atentátů</form>
   <lemma>atentát</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94204-87-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-87-p2s3w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-98-p1s1">
  <m id="m-ln94202-98-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p1s1w1</w.rf>
   <form>Sud</form>
   <lemma>sud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-98-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p1s1w2</w.rf>
   <form>piva</form>
   <lemma>pivo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p1s1w3</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94202-98-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p1s1w4</w.rf>
   <form>Everest</form>
   <lemma>Everest_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
 </s>
 <s id="m-ln94202-98-p2s1A">
  <m id="m-ln94202-98-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Aw1</w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Aw2</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94202-98-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Aw3</w.rf>
   <form>Metují</form>
   <lemma>Metuje_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Aw4</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Aw5</w.rf>
   <form>tom</form>
   <lemma>tom-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94202-98-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Aw6</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Aw7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-98-p2s1B">
  <m id="m-ln94202-98-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw1</w.rf>
   <form>Hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw2</w.rf>
   <form>cenu</form>
   <lemma>cena-2_^(medaile,_ocenění,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw4</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw6</w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw7</w.rf>
   <form>mezinárodního</form>
   <lemma>mezinárodní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw8</w.rf>
   <form>Festivalu</form>
   <lemma>festival</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw9</w.rf>
   <form>horolezeckých</form>
   <lemma>horolezecký</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw10</w.rf>
   <form>filmů</form>
   <lemma>film</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw11</w.rf>
   <form>získal</form>
   <lemma>získat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw12</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw13</w.rf>
   <form>očekávání</form>
   <lemma>očekávání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw14</w.rf>
   <form>australský</form>
   <lemma>australský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw15</w.rf>
   <form>snímek</form>
   <lemma>snímek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw16</w.rf>
   <form>Everest</form>
   <lemma>Everest_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw17</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw18</w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw19</w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw21</w.rf>
   <form>vrchol</form>
   <lemma>vrchol</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s1Bw22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-98-p2s2">
  <m id="m-ln94202-98-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w1</w.rf>
   <form>Putování</form>
   <lemma>putování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w2</w.rf>
   <form>horolezce</form>
   <lemma>horolezec</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w3</w.rf>
   <form>Tima</form>
   <lemma>Tim_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w4</w.rf>
   <form>Mac</form>
   <lemma>Mac_;S</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w5</w.rf>
   <form>Cartneyho</form>
   <lemma>Cartney_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w6</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-98-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w7</w.rf>
   <form>mořské</form>
   <lemma>mořský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w8</w.rf>
   <form>hladiny</form>
   <lemma>hladina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w9</w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94202-98-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w11</w.rf>
   <form>nejvyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w12</w.rf>
   <form>vrchol</form>
   <lemma>vrchol</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w13</w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w14</w.rf>
   <form>zaujalo</form>
   <lemma>zaujmout_^(upoutat_pozornost)</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-98-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w15</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w16</w.rf>
   <form>nápadem</form>
   <lemma>nápad</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w18</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w19</w.rf>
   <form>filmovým</form>
   <lemma>filmový</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w20</w.rf>
   <form>zpracováním</form>
   <lemma>zpracování_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s2w21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-98-p2s3">
  <m id="m-ln94202-98-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w1</w.rf>
   <form>Tento</form>
   <lemma>tento</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-ln94202-98-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w2</w.rf>
   <form>snímek</form>
   <lemma>snímek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w3</w.rf>
   <form>získal</form>
   <lemma>získat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-98-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w4</w.rf>
   <form>kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-98-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w5</w.rf>
   <form>stylizované</form>
   <lemma>stylizovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-98-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w6</w.rf>
   <form>keramické</form>
   <lemma>keramický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94202-98-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w7</w.rf>
   <form>jabloně</form>
   <lemma>jabloň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w8</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w9</w.rf>
   <form>cenu</form>
   <lemma>cena-2_^(medaile,_ocenění,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w10</w.rf>
   <form>diváků</form>
   <lemma>divák</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w11</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w12</w.rf>
   <form>sud</form>
   <lemma>sud</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w13</w.rf>
   <form>piva</form>
   <lemma>pivo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s3w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-98-p2s4">
  <m id="m-ln94202-98-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w1</w.rf>
   <form>Vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m-ln94202-98-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w2</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-ln94202-98-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w3</w.rf>
   <form>vzdálenosti</form>
   <lemma>vzdálenost_^(*5it)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w4</w.rf>
   <form>pátého</form>
   <lemma>pátý</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m-ln94202-98-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w5</w.rf>
   <form>kontinentu</form>
   <lemma>kontinent</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w6</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94202-98-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w7</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-98-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w8</w.rf>
   <form>slavnostním</form>
   <lemma>slavnostní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94202-98-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w9</w.rf>
   <form>vyhlášení</form>
   <lemma>vyhlášení_,a_^(*4sit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w10</w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-ln94202-98-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w11</w.rf>
   <form>cena</form>
   <lemma>cena-2_^(medaile,_ocenění,...)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w12</w.rf>
   <form>zkonzumována</form>
   <lemma>zkonzumovat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ln94202-98-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w13</w.rf>
   <form>návštěvníky</form>
   <lemma>návštěvník</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-ln94202-98-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p2s4w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-98-p3s1">
  <m id="m-ln94202-98-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-98-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w2</w.rf>
   <form>tříleté</form>
   <lemma>tříletý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94202-98-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w3</w.rf>
   <form>pauze</form>
   <lemma>pauza</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94202-98-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94202-98-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w5</w.rf>
   <form>obnovená</form>
   <lemma>obnovený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94202-98-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w6</w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94202-98-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-98-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w8</w.rf>
   <form>klínu</form>
   <lemma>klín</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94202-98-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w9</w.rf>
   <form>Teplicko</form>
   <lemma>teplický</lemma>
   <tag>A2--------A----</tag>
  </m>
  <m id="m-ln94202-98-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w10</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-98-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w11</w.rf>
   <form>adršpašských</form>
   <lemma>adršpašský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94202-98-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w12</w.rf>
   <form>skal</form>
   <lemma>skála</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94202-98-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w13</w.rf>
   <form>konala</form>
   <lemma>konat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94202-98-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-98-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w15</w.rf>
   <form>lehce</form>
   <lemma>lehce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94202-98-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w16</w.rf>
   <form>pozměněné</form>
   <lemma>pozměněný_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94202-98-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w17</w.rf>
   <form>podobě</form>
   <lemma>podoba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94202-98-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-98-p3s1w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95045-060-p1s1">
  <m id="m-ln95045-060-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p1s1w1</w.rf>
   <form>Mečiar</form>
   <lemma>Mečiar_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95045-060-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p1s1w2</w.rf>
   <form>chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95045-060-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p1s1w3</w.rf>
   <form>prý</form>
   <lemma>prý</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln95045-060-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p1s1w4</w.rf>
   <form>nového</form>
   <lemma>nový</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-ln95045-060-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p1s1w5</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln95045-060-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p1s1w6</w.rf>
   <form>SIS</form>
   <lemma>SIS-2_:B_;K_,t_^(Slovenská_informačná_služba)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
 </s>
 <s id="m-ln95045-060-p2s1A">
  <m id="m-ln95045-060-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Aw1</w.rf>
   <form>Bratislava</form>
   <lemma>Bratislava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95045-060-p2s1B">
  <m id="m-ln95045-060-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw2</w.rf>
   <form>minulém</form>
   <lemma>minulý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw3</w.rf>
   <form>jednání</form>
   <lemma>jednání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw4</w.rf>
   <form>vlády</form>
   <lemma>vláda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw5</w.rf>
   <form>SR</form>
   <lemma>SR-1_:B_;G_^(Slovenská_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw6</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw7</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw8</w.rf>
   <form>schválen</form>
   <lemma>schválit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw9</w.rf>
   <form>návrh</form>
   <lemma>návrh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw11</w.rf>
   <form>odvolání</form>
   <lemma>odvolání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw12</w.rf>
   <form>šéfa</form>
   <lemma>šéf</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw13</w.rf>
   <form>slovenské</form>
   <lemma>slovenský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw14</w.rf>
   <form>tajné</form>
   <lemma>tajný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw15</w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw16</w.rf>
   <form>SIS</form>
   <lemma>SIS-2_:B_;K_,t_^(Slovenská_informačná_služba)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw17</w.rf>
   <form>Vladimíra</form>
   <lemma>Vladimír_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw18</w.rf>
   <form>Mitra</form>
   <lemma>Mitr_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw20</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw21</w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw23</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw24</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw25</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw26</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw27</w.rf>
   <form>navrhl</form>
   <lemma>navrhnout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw28</w.rf>
   <form>Mečiarův</form>
   <lemma>Mečiarův_;S_^(*2)</lemma>
   <tag>AUIS1M---------</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw29</w.rf>
   <form>kabinet</form>
   <lemma>kabinet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw30</w.rf>
   <form>jmenovat</form>
   <lemma>jmenovat_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw31</w.rf>
   <form>Ivana</form>
   <lemma>Ivan_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw32</w.rf>
   <form>Lexu</form>
   <lemma>Lexa_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s1Bw33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s1Bw33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95045-060-p2s2">
  <m id="m-ln95045-060-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w1</w.rf>
   <form>Vyplývá</form>
   <lemma>vyplývat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95045-060-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln95045-060-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95045-060-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w4</w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95045-060-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w5</w.rf>
   <form>informovaných</form>
   <lemma>informovaný_^(*2t)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln95045-060-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w6</w.rf>
   <form>zdrojů</form>
   <lemma>zdroj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w7</w.rf>
   <form>LN</form>
   <lemma>LN-1_:B_;R_^(Lidové_noviny,_deník)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-ln95045-060-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-060-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w9</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-ln95045-060-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w10</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-ln95045-060-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w11</w.rf>
   <form>nepřály</form>
   <lemma>přát</lemma>
   <tag>VpTP---XR-NA---</tag>
  </m>
  <m id="m-ln95045-060-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w12</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95045-060-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w13</w.rf>
   <form>jmenovány</form>
   <lemma>jmenovat_:T_:W</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-ln95045-060-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s2w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95045-060-p2s3">
  <m id="m-ln95045-060-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w1</w.rf>
   <form>Kancelář</form>
   <lemma>kancelář</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w2</w.rf>
   <form>prezidenta</form>
   <lemma>prezident</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w3</w.rf>
   <form>oficiálně</form>
   <lemma>oficiálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95045-060-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w4</w.rf>
   <form>návrh</form>
   <lemma>návrh</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95045-060-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w6</w.rf>
   <form>Lexovo</form>
   <lemma>Lexův_;S_^(*2a)</lemma>
   <tag>AUNS4M---------</tag>
  </m>
  <m id="m-ln95045-060-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w7</w.rf>
   <form>jmenování</form>
   <lemma>jmenování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w8</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95045-060-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w9</w.rf>
   <form>neobdržela</form>
   <lemma>obdržet</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-ln95045-060-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95045-060-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w11</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95045-060-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w12</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95045-060-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w13</w.rf>
   <form>zde</form>
   <lemma>zde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95045-060-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w14</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95045-060-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w15</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m-ln95045-060-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w16</w.rf>
   <form>personální</form>
   <lemma>personální</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln95045-060-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w17</w.rf>
   <form>výměně</form>
   <lemma>výměna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln95045-060-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w18</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95045-060-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w19</w.rf>
   <form>věděli</form>
   <lemma>vědět</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln95045-060-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95045-060-p2s3w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-102-p1s1">
  <m id="m-ln94202-102-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p1s1w1</w.rf>
   <form>Zlatým</form>
   <lemma>zlatý_^(atribut;_z._řetízek,_poklad,...)</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m-ln94202-102-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p1s1w2</w.rf>
   <form>profesionálem</form>
   <lemma>profesionál</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94202-102-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p1s1w3</w.rf>
   <form>Leblanc</form>
   <lemma>Leblanc_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94202-102-p2s1A">
  <m id="m-ln94202-102-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Aw1</w.rf>
   <form>Český</form>
   <lemma>český</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Aw2</w.rf>
   <form>cyklista</form>
   <lemma>cyklista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Aw3</w.rf>
   <form>Lom</form>
   <lemma>Lom_;G_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Aw4</w.rf>
   <form>mistrovský</form>
   <lemma>mistrovský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Aw5</w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Aw6</w.rf>
   <form>nedojel</form>
   <lemma>dojet</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
 </s>
 <s id="m-ln94202-102-p2s1B">
  <m id="m-ln94202-102-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Bw1</w.rf>
   <form>Agrigento</form>
   <lemma>Agrigento_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Bw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-102-p2s1C">
  <m id="m-ln94202-102-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw2</w.rf>
   <form>nejcennější</form>
   <lemma>cenný</lemma>
   <tag>AAFS4----3A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw3</w.rf>
   <form>medaili</form>
   <lemma>medaile</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw4</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw6</w.rf>
   <form>MS</form>
   <lemma>MS-3_:B_;w_^(mistrovství_světa)</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw8</w.rf>
   <form>Agrigentu</form>
   <lemma>Agrigento_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw10</w.rf>
   <form>Sicílii</form>
   <lemma>Sicílie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw11</w.rf>
   <form>dojel</form>
   <lemma>dojet</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw13</w.rf>
   <form>silničním</form>
   <lemma>silniční</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw14</w.rf>
   <form>cyklistickém</form>
   <lemma>cyklistický</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw15</w.rf>
   <form>závodě</form>
   <lemma>závod</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw16</w.rf>
   <form>profesionálů</form>
   <lemma>profesionál</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw17</w.rf>
   <form>osmadvacetiletý</form>
   <lemma>osmadvacetiletý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw18</w.rf>
   <form>Francouz</form>
   <lemma>Francouz_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw19</w.rf>
   <form>Luc</form>
   <lemma>Luc_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw20</w.rf>
   <form>Leblanc</form>
   <lemma>Leblanc_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw22</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw24</w.rf>
   <form>závěrečném</form>
   <lemma>závěrečný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw25</w.rf>
   <form>stoupání</form>
   <lemma>stoupání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw26</w.rf>
   <form>ukázal</form>
   <lemma>ukázat</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw27</w.rf>
   <form>domácím</form>
   <lemma>domácí</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw28</w.rf>
   <form>závodníkům</form>
   <lemma>závodník</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw29</w.rf>
   <form>záda</form>
   <lemma>záda</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s1Cw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s1Cw30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-102-p2s2">
  <m id="m-ln94202-102-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94202-102-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w2</w.rf>
   <form>stříbrný</form>
   <lemma>stříbrný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94202-102-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w3</w.rf>
   <form>stupeň</form>
   <lemma>stupeň</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w4</w.rf>
   <form>vystoupil</form>
   <lemma>vystoupit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-102-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w5</w.rf>
   <form>Ital</form>
   <lemma>Ital_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w6</w.rf>
   <form>Claudio</form>
   <lemma>Claudio_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w7</w.rf>
   <form>Chiappucci</form>
   <lemma>Chiappucci_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-102-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w9</w.rf>
   <form>bronz</form>
   <lemma>bronz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w10</w.rf>
   <form>putuje</form>
   <lemma>putovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94202-102-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w11</w.rf>
   <form>zásluhou</form>
   <lemma>zásluha</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w12</w.rf>
   <form>Richarda</form>
   <lemma>Richard_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w13</w.rf>
   <form>Virenqueho</form>
   <lemma>Virenque_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w14</w.rf>
   <form>rovněž</form>
   <lemma>rovněž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94202-102-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w15</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-102-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w16</w.rf>
   <form>Francie</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s2w17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-102-p2s3">
  <m id="m-ln94202-102-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w1</w.rf>
   <form>Jediný</form>
   <lemma>jediný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94202-102-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w2</w.rf>
   <form>český</form>
   <lemma>český</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94202-102-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w3</w.rf>
   <form>zástupce</form>
   <lemma>zástupce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w4</w.rf>
   <form>Luboš</form>
   <lemma>Luboš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w5</w.rf>
   <form>Lom</form>
   <lemma>Lom_;G_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w6</w.rf>
   <form>vzdal</form>
   <lemma>vzdát</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94202-102-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w7</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94202-102-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w8</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94202-102-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-102-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w10</w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94202-102-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-102-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w12</w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94202-102-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w13</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-102-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w14</w.rf>
   <form>251.75</form>
   <form_change>num_normalization</form_change>
   <lemma>251.75</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94202-102-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w15</w.rf>
   <form>km</form>
   <lemma>km-1`kilometr_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln94202-102-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w16</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-102-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p2s3w17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94202-102-p3s1">
  <m id="m-ln94202-102-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w1</w.rf>
   <form>Dvě</form>
   <lemma>dva`2</lemma>
   <tag>ClHP1----------</tag>
  </m>
  <m id="m-ln94202-102-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w2</w.rf>
   <form>stě</form>
   <lemma>sto-2`100</lemma>
   <tag>NNNP1-----A---1</tag>
  </m>
  <m id="m-ln94202-102-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w3</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-2`1000</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w4</w.rf>
   <form>příznivců</form>
   <lemma>příznivec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w5</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-ln94202-102-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w6</w.rf>
   <form>nepřipouštělo</form>
   <lemma>připouštět_:T</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-ln94202-102-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w7</w.rf>
   <form>jinou</form>
   <lemma>jiný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w8</w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w9</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94202-102-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w10</w.rf>
   <form>vítězství</form>
   <lemma>vítězství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w11</w.rf>
   <form>Chippucciho</form>
   <lemma>Chippucci_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-102-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w13</w.rf>
   <form>Pantaniho</form>
   <lemma>Pantani_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94202-102-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w15</w.rf>
   <form>Furlana</form>
   <lemma>Furlan_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w16</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94202-102-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w17</w.rf>
   <form>někoho</form>
   <lemma>někdo</lemma>
   <tag>PZM-2----------</tag>
  </m>
  <m id="m-ln94202-102-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w18</w.rf>
   <form>dalšího</form>
   <lemma>další</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w19</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94202-102-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w20</w.rf>
   <form>dvanáctky</form>
   <lemma>dvanáctka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w21</w.rf>
   <form>squadry</form>
   <lemma>squadra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w22</w.rf>
   <form>azzury</form>
   <lemma>azzura</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94202-102-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94202-102-p3s1w23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-35-p1s1">
  <m id="m-ln94209-35-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p1s1w1</w.rf>
   <form>Nezletilí</form>
   <lemma>zletilý</lemma>
   <tag>AAMP1----1N----</tag>
  </m>
  <m id="m-ln94209-35-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p1s1w2</w.rf>
   <form>stříleli</form>
   <lemma>střílet_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94209-35-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p1s1w3</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-35-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p1s1w4</w.rf>
   <form>lidech</form>
   <lemma>člověk</lemma>
   <tag>NNMP6-----A----</tag>
  </m>
 </s>
 <s id="m-ln94209-35-p2s1A">
  <m id="m-ln94209-35-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Aw1</w.rf>
   <form>Choceň</form>
   <lemma>Choceň_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Aw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Aw3</w.rf>
   <form>jop</form>
   <lemma>jop-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94209-35-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Aw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Aw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-35-p2s1B">
  <m id="m-ln94209-35-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw1</w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw2</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw3</w.rf>
   <form>oznámila</form>
   <lemma>oznámit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw4</w.rf>
   <form>ústeckoorlická</form>
   <lemma>ústeckoorlický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw5</w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw7</w.rf>
   <form>stříleli</form>
   <lemma>střílet_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw8</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw9</w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw10</w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>ClXP6----------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw11</w.rf>
   <form>prázdninových</form>
   <lemma>prázdninový</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw12</w.rf>
   <form>dnech</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw13</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw14</w.rf>
   <form>čtrnáctiletí</form>
   <lemma>čtrnáctiletý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw15</w.rf>
   <form>chlapci</form>
   <lemma>chlapec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw16</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw17</w.rf>
   <form>vzduchovky</form>
   <lemma>vzduchovka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw18</w.rf>
   <form>namísto</form>
   <lemma>namísto-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw19</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw20</w.rf>
   <form>terčů</form>
   <lemma>terč</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw21</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw22</w.rf>
   <form>lidech</form>
   <lemma>člověk</lemma>
   <tag>NNMP6-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s1Bw23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-35-p2s2">
  <m id="m-ln94209-35-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s2w1</w.rf>
   <form>Stříleli</form>
   <lemma>střílet_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s2w2</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-35-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s2w3</w.rf>
   <form>cyklistech</form>
   <lemma>cyklista</lemma>
   <tag>NNMP6-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s2w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s2w5</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94209-35-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s2w6</w.rf>
   <form>nichž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P9XP2----------</tag>
  </m>
  <m id="m-ln94209-35-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s2w7</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-ln94209-35-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s2w8</w.rf>
   <form>zasáhli</form>
   <lemma>zasáhnout</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s2w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-35-p2s3">
  <m id="m-ln94209-35-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s3w1</w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m-ln94209-35-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s3w2</w.rf>
   <form>ošetření</form>
   <lemma>ošetření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s3w3</w.rf>
   <form>nepotřebovali</form>
   <lemma>potřebovat_:T</lemma>
   <tag>VpMP---XR-NA---</tag>
  </m>
  <m id="m-ln94209-35-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s3w4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-35-p2s4">
  <m id="m-ln94209-35-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s4w1</w.rf>
   <form>Hůře</form>
   <lemma>špatně</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-ln94209-35-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s4w2</w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s4w3</w.rf>
   <form>druhý</form>
   <lemma>druhý-2</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m-ln94209-35-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s4w4</w.rf>
   <form>den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s4w5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-35-p2s5">
  <m id="m-ln94209-35-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w1</w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w2</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w3</w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>ClYS1----------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w4</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w5</w.rf>
   <form>střelců</form>
   <lemma>střelec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w6</w.rf>
   <form>počínal</form>
   <lemma>počínat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w7</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w8</w.rf>
   <form>obratně</form>
   <lemma>obratně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w10</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w11</w.rf>
   <form>zasáhl</form>
   <lemma>zasáhnout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s5w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w12</w.rf>
   <form>cyklistku</form>
   <lemma>cyklistka_^(*2a)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w14</w.rf>
   <form>důchodkyni</form>
   <lemma>důchodkyně_^(*4ce)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w15</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w16</w.rf>
   <form>předloktí</form>
   <lemma>předloktí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w18</w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w19</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w20</w.rf>
   <form>vyžádá</form>
   <lemma>vyžádat_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s5w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w21</w.rf>
   <form>dvoutýdenní</form>
   <lemma>dvoutýdenní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w22</w.rf>
   <form>léčení</form>
   <lemma>léčení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s5w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w24</w.rf>
   <form>řekl</form>
   <lemma>říci_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s5w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w25</w.rf>
   <form>LN</form>
   <lemma>LN-1_:B_;R_^(Lidové_noviny,_deník)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-ln94209-35-p2s5w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w26</w.rf>
   <form>tiskový</form>
   <lemma>tiskový</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w27</w.rf>
   <form>mluvčí</form>
   <lemma>mluvčí</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w28</w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w29</w.rf>
   <form>Hampl</form>
   <lemma>Hampl_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s5w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s5w30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94209-35-p2s6">
  <m id="m-ln94209-35-p2s6w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w1</w.rf>
   <form>Nezletilí</form>
   <lemma>zletilý</lemma>
   <tag>AAMP1----1N----</tag>
  </m>
  <m id="m-ln94209-35-p2s6w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94209-35-p2s6w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w3</w.rf>
   <form>dopustili</form>
   <lemma>dopustit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s6w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w4</w.rf>
   <form>ublížení</form>
   <lemma>ublížení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s6w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94209-35-p2s6w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w6</w.rf>
   <form>zdraví</form>
   <lemma>zdraví</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s6w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s6w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w8</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94209-35-p2s6w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w9</w.rf>
   <form>případ</form>
   <lemma>případ</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s6w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w10</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94209-35-p2s6w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w11</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94209-35-p2s6w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w12</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94209-35-p2s6w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w13</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-ln94209-35-p2s6w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w14</w.rf>
   <form>věk</form>
   <lemma>věk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94209-35-p2s6w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w15</w.rf>
   <form>odložen</form>
   <lemma>odložit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ln94209-35-p2s6w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94209-35-p2s6w16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-19-p1s1">
  <m id="m-ln94204-19-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p1s1w1</w.rf>
   <form>Chmurné</form>
   <lemma>chmurný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln94204-19-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p1s1w2</w.rf>
   <form>vyhlídky</form>
   <lemma>vyhlídka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94204-19-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p1s1w3</w.rf>
   <form>uhlí</form>
   <lemma>uhlí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p1s1w4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-19-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p1s1w5</w.rf>
   <form>Evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94204-19-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p1s1w6</w.rf>
   <form>unii</form>
   <lemma>unie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
 </s>
 <s id="m-ln94204-19-p2s1">
  <m id="m-ln94204-19-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w1</w.rf>
   <form>Příštích</form>
   <lemma>příští</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w2</w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-ln94204-19-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w3</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w4</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-19-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w5</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-19-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w6</w.rf>
   <form>uhelný</form>
   <lemma>uhelný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w7</w.rf>
   <form>průmysl</form>
   <lemma>průmysl</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w8</w.rf>
   <form>znamenat</form>
   <lemma>znamenat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w9</w.rf>
   <form>poněkud</form>
   <lemma>poněkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-19-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w10</w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w11</w.rf>
   <form>časy</form>
   <lemma>čas</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-19-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w13</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-19-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w14</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94204-19-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w15</w.rf>
   <form>částečnou</form>
   <lemma>částečný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w16</w.rf>
   <form>úlevou</form>
   <lemma>úleva</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w17</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-ln94204-19-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w18</w.rf>
   <form>zvýšení</form>
   <lemma>zvýšení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w19</w.rf>
   <form>poptávky</form>
   <lemma>poptávka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w20</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-19-p2s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w21</w.rf>
   <form>Číně</form>
   <lemma>Čína_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-19-p2s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w23</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-19-p2s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w24</w.rf>
   <form>ostatních</form>
   <lemma>ostatní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w25</w.rf>
   <form>asijských</form>
   <lemma>asijský</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w26</w.rf>
   <form>zemích</form>
   <lemma>země</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94204-19-p2s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s1w27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-19-p2s2">
  <m id="m-ln94204-19-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s2w1</w.rf>
   <form>Vyplývá</form>
   <lemma>vyplývat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-19-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s2w2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94204-19-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s2w3</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ln94204-19-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s2w4</w.rf>
   <form>studie</form>
   <lemma>studie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s2w5</w.rf>
   <form>Evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94204-19-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s2w6</w.rf>
   <form>hospodářské</form>
   <lemma>hospodářský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94204-19-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s2w7</w.rf>
   <form>komise</form>
   <lemma>komise</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p2s2w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-19-p3s1">
  <m id="m-ln94204-19-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w1</w.rf>
   <form>Světová</form>
   <lemma>světový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w2</w.rf>
   <form>spotřeba</form>
   <lemma>spotřeba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w3</w.rf>
   <form>černého</form>
   <lemma>černý-1_^(barva)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w4</w.rf>
   <form>zlata</form>
   <lemma>zlato</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w5</w.rf>
   <form>klesla</form>
   <lemma>klesnout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-ln94204-19-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-19-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w7</w.rf>
   <form>loňském</form>
   <lemma>loňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w8</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94204-19-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w9</w.rf>
   <form>díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94204-19-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w10</w.rf>
   <form>značnému</form>
   <lemma>značný</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w11</w.rf>
   <form>omezení</form>
   <lemma>omezení_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-19-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w13</w.rf>
   <form>západoevropských</form>
   <lemma>západoevropský</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w14</w.rf>
   <form>zemích</form>
   <lemma>země</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-19-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w16</w.rf>
   <form>pokles</form>
   <lemma>pokles</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w17</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-19-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w18</w.rf>
   <form>pokračovat</form>
   <lemma>pokračovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94204-19-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w19</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-19-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w20</w.rf>
   <form>nadále</form>
   <lemma>nadále</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-19-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p3s1w21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-19-p4s1">
  <m id="m-ln94204-19-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w1</w.rf>
   <form>Světová</form>
   <lemma>světový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w2</w.rf>
   <form>produkce</form>
   <lemma>produkce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w3</w.rf>
   <form>uhlí</form>
   <lemma>uhlí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w5</w.rf>
   <form>loni</form>
   <lemma>vloni_,h</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-ln94204-19-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w6</w.rf>
   <form>snížila</form>
   <lemma>snížit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94204-19-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w7</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w8</w.rf>
   <form>1.8</form>
   <form_change>num_normalization</form_change>
   <lemma>1.8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w9</w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w11</w.rf>
   <form>3.43</form>
   <form_change>num_normalization</form_change>
   <lemma>3.43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w12</w.rf>
   <form>mld</form>
   <lemma>miliarda`1000000000_:B</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94204-19-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w14</w.rf>
   <form>tun</form>
   <lemma>tuna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w16</w.rf>
   <form>přičemž</form>
   <lemma>přičemž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w18</w.rf>
   <form>zemích</form>
   <lemma>země</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w19</w.rf>
   <form>Evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w20</w.rf>
   <form>unie</form>
   <lemma>unie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w21</w.rf>
   <form>dosáhl</form>
   <lemma>dosáhnout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-19-p4s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w22</w.rf>
   <form>pokles</form>
   <lemma>pokles</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w23</w.rf>
   <form>hodnoty</form>
   <lemma>hodnota</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w24</w.rf>
   <form>13.2</form>
   <form_change>num_normalization</form_change>
   <lemma>13.2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w25</w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w27</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w28</w.rf>
   <form>zemích</form>
   <lemma>země</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w29</w.rf>
   <form>střední</form>
   <lemma>střední</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w30</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w31</w.rf>
   <form>východní</form>
   <lemma>východní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w32</w.rf>
   <form>Evropy</form>
   <lemma>Evropa_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-19-p4s1w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w33</w.rf>
   <form>8.9</form>
   <form_change>num_normalization</form_change>
   <lemma>8.9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w34</w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-19-p4s1w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-19-p4s1w35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
