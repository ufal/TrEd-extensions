<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="sample7.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94210-75-p1s1">
  <m id="m-ln94210-75-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p1s1w1</w.rf>
   <form>Pokrytectví</form>
   <lemma>pokrytectví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94210-75-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p1s1w2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-75-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p1s1w3</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94210-75-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p1s1w4</w.rf>
   <form>fiskální</form>
   <lemma>fiskální</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94210-75-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p1s1w5</w.rf>
   <form>ústava</form>
   <lemma>ústava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94210-75-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p1s1w6</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94210-75-p2s1A">
  <m id="m-ln94210-75-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Aw1</w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Aw2</w.rf>
   <form>Kotrba</form>
   <lemma>Kotrba_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94210-75-p2s1B">
  <m id="m-ln94210-75-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw1</w.rf>
   <form>Návrh</form>
   <lemma>návrh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw2</w.rf>
   <form>výkonné</form>
   <lemma>výkonný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw3</w.rf>
   <form>rady</form>
   <lemma>rada-3_^(poradní_sbor;_př._Česká_národní_r.)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw4</w.rf>
   <form>ODS</form>
   <lemma>ODS-1_:B_;K_;p_^(Občanská_demokratická_strana)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw5</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw6</w.rf>
   <form>předložení</form>
   <lemma>předložení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw7</w.rf>
   <form>ústavního</form>
   <lemma>ústavní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw8</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw9</w.rf>
   <form>narazil</form>
   <lemma>narazit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw11</w.rf>
   <form>ostrou</form>
   <lemma>ostrý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw12</w.rf>
   <form>kritiku</form>
   <lemma>kritika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw13</w.rf>
   <form>téměř</form>
   <lemma>téměř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw14</w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP2----------</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw15</w.rf>
   <form>stran</form>
   <lemma>strana-2_^(politická)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s1Bw16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94210-75-p2s2">
  <m id="m-ln94210-75-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w1</w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94210-75-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w2</w.rf>
   <form>stran</form>
   <lemma>strana-2_^(politická)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w3</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94210-75-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w4</w.rf>
   <form>levé</form>
   <lemma>levý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w5</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w6</w.rf>
   <form>politického</form>
   <lemma>politický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w7</w.rf>
   <form>spektra</form>
   <lemma>spektrum</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w8</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94210-75-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w9</w.rf>
   <form>pochopitelná</form>
   <lemma>pochopitelný_^(*4)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w10</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94210-75-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w11</w.rf>
   <form>dalšího</form>
   <lemma>další</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w12</w.rf>
   <form>přemýšlení</form>
   <lemma>přemýšlení_^(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s2w13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94210-75-p2s3">
  <m id="m-ln94210-75-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w1</w.rf>
   <form>Snad</form>
   <lemma>snad</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w2</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94210-75-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w3</w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP6----------</tag>
  </m>
  <m id="m-ln94210-75-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w4</w.rf>
   <form>zemích</form>
   <lemma>země</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w5</w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w6</w.rf>
   <form>levicové</form>
   <lemma>levicový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w7</w.rf>
   <form>vlády</form>
   <lemma>vláda</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w8</w.rf>
   <form>povolovaly</form>
   <lemma>povolovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln94210-75-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w9</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w11</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w12</w.rf>
   <form>sociální</form>
   <lemma>sociální</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w13</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w14</w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w15</w.rf>
   <form>výdaje</form>
   <lemma>výdaj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w17</w.rf>
   <form>aniž</form>
   <lemma>aniž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w18</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w19</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-ln94210-75-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w20</w.rf>
   <form>pokryly</form>
   <lemma>pokrýt</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln94210-75-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w21</w.rf>
   <form>adekvátním</form>
   <lemma>adekvátní</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w22</w.rf>
   <form>zvýšením</form>
   <lemma>zvýšení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w23</w.rf>
   <form>rozpočtových</form>
   <lemma>rozpočtový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w24</w.rf>
   <form>příjmů</form>
   <lemma>příjem</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s3w25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94210-75-p2s4">
  <m id="m-ln94210-75-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w1</w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w3</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w4</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w5</w.rf>
   <form>tomuto</form>
   <lemma>tento</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w6</w.rf>
   <form>návrhu</form>
   <lemma>návrh</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w7</w.rf>
   <form>staví</form>
   <lemma>stavět_:T</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-ln94210-75-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w8</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w9</w.rf>
   <form>strany</form>
   <lemma>strana-2_^(politická)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w10</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w11</w.rf>
   <form>konzervativní</form>
   <lemma>konzervativní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w12</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w13</w.rf>
   <form>liberální</form>
   <lemma>liberální</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w14</w.rf>
   <form>politickou</form>
   <lemma>politický</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w15</w.rf>
   <form>orientací</form>
   <lemma>orientace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w17</w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4XP3----------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w18</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln94210-75-p2s4w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w19</w.rf>
   <form>idea</form>
   <lemma>idea</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w20</w.rf>
   <form>nezadluženého</form>
   <lemma>zadlužený_^(*3it)</lemma>
   <tag>AAIS2----1N----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w21</w.rf>
   <form>státu</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w22</w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94210-75-p2s4w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w23</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w24</w.rf>
   <form>vlastní</form>
   <lemma>vlastní-1_^(příslušný_k_něčemu)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94210-75-p2s4w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94210-75-p2s4w25</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930713-017-p1s1">
  <m id="m-mf930713-017-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p1s1w1</w.rf>
   <form>Ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p1s1w2</w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-mf930713-017-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p1s1w3</w.rf>
   <form>vzít</form>
   <lemma>vzít_^(př._sebrat_něco;_brát_ohled,_zřetel,...)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf930713-017-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p1s1w4</w.rf>
   <form>koště</form>
   <lemma>koště</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf930713-017-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p1s1w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p1s1w6</w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf930713-017-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p1s1w7</w.rf>
   <form>tenistky</form>
   <lemma>tenistka_^(*2a)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p1s1w8</w.rf>
   <form>mohly</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-mf930713-017-p1s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p1s1w9</w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A----</tag>
  </m>
 </s>
 <s id="m-mf930713-017-p2s1A">
  <m id="m-mf930713-017-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Aw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Aw3</w.rf>
   <form>čen</form>
   <lemma>čen-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-mf930713-017-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Aw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Aw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930713-017-p2s1B">
  <m id="m-mf930713-017-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw1</w.rf>
   <form>Aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw2</w.rf>
   <form>mohla</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw3</w.rf>
   <form>pokračovat</form>
   <lemma>pokračovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw4</w.rf>
   <form>kvalifikace</form>
   <lemma>kvalifikace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw5</w.rf>
   <form>tenisového</form>
   <lemma>tenisový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw6</w.rf>
   <form>turnaje</form>
   <lemma>turnaj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw7</w.rf>
   <form>žen</form>
   <lemma>žena</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw8</w.rf>
   <form>BVV</form>
   <lemma>BVV_:B_;K</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw9</w.rf>
   <form>Prague</form>
   <lemma>Prague_;K_,t</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw10</w.rf>
   <form>Open</form>
   <lemma>Open-1_,t_^(v_názvu_např._sport._soutěží,_"otevřený")</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw12</w.rf>
   <form>celková</form>
   <lemma>celkový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw13</w.rf>
   <form>dotace</form>
   <lemma>dotace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw14</w.rf>
   <form>sto</form>
   <lemma>sto-2`100</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw15</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw16</w.rf>
   <form>dolarů</form>
   <lemma>dolar_;b</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw17</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw19</w.rf>
   <form>přerušená</form>
   <lemma>přerušený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw20</w.rf>
   <form>průtrží</form>
   <lemma>průtrž</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw21</w.rf>
   <form>mračen</form>
   <lemma>mračno</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw23</w.rf>
   <form>vzali</form>
   <lemma>vzít_^(př._sebrat_něco;_brát_ohled,_zřetel,...)</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw24</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw25</w.rf>
   <form>koště</form>
   <lemma>koště</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw26</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw27</w.rf>
   <form>ruky</form>
   <lemma>ruka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw28</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw29</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw30</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw31</w.rf>
   <form>Vladimír</form>
   <lemma>Vladimír_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw32</w.rf>
   <form>Šafařík</form>
   <lemma>Šafařík_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw33</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw34</w.rf>
   <form>rozhodčím</form>
   <lemma>rozhodčí</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw35</w.rf>
   <form>Antonínem</form>
   <lemma>Antonín_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw36</w.rf>
   <form>Bubeníkem</form>
   <lemma>bubeník</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw37</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw38</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw39</w.rf>
   <form>štvanických</form>
   <lemma>štvanický</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw40">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw40</w.rf>
   <form>kurtech</form>
   <lemma>kurt</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw41">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw41</w.rf>
   <form>pomáhali</form>
   <lemma>pomáhat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw42">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw42</w.rf>
   <form>vymetat</form>
   <lemma>vymetat-1_:T_:W_^(obilí_vymetalo)</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw43">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw43</w.rf>
   <form>louže</form>
   <lemma>louže</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s1Bw44">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s1Bw44</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930713-017-p2s2">
  <m id="m-mf930713-017-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w2</w.rf>
   <form>Počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w3</w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m-mf930713-017-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w4</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w5</w.rf>
   <form>nechává</form>
   <lemma>nechávat_:T_^(*4at)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf930713-017-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w6</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930713-017-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w7</w.rf>
   <form>klidu</form>
   <lemma>klid</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w9</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf930713-017-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w10</w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w11</w.rf>
   <form>turnaje</form>
   <lemma>turnaj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w12</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf930713-017-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w13</w.rf>
   <form>času</form>
   <lemma>čas</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w14</w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-mf930713-017-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w16</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w17</w.rf>
   <form>tvrdil</form>
   <lemma>tvrdit_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-mf930713-017-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w18</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w19</w.rf>
   <form>Šafařík</form>
   <lemma>Šafařík_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s2w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930713-017-p2s3">
  <m id="m-mf930713-017-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s3w1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s3w2</w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-mf930713-017-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s3w3</w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m-mf930713-017-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s3w4</w.rf>
   <form>spíš</form>
   <lemma>spíše</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-mf930713-017-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s3w5</w.rf>
   <form>zklamalo</form>
   <lemma>zklamat</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-mf930713-017-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s3w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-017-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s3w7</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf930713-017-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s3w8</w.rf>
   <form>los</form>
   <lemma>los-1_^(zvíře)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930713-017-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930713-017-p2s3w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-155-p1s1">
  <m id="m-ln94200-155-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p1s1w1</w.rf>
   <form>Hlavou</form>
   <lemma>hlava</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94200-155-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p1s1w2</w.rf>
   <form>proražená</form>
   <lemma>proražený_^(*4zit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94200-155-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p1s1w3</w.rf>
   <form>švédská</form>
   <lemma>švédský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94200-155-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p1s1w4</w.rf>
   <form>hráz</form>
   <lemma>hráz</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94200-155-p2s1A">
  <m id="m-ln94200-155-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw1</w.rf>
   <form>Viktoria</form>
   <lemma>Viktoria-2_;K_^(jméno_sport.klubu)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw2</w.rf>
   <form>Žižkov</form>
   <lemma>Žižkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw3</w.rf>
   <form>remizovala</form>
   <lemma>remizovat_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw5</w.rf>
   <form>předkole</form>
   <lemma>předkolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw6</w.rf>
   <form>fotbalového</form>
   <lemma>fotbalový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw7</w.rf>
   <form>PVP</form>
   <lemma>PVP_:B_;K</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw9</w.rf>
   <form>hřišti</form>
   <lemma>hřiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw10</w.rf>
   <form>Norrköpingu</form>
   <lemma>Norrköping_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw11</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw12</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw13</w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw14</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw15</w.rf>
   <form>postupuje</form>
   <lemma>postupovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94200-155-p2s1Aw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Aw16</w.rf>
   <form>dále</form>
   <lemma>daleko-1_^(dojít_dále_než_...)</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
 </s>
 <s id="m-ln94200-155-p2s1B">
  <m id="m-ln94200-155-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Bw1</w.rf>
   <form>Zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Bw2</w.rf>
   <form>zpravodaj</form>
   <lemma>zpravodaj-2_^(člověk)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Bw3</w.rf>
   <form>LN</form>
   <lemma>LN-1_:B_;R_^(Lidové_noviny,_deník)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-ln94200-155-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Bw4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Bw5</w.rf>
   <form>Norrköpingu</form>
   <lemma>Norrköping_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Bw6</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Bw7</w.rf>
   <form>Švéd</form>
   <lemma>Švéd_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94200-155-p2s1C">
  <m id="m-ln94200-155-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw1</w.rf>
   <form>Spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw2</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw3</w.rf>
   <form>pražskou</form>
   <lemma>pražský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw4</w.rf>
   <form>Slavií</form>
   <lemma>Slavia_;K</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw6</w.rf>
   <form>Viktoria</form>
   <lemma>Viktoria-2_;K_^(jméno_sport.klubu)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw7</w.rf>
   <form>Žižkov</form>
   <lemma>Žižkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw8</w.rf>
   <form>druhým</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw9</w.rf>
   <form>českým</form>
   <lemma>český</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw10</w.rf>
   <form>týmem</form>
   <lemma>tým</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw12</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw13</w.rf>
   <form>postoupil</form>
   <lemma>postoupit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw14</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw15</w.rf>
   <form>předkola</form>
   <lemma>předkolo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw16</w.rf>
   <form>evropských</form>
   <lemma>evropský</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw17</w.rf>
   <form>fotbalových</form>
   <lemma>fotbalový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw18</w.rf>
   <form>pohárů</form>
   <lemma>pohár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s1Cw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s1Cw19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-155-p2s2">
  <m id="m-ln94200-155-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w1</w.rf>
   <form>Přitom</form>
   <lemma>přitom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w2</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94200-155-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w3</w.rf>
   <form>tým</form>
   <lemma>tým</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w4</w.rf>
   <form>mecenáše</form>
   <lemma>mecenáš</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w5</w.rf>
   <form>Vratislava</form>
   <lemma>Vratislav-1_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w6</w.rf>
   <form>Čekana</form>
   <lemma>Čekan_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w7</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94200-155-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w8</w.rf>
   <form>odvetný</form>
   <lemma>odvetný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w9</w.rf>
   <form>zápas</form>
   <lemma>zápas</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w10</w.rf>
   <form>PVP</form>
   <lemma>PVP_:B_;K</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln94200-155-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94200-155-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w12</w.rf>
   <form>Norrköpingu</form>
   <lemma>Norrköping_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w13</w.rf>
   <form>nevyvíjel</form>
   <lemma>vyvíjet_:T</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ln94200-155-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w14</w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s2w15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94200-155-p2s3">
  <m id="m-ln94200-155-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w2</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w3</w.rf>
   <form>půli</form>
   <lemma>půle</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w4</w.rf>
   <form>totiž</form>
   <lemma>totiž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w5</w.rf>
   <form>Žižkovští</form>
   <lemma>žižkovský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w6</w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94200-155-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w7</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w8</w.rf>
   <form>zraněného</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w9</w.rf>
   <form>brankáře</form>
   <lemma>brankář</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w10</w.rf>
   <form>Pařízka</form>
   <lemma>Pařízek-1_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w11</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w12</w.rf>
   <form>zlomená</form>
   <lemma>zlomený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94200-155-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w13</w.rf>
   <form>noha</form>
   <lemma>noha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w14</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w15</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w16</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w17</w.rf>
   <form>náskok</form>
   <lemma>náskok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w18</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w19</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w20</w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w21</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w22</w.rf>
   <form>prvního</form>
   <lemma>první</lemma>
   <tag>CrNS2----------</tag>
  </m>
  <m id="m-ln94200-155-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w23</w.rf>
   <form>utkání</form>
   <lemma>utkání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94200-155-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94200-155-p2s3w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-75-p1s1">
  <m id="m-ln94211-75-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p1s1w1</w.rf>
   <form>Princ</form>
   <lemma>princ</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94211-75-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p1s1w2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94211-75-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p1s1w3</w.rf>
   <form>císařových</form>
   <lemma>císařův_^(*2)</lemma>
   <tag>AUIP6M---------</tag>
  </m>
  <m id="m-ln94211-75-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p1s1w4</w.rf>
   <form>nových</form>
   <lemma>nový</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-ln94211-75-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p1s1w5</w.rf>
   <form>šatech</form>
   <lemma>šat</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
 </s>
 <s id="m-ln94211-75-p2s1">
  <m id="m-ln94211-75-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w1</w.rf>
   <form>Barevnou</form>
   <lemma>barevný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w2</w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w3</w.rf>
   <form>téměř</form>
   <lemma>téměř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w4</w.rf>
   <form>nahého</form>
   <lemma>nahý</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w5</w.rf>
   <form>následníka</form>
   <lemma>následník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w6</w.rf>
   <form>britského</form>
   <lemma>britský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w7</w.rf>
   <form>trůnu</form>
   <lemma>trůn</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w8</w.rf>
   <form>prince</form>
   <lemma>princ</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w9</w.rf>
   <form>Charlese</form>
   <lemma>Charles_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w10</w.rf>
   <form>otiskl</form>
   <lemma>otisknout_:W</lemma>
   <tag>VpYS---XR-AA--1</tag>
  </m>
  <m id="m-ln94211-75-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w11</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w12</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94211-75-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w13</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m-ln94211-75-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w14</w.rf>
   <form>straně</form>
   <lemma>strana-4_^(v_knize,_rukopise,...)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w15</w.rf>
   <form>nejrozšířenější</form>
   <lemma>rozšířený_^(*3it)</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w16</w.rf>
   <form>německý</form>
   <lemma>německý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w17</w.rf>
   <form>deník</form>
   <lemma>deník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w18</w.rf>
   <form>Bild</form>
   <lemma>Bild_;K_;R</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w19</w.rf>
   <form>Zeitung</form>
   <lemma>Zeitung-1_;K_,t_^(souč._názvu_něm._novin)</lemma>
   <tag>NNISX-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s1w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-75-p2s2">
  <m id="m-ln94211-75-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w1</w.rf>
   <form>Přestože</form>
   <lemma>přestože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w2</w.rf>
   <form>snímek</form>
   <lemma>snímek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w3</w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ln94211-75-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w4</w.rf>
   <form>pořízen</form>
   <lemma>pořídit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ln94211-75-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w5</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94211-75-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w6</w.rf>
   <form>naprosto</form>
   <lemma>naprosto</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w7</w.rf>
   <form>kvalitního</form>
   <lemma>kvalitní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w8</w.rf>
   <form>negativu</form>
   <lemma>negativ</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w10</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94211-75-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w11</w.rf>
   <form>patrné</form>
   <lemma>patrný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w13</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w14</w.rf>
   <form>princ</form>
   <lemma>princ</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w15</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94211-75-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w16</w.rf>
   <form>mužnou</form>
   <lemma>mužný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w17</w.rf>
   <form>postavu</form>
   <lemma>postava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s2w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-75-p2s3">
  <m id="m-ln94211-75-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s3w1</w.rf>
   <form>Široká</form>
   <lemma>široký</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s3w2</w.rf>
   <form>ramena</form>
   <lemma>rameno</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s3w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s3w4</w.rf>
   <form>svalnaté</form>
   <lemma>svalnatý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s3w5</w.rf>
   <form>paže</form>
   <lemma>paže</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s3w6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s3w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s3w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-75-p2s4">
  <m id="m-ln94211-75-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w1</w.rf>
   <form>Ani</form>
   <lemma>ani</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w2</w.rf>
   <form>náznak</form>
   <lemma>náznak</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w3</w.rf>
   <form>obtloustlosti</form>
   <lemma>obtloustlost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w5</w.rf>
   <form>vše</form>
   <lemma>všechen</lemma>
   <tag>PLNS1---------1</tag>
  </m>
  <m id="m-ln94211-75-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w6</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w8</w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w9</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94211-75-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w10</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94211-75-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s4w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94211-75-p2s5">
  <m id="m-ln94211-75-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w1</w.rf>
   <form>Královská</form>
   <lemma>královský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w2</w.rf>
   <form>postava</form>
   <lemma>postava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w4</w.rf>
   <form>komentuje</form>
   <lemma>komentovat_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94211-75-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w5</w.rf>
   <form>deník</form>
   <lemma>deník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w6</w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w8</w.rf>
   <form>tvrdí</form>
   <lemma>tvrdit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94211-75-p2s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s5w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w10</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94211-75-p2s5w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w11</w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94211-75-p2s5w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w12</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94211-75-p2s5w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w13</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m-ln94211-75-p2s5w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w14</w.rf>
   <form>publikovaný</form>
   <lemma>publikovaný_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s5w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w15</w.rf>
   <form>snímek</form>
   <lemma>snímek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s5w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w16</w.rf>
   <form>nahého</form>
   <lemma>nahý</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln94211-75-p2s5w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w17</w.rf>
   <form>Charlese</form>
   <lemma>Charles_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94211-75-p2s5w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94211-75-p2s5w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94103-059-p1s1A">
  <m id="m-lnd94103-059-p1s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Aw1</w.rf>
   <form>Salvador</form>
   <lemma>Salvador_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Aw2</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Aw3</w.rf>
   <form>volbách</form>
   <lemma>volba</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
 </s>
 <s id="m-lnd94103-059-p1s1B">
  <m id="m-lnd94103-059-p1s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Bw1</w.rf>
   <form>Boj</form>
   <lemma>boj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Bw2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Bw3</w.rf>
   <form>novou</form>
   <lemma>nový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Bw4</w.rf>
   <form>tvář</form>
   <lemma>tvář</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Bw5</w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Bw6</w.rf>
   <form>pokračuje</form>
   <lemma>pokračovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
 </s>
 <s id="m-lnd94103-059-p1s1C">
  <m id="m-lnd94103-059-p1s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Cw1</w.rf>
   <form>Konec</form>
   <lemma>konec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Cw2</w.rf>
   <form>podtitulku</form>
   <lemma>podtitulek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd94103-059-p1s1D">
  <m id="m-lnd94103-059-p1s1Dw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Dw1</w.rf>
   <form>Martin</form>
   <lemma>Martin-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Dw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Dw2</w.rf>
   <form>Ehl</form>
   <lemma>Ehl_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd94103-059-p1s1E">
  <m id="m-lnd94103-059-p1s1Ew1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew2</w.rf>
   <form>Především</form>
   <lemma>především</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew3</w.rf>
   <form>chci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew4</w.rf>
   <form>pokračovat</form>
   <lemma>pokračovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew6</w.rf>
   <form>důsledném</form>
   <lemma>důsledný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew7</w.rf>
   <form>dodržování</form>
   <lemma>dodržování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew8</w.rf>
   <form>mírových</form>
   <lemma>mírový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew9</w.rf>
   <form>dohod</form>
   <lemma>dohoda</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew11</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew12</w.rf>
   <form>prohlásil</form>
   <lemma>prohlásit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew13</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew14</w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew15</w.rf>
   <form>večer</form>
   <lemma>večer</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew16</w.rf>
   <form>budoucí</form>
   <lemma>budoucí</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew17</w.rf>
   <form>salvadorský</form>
   <lemma>salvadorský</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew18</w.rf>
   <form>prezident</form>
   <lemma>prezident</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew19</w.rf>
   <form>Armando</form>
   <lemma>Armando_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew20</w.rf>
   <form>Calderón</form>
   <lemma>Calderón_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew21</w.rf>
   <form>Sol</form>
   <lemma>Sol-2_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s1Ew22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s1Ew22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94103-059-p1s2">
  <m id="m-lnd94103-059-p1s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w1</w.rf>
   <form>Tento</form>
   <lemma>tento</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w2</w.rf>
   <form>pětačtyřicetiletý</form>
   <lemma>pětačtyřicetiletý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w3</w.rf>
   <form>právník</form>
   <lemma>právník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w4</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w5</w.rf>
   <form>počátkem</form>
   <lemma>počátek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w6</w.rf>
   <form>osmdesátých</form>
   <lemma>osmdesátý</lemma>
   <tag>CrNP2----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w7</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w8</w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS7----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w9</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w10</w.rf>
   <form>zakladatelů</form>
   <lemma>zakladatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w11</w.rf>
   <form>pravicové</form>
   <lemma>pravicový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w12</w.rf>
   <form>Národní</form>
   <lemma>národní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w13</w.rf>
   <form>republikánské</form>
   <lemma>republikánský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w14</w.rf>
   <form>aliance</form>
   <lemma>aliance</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w15</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w16</w.rf>
   <form>ARENA</form>
   <lemma>ARENA-1_:B_;K_,t_^(Alianca_Renovadora_Nacional)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w17</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w19</w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w20</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w21</w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w22</w.rf>
   <form>ustavila</form>
   <lemma>ustavit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w23</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w24</w.rf>
   <form>protiváha</form>
   <lemma>protiváha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w25</w.rf>
   <form>partyzánským</form>
   <lemma>partyzánský</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w26</w.rf>
   <form>oddílům</form>
   <lemma>oddíl</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w27</w.rf>
   <form>Fronty</form>
   <lemma>fronta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w28</w.rf>
   <form>národního</form>
   <lemma>národní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w29</w.rf>
   <form>osvobození</form>
   <lemma>osvobození_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w30</w.rf>
   <form>Farabunda</form>
   <lemma>Farabundo_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w31</w.rf>
   <form>Martího</form>
   <lemma>Martí_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w32</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w33</w.rf>
   <form>FMLN</form>
   <lemma>FMLN_:B_;K_,t</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w34</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s2w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s2w35</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94103-059-p1s3">
  <m id="m-lnd94103-059-p1s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w1</w.rf>
   <form>Salvador</form>
   <lemma>Salvador_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w3</w.rf>
   <form>stal</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w4</w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w5</w.rf>
   <form>dvanáctileté</form>
   <lemma>dvanáctiletý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w6</w.rf>
   <form>občanské</form>
   <lemma>občanský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w7</w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w8</w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>ClZS7----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w10</w.rf>
   <form>krvavých</form>
   <lemma>krvavý</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w11</w.rf>
   <form>bojišť</form>
   <lemma>bojiště</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w12</w.rf>
   <form>studené</form>
   <lemma>studený</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w13</w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s3w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94103-059-p1s4">
  <m id="m-lnd94103-059-p1s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w1</w.rf>
   <form>Prostřednictvím</form>
   <lemma>prostřednictví</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w2</w.rf>
   <form>pětimilionového</form>
   <lemma>pětimilionový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w3</w.rf>
   <form>národa</form>
   <lemma>národ</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w4</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w5</w.rf>
   <form>tu</form>
   <lemma>tady</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w6</w.rf>
   <form>vyřizovaly</form>
   <lemma>vyřizovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w7</w.rf>
   <form>své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FP4---------1</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w8</w.rf>
   <form>záležitosti</form>
   <lemma>záležitost</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w9</w.rf>
   <form>USA</form>
   <lemma>USA_;G</lemma>
   <tag>NNIPX-----A----</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w11</w.rf>
   <form>SSSR</form>
   <lemma>SSSR_:B_;G_^(Svaz_sov._socialist._republik)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-lnd94103-059-p1s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-059-p1s4w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-129-p1s1">
  <m id="m-ln94204-129-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p1s1w1</w.rf>
   <form>Ivaniševič</form>
   <lemma>Ivaniševič_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p1s1w2</w.rf>
   <form>chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-129-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p1s1w3</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-129-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p1s1w4</w.rf>
   <form>ženy</form>
   <lemma>žena</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
 </s>
 <s id="m-ln94204-129-p2s1A">
  <m id="m-ln94204-129-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Aw1</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Aw2</w.rf>
   <form>vyřazení</form>
   <lemma>vyřazení_^(*4dit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Aw3</w.rf>
   <form>prý</form>
   <lemma>prý</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Aw4</w.rf>
   <form>nemůže</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-ln94204-129-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Aw5</w.rf>
   <form>zraněné</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Aw6</w.rf>
   <form>stehno</form>
   <lemma>stehno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Aw7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Aw8</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Aw9</w.rf>
   <form>mozek</form>
   <lemma>mozek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94204-129-p2s1B">
  <m id="m-ln94204-129-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Bw1</w.rf>
   <form>New</form>
   <lemma>New-1_;G_,t_^(součást_míst._jmen)</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Bw2</w.rf>
   <form>York</form>
   <lemma>York-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Bw3</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Bw4</w.rf>
   <form>Reuter</form>
   <lemma>Reuter_;K</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Bw5</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Bw6</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-129-p2s1C">
  <m id="m-ln94204-129-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw1</w.rf>
   <form>Čím</form>
   <lemma>co-1</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw2</w.rf>
   <form>výše</form>
   <lemma>vysoko-1_^(výše_než...[uvedeno_výše])</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw4</w.rf>
   <form>chorvatský</form>
   <lemma>chorvatský</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw5</w.rf>
   <form>tenista</form>
   <lemma>tenista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw6</w.rf>
   <form>Goran</form>
   <lemma>Goran_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw7</w.rf>
   <form>Ivaniševič</form>
   <lemma>Ivaniševič_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw9</w.rf>
   <form>žebříčku</form>
   <lemma>žebříček</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw10</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw11</w.rf>
   <form>momentálně</form>
   <lemma>momentálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw12</w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw14</w.rf>
   <form>hráč</form>
   <lemma>hráč</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw15</w.rf>
   <form>ATP</form>
   <lemma>ATP-1_:B_;K_;w_,t_^(Prof._sv._asociace_tenisových_hráčů)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw16</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw18</w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw19</w.rf>
   <form>méně</form>
   <lemma>málo-3</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw20</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw21</w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>PHZS3--3-------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw22</w.rf>
   <form>daří</form>
   <lemma>dařit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw23</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw24</w.rf>
   <form>Flushing</form>
   <lemma>Flushing_;G_,t</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw25</w.rf>
   <form>Meadows</form>
   <lemma>Meadows-2_;G_,t</lemma>
   <tag>NNFPX-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s1Cw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s1Cw26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-129-p2s2">
  <m id="m-ln94204-129-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-129-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w2</w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94204-129-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w3</w.rf>
   <form>1991</form>
   <lemma>1991</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w4</w.rf>
   <form>postoupil</form>
   <lemma>postoupit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-129-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w5</w.rf>
   <form>Ivaniševič</form>
   <lemma>Ivaniševič_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94204-129-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w7</w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w9</w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w10</w.rf>
   <form>US</form>
   <lemma>US-3_:B_;m_,t_^(americký)</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-ln94204-129-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w11</w.rf>
   <form>Open</form>
   <lemma>Open-1_,t_^(v_názvu_např._sport._soutěží,_"otevřený")</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w13</w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PE--1----------</tag>
  </m>
  <m id="m-ln94204-129-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w14</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-129-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w15</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln94204-129-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w16</w.rf>
   <form>dosavadní</form>
   <lemma>dosavadní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w17</w.rf>
   <form>maximum</form>
   <lemma>maximum</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s2w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-129-p2s3">
  <m id="m-ln94204-129-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w1</w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w2</w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w3</w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w4</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94204-129-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w5</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w6</w.rf>
   <form>výkony</form>
   <lemma>výkon</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w8</w.rf>
   <form>New</form>
   <lemma>New-1_;G_,t_^(součást_míst._jmen)</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w9</w.rf>
   <form>Yorku</form>
   <lemma>York-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w10</w.rf>
   <form>pravidelně</form>
   <lemma>pravidelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w11</w.rf>
   <form>sestupnou</form>
   <lemma>sestupný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w12</w.rf>
   <form>tendenci</form>
   <lemma>tendence</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w14</w.rf>
   <form>čemuž</form>
   <lemma>což-1</lemma>
   <tag>PE--3----------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w15</w.rf>
   <form>odpovídá</form>
   <lemma>odpovídat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-129-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w16</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w17</w.rf>
   <form>letošní</form>
   <lemma>letošní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w18</w.rf>
   <form>výsledek</form>
   <lemma>výsledek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w19</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w21</w.rf>
   <form>posledním</form>
   <lemma>poslední</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w22</w.rf>
   <form>grandslamovém</form>
   <lemma>grandslamový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w23</w.rf>
   <form>turnaji</form>
   <lemma>turnaj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w24</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-ln94204-129-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w25</w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>PHZS4--3-------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w26</w.rf>
   <form>Němec</form>
   <lemma>Němec-2_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w27</w.rf>
   <form>Markus</form>
   <lemma>Markus_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w28</w.rf>
   <form>Zoecke</form>
   <lemma>Zoecke_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w29</w.rf>
   <form>vyřadil</form>
   <lemma>vyřadit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-129-p2s3w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w30</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w31</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w32</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-129-p2s3w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w33</w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94204-129-p2s3w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-129-p2s3w34</w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-123-p1s1">
  <m id="m-mf920925-123-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p1s1w1</w.rf>
   <form>Výsledek</form>
   <lemma>výsledek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf920925-123-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p1s1w2</w.rf>
   <form>voleb</form>
   <lemma>volba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p1s1w3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-mf920925-123-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p1s1w4</w.rf>
   <form>těsný</form>
   <lemma>těsný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
 </s>
 <s id="m-mf920925-123-p2s1">
  <m id="m-mf920925-123-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p2s1w1</w.rf>
   <form>RUMUNSKO</form>
   <lemma>Rumunsko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf920925-123-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p2s1w2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-123-p3s1">
  <m id="m-mf920925-123-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p3s1w1</w.rf>
   <form>Výsledek</form>
   <lemma>výsledek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf920925-123-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p3s1w2</w.rf>
   <form>voleb</form>
   <lemma>volba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p3s1w3</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-mf920925-123-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p3s1w4</w.rf>
   <form>těsný</form>
   <lemma>těsný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
 </s>
 <s id="m-mf920925-123-p4s1">
  <m id="m-mf920925-123-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s1w1</w.rf>
   <form>Bukurešť</form>
   <lemma>Bukurešť_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s1w2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-123-p4s2">
  <m id="m-mf920925-123-p4s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w1</w.rf>
   <form>Včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-123-p4s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w3</w.rf>
   <form>Rumunsku</form>
   <lemma>Rumunsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w4</w.rf>
   <form>vyvrcholila</form>
   <lemma>vyvrcholit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf920925-123-p4s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w5</w.rf>
   <form>kampaň</form>
   <lemma>kampaň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w6</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-mf920925-123-p4s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w7</w.rf>
   <form>nedělním</form>
   <lemma>nedělní</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w8</w.rf>
   <form>parlamentním</form>
   <lemma>parlamentní</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w10</w.rf>
   <form>prezidentským</form>
   <lemma>prezidentský</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w11</w.rf>
   <form>volbám</form>
   <lemma>volba</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s2w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-123-p4s3">
  <m id="m-mf920925-123-p4s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w1</w.rf>
   <form>Odhady</form>
   <lemma>odhad</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w2</w.rf>
   <form>hovoří</form>
   <lemma>hovořit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf920925-123-p4s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w4</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w5</w.rf>
   <form>opoziční</form>
   <lemma>opoziční</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w6</w.rf>
   <form>koalice</form>
   <lemma>koalice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w7</w.rf>
   <form>Demokratický</form>
   <lemma>demokratický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w8</w.rf>
   <form>konvent</form>
   <lemma>konvent</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w9</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w10</w.rf>
   <form>mohla</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf920925-123-p4s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w11</w.rf>
   <form>získat</form>
   <lemma>získat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w12</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w13</w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w14</w.rf>
   <form>procent</form>
   <lemma>procento</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w16</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-mf920925-123-p4s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w17</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w18</w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NA---</tag>
  </m>
  <m id="m-mf920925-123-p4s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w19</w.rf>
   <form>stačit</form>
   <lemma>stačit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w20</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920925-123-p4s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w21</w.rf>
   <form>vytvoření</form>
   <lemma>vytvoření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w22</w.rf>
   <form>vlády</form>
   <lemma>vláda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w23</w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920925-123-p4s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w24</w.rf>
   <form>koaličních</form>
   <lemma>koaliční</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w25</w.rf>
   <form>partnerů</form>
   <lemma>partner</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s3w26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-123-p4s4">
  <m id="m-mf920925-123-p4s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-123-p4s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w2</w.rf>
   <form>druhém</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w3</w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920925-123-p4s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w5</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-mf920925-123-p4s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w6</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w7</w.rf>
   <form>procenty</form>
   <lemma>procento</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w8</w.rf>
   <form>kryptokomunistická</form>
   <lemma>kryptokomunistický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w9</w.rf>
   <form>Demokratická</form>
   <lemma>demokratický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w10</w.rf>
   <form>fronta</form>
   <lemma>fronta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w11</w.rf>
   <form>národní</form>
   <lemma>národní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w12</w.rf>
   <form>spásy</form>
   <lemma>spása</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s4w13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-123-p4s5">
  <m id="m-mf920925-123-p4s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w1</w.rf>
   <form>Vládní</form>
   <lemma>vládní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w2</w.rf>
   <form>Fronta</form>
   <lemma>fronta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w3</w.rf>
   <form>národní</form>
   <lemma>národní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w4</w.rf>
   <form>spásy</form>
   <lemma>spása</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w5</w.rf>
   <form>může</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920925-123-p4s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w6</w.rf>
   <form>očekávat</form>
   <lemma>očekávat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf920925-123-p4s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w7</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920925-123-p4s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w8</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w9</w.rf>
   <form>procent</form>
   <lemma>procento</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s5w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w10</w.rf>
   <form>hlasů</form>
   <lemma>hlas</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s5w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s5w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-123-p4s6">
  <m id="m-mf920925-123-p4s6w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w1</w.rf>
   <form>Žádná</form>
   <lemma>žádný</lemma>
   <tag>PWFS1----------</tag>
  </m>
  <m id="m-mf920925-123-p4s6w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w2</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920925-123-p4s6w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w3</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-mf920925-123-p4s6w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w4</w.rf>
   <form>84</form>
   <lemma>84</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s6w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w5</w.rf>
   <form>stran</form>
   <lemma>strana-2_^(politická)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s6w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s6w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w7</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-mf920925-123-p4s6w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf920925-123-p4s6w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w9</w.rf>
   <form>voleb</form>
   <lemma>volba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s6w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w10</w.rf>
   <form>zúčastní</form>
   <lemma>zúčastnit_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf920925-123-p4s6w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s6w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w12</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s6w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w13</w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW---XR-NA---</tag>
  </m>
  <m id="m-mf920925-123-p4s6w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w14</w.rf>
   <form>přesáhnout</form>
   <lemma>přesáhnout</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf920925-123-p4s6w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w15</w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-123-p4s6w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w16</w.rf>
   <form>procent</form>
   <lemma>procento</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-mf920925-123-p4s6w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-123-p4s6w17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-029-p1s1">
  <m id="m-mf920922-029-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p1s1w1</w.rf>
   <form>Narozeniny</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf920922-029-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p1s1w2</w.rf>
   <form>jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf920922-029-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p1s1w3</w.rf>
   <form>provokace</form>
   <lemma>provokace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-mf920922-029-p2s1">
  <m id="m-mf920922-029-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w1</w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w2</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w3</w.rf>
   <form>provokací</form>
   <lemma>provokace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w4</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf920922-029-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w5</w.rf>
   <form>hra</form>
   <lemma>hra_^(dětská;_v_divadle;...)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w6</w.rf>
   <form>Jaroslava</form>
   <lemma>Jaroslav_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w7</w.rf>
   <form>Duška</form>
   <lemma>Dušek_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w8</w.rf>
   <form>Narozeniny</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w10</w.rf>
   <form>uvedená</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920922-029-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w12</w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920922-029-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w14</w.rf>
   <form>stanici</form>
   <lemma>stanice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w15</w.rf>
   <form>Vltava</form>
   <lemma>Vltava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920922-029-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w17</w.rf>
   <form>režii</form>
   <lemma>režie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w18</w.rf>
   <form>Michala</form>
   <lemma>Michal_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w19</w.rf>
   <form>Pavlíka</form>
   <lemma>Pavlík_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w21</w.rf>
   <form>nedá</form>
   <lemma>dát</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-mf920922-029-p2s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w22</w.rf>
   <form>nazvat</form>
   <lemma>nazvat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf920922-029-p2s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s1w23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-029-p2s2">
  <m id="m-mf920922-029-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w1</w.rf>
   <form>Spotřebitelské</form>
   <lemma>spotřebitelský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-mf920922-029-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w2</w.rf>
   <form>fráze</form>
   <lemma>fráze</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w3</w.rf>
   <form>rodinného</form>
   <lemma>rodinný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf920922-029-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w4</w.rf>
   <form>života</form>
   <lemma>život</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w5</w.rf>
   <form>soupeří</form>
   <lemma>soupeřit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf920922-029-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-mf920922-029-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w7</w.rf>
   <form>hravostí</form>
   <lemma>hravost_^(*3ý)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w8</w.rf>
   <form>snu</form>
   <lemma>sen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w10</w.rf>
   <form>fantazie</form>
   <lemma>fantazie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s2w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-029-p2s3">
  <m id="m-mf920922-029-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w1</w.rf>
   <form>Rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w2</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-mf920922-029-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w3</w.rf>
   <form>pletou</form>
   <lemma>plést</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf920922-029-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w5</w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w6</w.rf>
   <form>vypadá</form>
   <lemma>vypadat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-029-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w7</w.rf>
   <form>jejich</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXXP3-------</tag>
  </m>
  <m id="m-mf920922-029-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w8</w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w10</w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4MS4----------</tag>
  </m>
  <m id="m-mf920922-029-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w11</w.rf>
   <form>už</form>
   <lemma>už</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w12</w.rf>
   <form>dávno</form>
   <lemma>dávno</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-mf920922-029-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w13</w.rf>
   <form>nevnímají</form>
   <lemma>vnímat_:T</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-mf920922-029-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w14</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w15</w.rf>
   <form>přesto</form>
   <lemma>přesto</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-mf920922-029-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w16</w.rf>
   <form>slaví</form>
   <lemma>slavit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf920922-029-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w17</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-mf920922-029-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w18</w.rf>
   <form>narozeniny</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s3w19</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-029-p2s4">
  <m id="m-mf920922-029-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s4w1</w.rf>
   <form>Ještě</form>
   <lemma>ještě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s4w2</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-mf920922-029-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s4w3</w.rf>
   <form>je</form>
   <lemma>on-1_^(oni/ono)</lemma>
   <tag>PPXP4--3-------</tag>
  </m>
  <m id="m-mf920922-029-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s4w4</w.rf>
   <form>zmate</form>
   <lemma>zmást</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-029-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s4w5</w.rf>
   <form>návštěva</form>
   <lemma>návštěva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s4w6</w.rf>
   <form>smyšlených</form>
   <lemma>smyšlený_^(*5slet)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-mf920922-029-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s4w7</w.rf>
   <form>bytostí</form>
   <lemma>bytost</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s4w8</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920922-029-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s4w9</w.rf>
   <form>éteru</form>
   <lemma>éter</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s4w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-029-p2s5">
  <m id="m-mf920922-029-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w1</w.rf>
   <form>Druhým</form>
   <lemma>druhý-2</lemma>
   <tag>CrIS7----------</tag>
  </m>
  <m id="m-mf920922-029-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w2</w.rf>
   <form>plánem</form>
   <lemma>plán</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w3</w.rf>
   <form>hry</form>
   <lemma>hra_^(dětská;_v_divadle;...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-029-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w5</w.rf>
   <form>totiž</form>
   <lemma>totiž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w6</w.rf>
   <form>dialogizovaný</form>
   <lemma>dialogizovaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf920922-029-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w7</w.rf>
   <form>text</form>
   <lemma>text</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w8</w.rf>
   <form>humorné</form>
   <lemma>humorný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920922-029-p2s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w9</w.rf>
   <form>prózy</form>
   <lemma>próza</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s5w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w10</w.rf>
   <form>Rosti</form>
   <lemma>Rosťa_;Y_,h</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s5w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w11</w.rf>
   <form>Volného</form>
   <lemma>Volný_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s5w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s5w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w13</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-mf920922-029-p2s5w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w14</w.rf>
   <form>obrací</form>
   <lemma>obracet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-029-p2s5w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w15</w.rf>
   <form>vše</form>
   <lemma>všechen</lemma>
   <tag>PLNS4---------1</tag>
  </m>
  <m id="m-mf920922-029-p2s5w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w16</w.rf>
   <form>naruby</form>
   <lemma>naruby</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s5w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s5w17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-029-p2s6">
  <m id="m-mf920922-029-p2s6w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w1</w.rf>
   <form>Inscenace</form>
   <lemma>inscenace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-029-p2s6w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-029-p2s6w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w3</w.rf>
   <form>zábavná</form>
   <lemma>zábavný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf920922-029-p2s6w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w4</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s6w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w5</w.rf>
   <form>smutná</form>
   <lemma>smutný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf920922-029-p2s6w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w6</w.rf>
   <form>právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s6w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w7</w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-mf920922-029-p2s6w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s6w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w9</w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf920922-029-p2s6w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w10</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf920922-029-p2s6w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w11</w.rf>
   <form>nám</form>
   <lemma>já</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m-mf920922-029-p2s6w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w12</w.rf>
   <form>podobá</form>
   <lemma>podobat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-029-p2s6w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-029-p2s6w13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
