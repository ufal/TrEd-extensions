<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="sample2.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94208-113-p1s1">
  <m id="m-ln94208-113-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p1s1w1</w.rf>
   <form>Krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
 </s>
 <s id="m-ln94208-113-p2s1">
  <m id="m-ln94208-113-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w1</w.rf>
   <form>Družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94208-113-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w2</w.rf>
   <form>českých</form>
   <lemma>český</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94208-113-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w3</w.rf>
   <form>motoristů</form>
   <lemma>motorista</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94208-113-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w4</w.rf>
   <form>obsadilo</form>
   <lemma>obsadit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-113-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w5</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-113-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w6</w.rf>
   <form>Trialu</form>
   <lemma>trial</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94208-113-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w7</w.rf>
   <form>národů</form>
   <lemma>národ</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94208-113-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-113-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w9</w.rf>
   <form>Andoře</form>
   <lemma>Andorra_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94208-113-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w10</w.rf>
   <form>deváté</form>
   <lemma>devátý</lemma>
   <tag>CrNS4----------</tag>
  </m>
  <m id="m-ln94208-113-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w11</w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94208-113-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-113-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w13</w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PE--1----------</tag>
  </m>
  <m id="m-ln94208-113-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w14</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-113-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w15</w.rf>
   <form>nejlepší</form>
   <lemma>dobrý</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="m-ln94208-113-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w16</w.rf>
   <form>výsledek</form>
   <lemma>výsledek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-113-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w17</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-113-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w18</w.rf>
   <form>historii</form>
   <lemma>historie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94208-113-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w19</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-ln94208-113-p2s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w20</w.rf>
   <form>odvětví</form>
   <lemma>odvětví</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94208-113-p2s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p2s1w21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-113-p3s1">
  <m id="m-ln94208-113-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w1</w.rf>
   <form>Pětice</form>
   <lemma>pětice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w2</w.rf>
   <form>finských</form>
   <lemma>finský</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94208-113-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w3</w.rf>
   <form>vzpěračů</form>
   <lemma>vzpěrač</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w4</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94208-113-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w5</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS7---------1</tag>
  </m>
  <m id="m-ln94208-113-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w6</w.rf>
   <form>národní</form>
   <lemma>národní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94208-113-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w7</w.rf>
   <form>federací</form>
   <lemma>federace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w8</w.rf>
   <form>potrestána</form>
   <lemma>potrestat_:W</lemma>
   <tag>VsQW---XX-AP---</tag>
  </m>
  <m id="m-ln94208-113-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w9</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94208-113-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w10</w.rf>
   <form>doping</form>
   <lemma>doping</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s1w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-113-p3s2">
  <m id="m-ln94208-113-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w1</w.rf>
   <form>Tříletý</form>
   <lemma>tříletý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94208-113-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w2</w.rf>
   <form>zákaz</form>
   <lemma>zákaz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w3</w.rf>
   <form>startu</form>
   <lemma>start</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w4</w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94208-113-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w5</w.rf>
   <form>Oravainen</form>
   <lemma>Oravainen_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-113-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w7</w.rf>
   <form>Viitala</form>
   <lemma>Viitala_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-113-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w9</w.rf>
   <form>Parantainen</form>
   <lemma>Parantainen_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-113-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w11</w.rf>
   <form>Vepsalainen</form>
   <lemma>Vepsalainen_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-113-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w13</w.rf>
   <form>Laitinen</form>
   <lemma>Laitinen_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s2w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-113-p3s3">
  <m id="m-ln94208-113-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w1</w.rf>
   <form>Všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-ln94208-113-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w2</w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln94208-113-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w3</w.rf>
   <form>pozitivní</form>
   <lemma>pozitivní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94208-113-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w4</w.rf>
   <form>nález</form>
   <lemma>nález</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w5</w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-113-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w6</w.rf>
   <form>testů</form>
   <lemma>test</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w7</w.rf>
   <form>prováděných</form>
   <lemma>prováděný_^(*2t)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94208-113-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-113-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w9</w.rf>
   <form>dubnu</form>
   <lemma>duben</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-113-p3s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w11</w.rf>
   <form>červnu</form>
   <lemma>červen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94208-113-p3s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-113-p3s3w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-49-p1s1">
  <m id="m-ln94208-49-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p1s1w1</w.rf>
   <form>Druhý</form>
   <lemma>druhý-2</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-ln94208-49-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p1s1w2</w.rf>
   <form>ročník</form>
   <lemma>ročník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-49-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p1s1w3</w.rf>
   <form>běhu</form>
   <lemma>běh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p1s1w4</w.rf>
   <form>politiků</form>
   <lemma>politik</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p1s1w5</w.rf>
   <form>Špilberkem</form>
   <lemma>Špilberk_;G</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
 </s>
 <s id="m-ln94208-49-p2s1A">
  <m id="m-ln94208-49-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Aw1</w.rf>
   <form>Brno</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-49-p2s1B">
  <m id="m-ln94208-49-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw1</w.rf>
   <form>Již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw2</w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw3</w.rf>
   <form>ministrů</form>
   <lemma>ministr</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw5</w.rf>
   <form>poslanců</form>
   <lemma>poslanec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw6</w.rf>
   <form>parlamentu</form>
   <lemma>parlament</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw7</w.rf>
   <form>projevilo</form>
   <lemma>projevit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw8</w.rf>
   <form>zájem</form>
   <lemma>zájem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw9</w.rf>
   <form>startovat</form>
   <lemma>startovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw10</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw11</w.rf>
   <form>druhém</form>
   <lemma>druhý-2</lemma>
   <tag>CrIS6----------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw12</w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw13</w.rf>
   <form>běhu</form>
   <lemma>běh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw14</w.rf>
   <form>Špilberkem</form>
   <lemma>Špilberk_;G</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw16</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw17</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw18</w.rf>
   <form>uskuteční</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw19</w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw21</w.rf>
   <form>října</form>
   <lemma>říjen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw23</w.rf>
   <form>parku</form>
   <lemma>park</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw24</w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw25</w.rf>
   <form>brněnského</form>
   <lemma>brněnský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw26</w.rf>
   <form>hradu</form>
   <lemma>hrad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s1Bw27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-49-p2s2">
  <m id="m-ln94208-49-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w1</w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-49-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w2</w.rf>
   <form>zástupců</form>
   <lemma>zástupce</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w3</w.rf>
   <form>pořádající</form>
   <lemma>pořádající_^(*4t)</lemma>
   <tag>AGFS2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w4</w.rf>
   <form>nadace</form>
   <lemma>nadace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w5</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94208-49-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-49-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w8</w.rf>
   <form>startu</form>
   <lemma>start</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w9</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-49-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w10</w.rf>
   <form>objevit</form>
   <lemma>objevit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w11</w.rf>
   <form>mj</form>
   <lemma>mj-1_:B_^(mimo_jiné)</lemma>
   <tag>Db------------8</tag>
  </m>
  <m id="m-ln94208-49-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w13</w.rf>
   <form>ministr</form>
   <lemma>ministr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w14</w.rf>
   <form>Zieleniec</form>
   <lemma>Zieleniec_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w16</w.rf>
   <form>zastupitelé</form>
   <lemma>zastupitel_,a</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w17</w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w19</w.rf>
   <form>Bratislavy</form>
   <lemma>Bratislava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w21</w.rf>
   <form>herci</form>
   <lemma>herec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w22</w.rf>
   <form>brněnských</form>
   <lemma>brněnský</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w23</w.rf>
   <form>divadel</form>
   <lemma>divadlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s2w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-49-p2s3">
  <m id="m-ln94208-49-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w1</w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w2</w.rf>
   <form>druhý</form>
   <lemma>druhý-2</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w3</w.rf>
   <form>ročník</form>
   <lemma>ročník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-49-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w5</w.rf>
   <form>připraveno</form>
   <lemma>připravit_:W</lemma>
   <tag>VsNS---XX-AP---</tag>
  </m>
  <m id="m-ln94208-49-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w6</w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cn-S1----------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w7</w.rf>
   <form>kategorií</form>
   <lemma>kategorie</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w9</w.rf>
   <form>politici</form>
   <lemma>politik</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w11</w.rf>
   <form>45</form>
   <lemma>45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w12</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w13</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w14</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w15</w.rf>
   <form>45</form>
   <lemma>45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w16</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w18</w.rf>
   <form>osobnosti</form>
   <lemma>osobnost</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w19</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w20</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w21</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w22</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w23</w.rf>
   <form>řadí</form>
   <lemma>řadit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94208-49-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w24</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w25</w.rf>
   <form>novináři</form>
   <lemma>novinář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w27</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w28</w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-ln94208-49-p2s3w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w29</w.rf>
   <form>vysokoškolští</form>
   <lemma>vysokoškolský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94208-49-p2s3w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w30</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-49-p2s3w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w31</w.rf>
   <form>středoškolští</form>
   <lemma>středoškolský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94208-49-p2s3w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w32</w.rf>
   <form>studenti</form>
   <lemma>student</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94208-49-p2s3w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-49-p2s3w33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94103-038-p1s1">
  <m id="m-lnd94103-038-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s1w1</w.rf>
   <form>ODS</form>
   <lemma>ODS-1_:B_;K_;p_^(Občanská_demokratická_strana)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-lnd94103-038-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s1w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s1w3</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s1w4</w.rf>
   <form>Petrové</form>
   <lemma>Petrová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s1w5</w.rf>
   <form>obávala</form>
   <lemma>obávat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-038-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s1w6</w.rf>
   <form>prolomení</form>
   <lemma>prolomení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s1w7</w.rf>
   <form>restituční</form>
   <lemma>restituční</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s1w8</w.rf>
   <form>hranice</form>
   <lemma>hranice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd94103-038-p1s2">
  <m id="m-lnd94103-038-p1s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s2w1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s2w2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s2w3</w.rf>
   <form>mst</form>
   <lemma>mst-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-lnd94103-038-p1s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s2w4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s2w5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94103-038-p1s3">
  <m id="m-lnd94103-038-p1s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w1</w.rf>
   <form>Přijetí</form>
   <lemma>přijetí-2_^(např._návrh)_(*5mout-2)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w2</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w4</w.rf>
   <form>restitucích</form>
   <lemma>restituce</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w5</w.rf>
   <form>židovského</form>
   <lemma>židovský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w6</w.rf>
   <form>majetku</form>
   <lemma>majetek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w8</w.rf>
   <form>podobě</form>
   <lemma>podoba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w10</w.rf>
   <form>jakou</form>
   <lemma>jaký</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w11</w.rf>
   <form>navrhoval</form>
   <lemma>navrhovat_:T</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w12</w.rf>
   <form>Viktor</form>
   <lemma>Viktor_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w13</w.rf>
   <form>Dobal</form>
   <lemma>Dobal_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w14</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w15</w.rf>
   <form>ODA</form>
   <lemma>ODA-2_:B_;K_;p_^(Občanská_demokratická_aliance)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w16</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w18</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w19</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w20</w.rf>
   <form>mluvčí</form>
   <lemma>mluvčí</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w21</w.rf>
   <form>ODS</form>
   <lemma>ODS-1_:B_;K_;p_^(Občanská_demokratická_strana)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w22</w.rf>
   <form>J</form>
   <lemma>j-3_^(označení_pomocí_písmene)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w23</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w24</w.rf>
   <form>Petrové</form>
   <lemma>Petrová_;S</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w25</w.rf>
   <form>znamenalo</form>
   <lemma>znamenat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w26</w.rf>
   <form>faktické</form>
   <lemma>faktický</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w27</w.rf>
   <form>prolomení</form>
   <lemma>prolomení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w28</w.rf>
   <form>restituční</form>
   <lemma>restituční</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w29</w.rf>
   <form>hranice</form>
   <lemma>hranice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w30</w.rf>
   <form>dané</form>
   <lemma>daný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w31</w.rf>
   <form>rokem</form>
   <lemma>rok</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w32</w.rf>
   <form>1948</form>
   <lemma>1948</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s3w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s3w33</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94103-038-p1s4">
  <m id="m-lnd94103-038-p1s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w1</w.rf>
   <form>Mluvčí</form>
   <lemma>mluvčí</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w2</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w3</w.rf>
   <form>reagovala</form>
   <lemma>reagovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w4</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w5</w.rf>
   <form>otázku</form>
   <lemma>otázka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w6</w.rf>
   <form>LN</form>
   <lemma>LN-1_:B_;R_^(Lidové_noviny,_deník)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w8</w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w9</w.rf>
   <form>ODS</form>
   <lemma>ODS-1_:B_;K_;p_^(Občanská_demokratická_strana)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w10</w.rf>
   <form>prosadila</form>
   <lemma>prosadit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w12</w.rf>
   <form>zákona</form>
   <lemma>zákon</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w13</w.rf>
   <form>pozměňovací</form>
   <lemma>pozměňovací_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w14</w.rf>
   <form>návrh</form>
   <lemma>návrh</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w16</w.rf>
   <form>jehož</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>PJZS2----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w17</w.rf>
   <form>schválením</form>
   <lemma>schválení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w18</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w19</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w20</w.rf>
   <form>odškodnění</form>
   <lemma>odškodnění_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w21</w.rf>
   <form>nárok</form>
   <lemma>nárok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w22</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w23</w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w25</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w26</w.rf>
   <form>přišly</form>
   <lemma>přijít</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w27</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w28</w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w29</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w30</w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w31</w.rf>
   <form>rasových</form>
   <lemma>rasový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w32</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w33</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w34</w.rf>
   <form>ne</form>
   <lemma>ne</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w35</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w36</w.rf>
   <form>národnostních</form>
   <lemma>národnostní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w37</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w38</w.rf>
   <form>politických</form>
   <lemma>politický</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-lnd94103-038-p1s4w39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-lnd94103-038-p1s4w39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-044-p1s1A">
  <m id="m-mf920922-044-p1s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Aw1</w.rf>
   <form>Pole</form>
   <lemma>pole</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Aw2</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920922-044-p1s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Aw3</w.rf>
   <form>léčebnu</form>
   <lemma>léčebna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Aw4</w.rf>
   <form>Kroměříž</form>
   <lemma>Kroměříž_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Aw5</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Aw6</w.rf>
   <form>do</form>
   <lemma>do-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-mf920922-044-p1s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Aw7</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Aw8</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-044-p1s1B">
  <m id="m-mf920922-044-p1s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Bw1</w.rf>
   <form>Navrácení</form>
   <lemma>navrácení_^(*4tit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Bw2</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Bw3</w.rf>
   <form>hektarů</form>
   <lemma>ha-1`hektar</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Bw4</w.rf>
   <form>polí</form>
   <lemma>pole</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Bw5</w.rf>
   <form>žádá</form>
   <lemma>žádat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Bw6</w.rf>
   <form>Psychiatrická</form>
   <lemma>psychiatrický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-mf920922-044-p1s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Bw7</w.rf>
   <form>léčebna</form>
   <lemma>léčebna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Bw8</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920922-044-p1s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Bw9</w.rf>
   <form>Kroměříži</form>
   <lemma>Kroměříž_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s1Bw10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-044-p1s2">
  <m id="m-mf920922-044-p1s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w1</w.rf>
   <form>Před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-mf920922-044-p1s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w2</w.rf>
   <form>válkou</form>
   <lemma>válka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w3</w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w4</w.rf>
   <form>léčebna</form>
   <lemma>léčebna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w5</w.rf>
   <form>svou</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-mf920922-044-p1s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w6</w.rf>
   <form>farmu</form>
   <lemma>farma</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w8</w.rf>
   <form>pěstovala</form>
   <lemma>pěstovat_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w9</w.rf>
   <form>krávy</form>
   <lemma>kráva</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w11</w.rf>
   <form>prasata</form>
   <lemma>prase</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w13</w.rf>
   <form>hospodařila</form>
   <lemma>hospodařit_:T</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920922-044-p1s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w15</w.rf>
   <form>polích</form>
   <lemma>pole</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w17</w.rf>
   <form>vedla</form>
   <lemma>vést-1</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w18</w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-mf920922-044-p1s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w19</w.rf>
   <form>zahradnictví</form>
   <lemma>zahradnictví</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s2w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-044-p1s3">
  <m id="m-mf920922-044-p1s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s3w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920922-044-p1s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s3w2</w.rf>
   <form>padesátých</form>
   <lemma>padesátý</lemma>
   <tag>CrNP6----------</tag>
  </m>
  <m id="m-mf920922-044-p1s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s3w3</w.rf>
   <form>letech</form>
   <lemma>rok</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s3w4</w.rf>
   <form>komunisté</form>
   <lemma>komunista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s3w5</w.rf>
   <form>vše</form>
   <lemma>všechen</lemma>
   <tag>PLNS4---------1</tag>
  </m>
  <m id="m-mf920922-044-p1s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s3w6</w.rf>
   <form>zabavili</form>
   <lemma>zabavit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s3w7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-044-p1s4">
  <m id="m-mf920922-044-p1s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w1</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920922-044-p1s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w2</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m-mf920922-044-p1s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w3</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w4</w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-mf920922-044-p1s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w5</w.rf>
   <form>hospodářství</form>
   <lemma>hospodářství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w6</w.rf>
   <form>krylo</form>
   <lemma>krýt</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w7</w.rf>
   <form>náklady</form>
   <lemma>náklad</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920922-044-p1s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w9</w.rf>
   <form>provoz</form>
   <lemma>provoz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w10</w.rf>
   <form>léčebny</form>
   <lemma>léčebna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w11</w.rf>
   <form>přibližně</form>
   <lemma>přibližně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-mf920922-044-p1s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w12</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920922-044-p1s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w13</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w14</w.rf>
   <form>procent</form>
   <lemma>procento</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s4w15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-044-p1s5">
  <m id="m-mf920922-044-p1s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w1</w.rf>
   <form>Pojišťovna</form>
   <lemma>pojišťovna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w2</w.rf>
   <form>přispívala</form>
   <lemma>přispívat_:T_^(*4ět)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w3</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w4</w.rf>
   <form>procenty</form>
   <lemma>procento</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w6</w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w7</w.rf>
   <form>dalšími</form>
   <lemma>další</lemma>
   <tag>AANP7----1A----</tag>
  </m>
  <m id="m-mf920922-044-p1s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w8</w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w9</w.rf>
   <form>procenty</form>
   <lemma>procento</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s5w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s5w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w11</w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s5w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w12</w.rf>
   <form>procent</form>
   <lemma>procento</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s5w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w13</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-mf920922-044-p1s5w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w14</w.rf>
   <form>platili</form>
   <lemma>platit_:T_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s5w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w15</w.rf>
   <form>sami</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-mf920922-044-p1s5w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w16</w.rf>
   <form>pacienti</form>
   <lemma>pacient</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s5w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s5w17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920922-044-p1s6">
  <m id="m-mf920922-044-p1s6w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w1</w.rf>
   <form>Za</form>
   <lemma>za-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920922-044-p1s6w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w2</w.rf>
   <form>současného</form>
   <lemma>současný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf920922-044-p1s6w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w3</w.rf>
   <form>stavu</form>
   <lemma>stav</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s6w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s6w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w5</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s6w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w6</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf920922-044-p1s6w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w7</w.rf>
   <form>léčebna</form>
   <lemma>léčebna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s6w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w8</w.rf>
   <form>potýká</form>
   <lemma>potýkat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s6w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w9</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-mf920922-044-p1s6w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w10</w.rf>
   <form>obrovskými</form>
   <lemma>obrovský</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-mf920922-044-p1s6w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w11</w.rf>
   <form>finančními</form>
   <lemma>finanční</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-mf920922-044-p1s6w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w12</w.rf>
   <form>potížemi</form>
   <lemma>potíž</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s6w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s6w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w14</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s6w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w15</w.rf>
   <form>ráda</form>
   <lemma>rád</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m-mf920922-044-p1s6w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w16</w.rf>
   <form>znovu</form>
   <lemma>znovu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920922-044-p1s6w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w17</w.rf>
   <form>obnovila</form>
   <lemma>obnovit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf920922-044-p1s6w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w18</w.rf>
   <form>svoji</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS4----------</tag>
  </m>
  <m id="m-mf920922-044-p1s6w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w19</w.rf>
   <form>farmu</form>
   <lemma>farma</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf920922-044-p1s6w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920922-044-p1s6w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95047-085-p1s1">
  <m id="m-ln95047-085-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p1s1w1</w.rf>
   <form>Připlácení</form>
   <lemma>připlácení_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95047-085-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p1s1w2</w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln95047-085-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p1s1w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95047-085-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p1s1w4</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95047-085-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p1s1w5</w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-ln95047-085-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p1s1w6</w.rf>
   <form>dál</form>
   <lemma>dále-3_^(také,_za_další,_popořadě;_čas._i_míst.;_nestupňuje_se)</lemma>
   <tag>Db-------------</tag>
  </m>
 </s>
 <s id="m-ln95047-085-p2s1A">
  <m id="m-ln95047-085-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Aw1</w.rf>
   <form>Komentáře</form>
   <lemma>komentář</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
 </s>
 <s id="m-ln95047-085-p2s1B">
  <m id="m-ln95047-085-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw1</w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw2</w.rf>
   <form>druhého</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw3</w.rf>
   <form>pololetí</form>
   <lemma>pololetí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw4</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw5</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw6</w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw7</w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw8</w.rf>
   <form>pacienti</form>
   <lemma>pacient</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw9</w.rf>
   <form>nemocnic</form>
   <lemma>nemocnice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw10</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw11</w.rf>
   <form>výjimkou</form>
   <lemma>výjimka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw12</w.rf>
   <form>dětí</form>
   <lemma>dítě</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw13</w.rf>
   <form>připlácet</form>
   <lemma>připlácet_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw14</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrIP4----------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw15</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw16</w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw17</w.rf>
   <form>hospitalizace</form>
   <lemma>hospitalizace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw18</w.rf>
   <form>55</form>
   <lemma>55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw19</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw20</w.rf>
   <form>denně</form>
   <lemma>denně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw21</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw22</w.rf>
   <form>říkajíc</form>
   <lemma>říkat_:T</lemma>
   <tag>VeHS------A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw23</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw24</w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw25</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw26</w.rf>
   <form>stravu</form>
   <lemma>strava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s1Bw27</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95047-085-p2s2">
  <m id="m-ln95047-085-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s2w1</w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95047-085-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s2w2</w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-ln95047-085-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s2w3</w.rf>
   <form>zdůraznit</form>
   <lemma>zdůraznit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95047-085-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s2w4</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s2w5</w.rf>
   <form>připlácet</form>
   <lemma>připlácet_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95047-085-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s2w6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s2w7</w.rf>
   <form>nikoli</form>
   <lemma>nikoliv</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-ln95047-085-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s2w8</w.rf>
   <form>platit</form>
   <lemma>platit_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95047-085-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s2w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95047-085-p2s3">
  <m id="m-ln95047-085-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w1</w.rf>
   <form>Navrhovaná</form>
   <lemma>navrhovaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln95047-085-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w2</w.rf>
   <form>částka</form>
   <lemma>částka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95047-085-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w4</w.rf>
   <form>totiž</form>
   <lemma>totiž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w5</w.rf>
   <form>jen</form>
   <lemma>jen-1_^(pouze)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w6</w.rf>
   <form>zlomkem</form>
   <lemma>zlomek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w7</w.rf>
   <form>nákladů</form>
   <lemma>náklad</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w9</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m-ln95047-085-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w10</w.rf>
   <form>pobyt</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w11</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95047-085-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w12</w.rf>
   <form>nemocnicích</form>
   <lemma>nemocnice</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w13</w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95047-085-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w14</w.rf>
   <form>stojí</form>
   <lemma>stát-4_^(něco_stojí_peníze)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95047-085-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s3w15</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95047-085-p2s4">
  <m id="m-ln95047-085-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s4w1</w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m-ln95047-085-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s4w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95047-085-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s4w3</w.rf>
   <form>pohybují</form>
   <lemma>pohybovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95047-085-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s4w4</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95047-085-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s4w5</w.rf>
   <form>šesti</form>
   <lemma>šest`6</lemma>
   <tag>Cn-P2----------</tag>
  </m>
  <m id="m-ln95047-085-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s4w6</w.rf>
   <form>set</form>
   <lemma>sto-2`100</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s4w7</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s4w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95047-085-p2s5">
  <m id="m-ln95047-085-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s5w1</w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95047-085-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s5w2</w.rf>
   <form>pojištění</form>
   <lemma>pojištění_^(*5stit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s5w3</w.rf>
   <form>dostanou</form>
   <lemma>dostat</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95047-085-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s5w4</w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s5w5</w.rf>
   <form>přibližně</form>
   <lemma>přibližně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95047-085-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s5w6</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP4----------</tag>
  </m>
  <m id="m-ln95047-085-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s5w7</w.rf>
   <form>sta</form>
   <lemma>sto-2`100</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s5w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95047-085-p2s6">
  <m id="m-ln95047-085-p2s6w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w1</w.rf>
   <form>Ministerstvo</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s6w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w2</w.rf>
   <form>zdravotnictví</form>
   <lemma>zdravotnictví</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s6w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w3</w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PPXP3--3-------</tag>
  </m>
  <m id="m-ln95047-085-p2s6w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w4</w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s6w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w5</w.rf>
   <form>kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95047-085-p2s6w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w6</w.rf>
   <form>peněz</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s6w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w7</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95047-085-p2s6w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w8</w.rf>
   <form>nemocných</form>
   <lemma>nemocný-1_^(pacient)</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s6w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w9</w.rf>
   <form>slibuje</form>
   <lemma>slibovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95047-085-p2s6w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w10</w.rf>
   <form>již</form>
   <lemma>již</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95047-085-p2s6w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w11</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95047-085-p2s6w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w12</w.rf>
   <form>prvního</form>
   <lemma>první</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m-ln95047-085-p2s6w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w13</w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s6w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w14</w.rf>
   <form>zvýšené</form>
   <lemma>zvýšený_^(*3it)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln95047-085-p2s6w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w15</w.rf>
   <form>platby</form>
   <lemma>platba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s6w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w16</w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95047-085-p2s6w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w17</w.rf>
   <form>pojišťoven</form>
   <lemma>pojišťovna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95047-085-p2s6w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-085-p2s6w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-147-p1s1">
  <m id="m-ln95048-147-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p1s1w1</w.rf>
   <form>Privatizace</form>
   <lemma>privatizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95048-147-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p1s1w2</w.rf>
   <form>nevylučuje</form>
   <lemma>vylučovat_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-ln95048-147-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p1s1w3</w.rf>
   <form>bankroty</form>
   <lemma>bankrot</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
 </s>
 <s id="m-ln95048-147-p2s1">
  <m id="m-ln95048-147-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w1</w.rf>
   <form>Spláčou</form>
   <lemma>splakat</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95048-147-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w2</w.rf>
   <form>dikové</form>
   <lemma>dik</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-ln95048-147-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-147-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w4</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-ln95048-147-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w5</w.rf>
   <form>vložili</form>
   <lemma>vložit_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-147-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w6</w.rf>
   <form>body</form>
   <lemma>bod</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln95048-147-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w7</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-147-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w8</w.rf>
   <form>Masokombinátu</form>
   <lemma>masokombinát</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w9</w.rf>
   <form>Kladno</form>
   <lemma>Kladno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln95048-147-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-147-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w11</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95048-147-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w12</w.rf>
   <form>výdělkem</form>
   <lemma>výdělek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln95048-147-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p2s1w13</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-147-p3s1">
  <m id="m-ln95048-147-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w1</w.rf>
   <form>Přestože</form>
   <lemma>přestože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w2</w.rf>
   <form>představitelé</form>
   <lemma>představitel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w3</w.rf>
   <form>ministerstva</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w4</w.rf>
   <form>privatizace</form>
   <lemma>privatizace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w6</w.rf>
   <form>FNM</form>
   <lemma>FNM-1_:B_;K_;p_^(Fond_národního_majetku)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln95048-147-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w7</w.rf>
   <form>slibovali</form>
   <lemma>slibovat_:T</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-147-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w9</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w10</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w11</w.rf>
   <form>druhé</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w12</w.rf>
   <form>privatizační</form>
   <lemma>privatizační</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w13</w.rf>
   <form>vlny</form>
   <lemma>vlna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w14</w.rf>
   <form>zařadí</form>
   <lemma>zařadit_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95048-147-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w15</w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w16</w.rf>
   <form>kvalitní</form>
   <lemma>kvalitní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w18</w.rf>
   <form>perspektivní</form>
   <lemma>perspektivní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w19</w.rf>
   <form>podniky</form>
   <lemma>podnik</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w21</w.rf>
   <form>nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w22</w.rf>
   <form>připouštějí</form>
   <lemma>připouštět_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95048-147-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w24</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w25</w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZIP1----------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w26</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w27</w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>P5XP2--3-------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w28</w.rf>
   <form>mohou</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-ln95048-147-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w29</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95048-147-p3s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w30</w.rf>
   <form>relativně</form>
   <lemma>relativně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w31</w.rf>
   <form>krátké</form>
   <lemma>krátký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w32</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w33</w.rf>
   <form>zbankrotovat</form>
   <lemma>zbankrotovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95048-147-p3s1w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p3s1w34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-147-p4s1">
  <m id="m-ln95048-147-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w2</w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w3</w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w4</w.rf>
   <form>výběru</form>
   <lemma>výběr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w6</w.rf>
   <form>zařazení</form>
   <lemma>zařazení_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w7</w.rf>
   <form>podniků</form>
   <lemma>podnik</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w8</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w9</w.rf>
   <form>definitivní</form>
   <lemma>definitivní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w10</w.rf>
   <form>nabídky</form>
   <lemma>nabídka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w12</w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w13</w.rf>
   <form>vlny</form>
   <lemma>vlna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w14</w.rf>
   <form>uplynulo</form>
   <lemma>uplynout</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln95048-147-p4s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w15</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w16</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w17</w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w18</w.rf>
   <form>čtvrtě</form>
   <lemma>čtvrt-2_^(čtvrtina)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w19</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-ln95048-147-p4s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w20</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w21</w.rf>
   <form>my</form>
   <lemma>já</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w22</w.rf>
   <form>nemůžeme</form>
   <lemma>moci_^(mít_možnost_[něco_dělat])</lemma>
   <tag>VB-P---1P-NA---</tag>
  </m>
  <m id="m-ln95048-147-p4s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w23</w.rf>
   <form>vyloučit</form>
   <lemma>vyloučit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w25</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w26</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w27</w.rf>
   <form>toto</form>
   <lemma>tento</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w28</w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w29</w.rf>
   <form>nedošlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS---XR-NA---</tag>
  </m>
  <m id="m-ln95048-147-p4s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w30</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w31</w.rf>
   <form>posunu</form>
   <lemma>posun</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w32</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w33</w.rf>
   <form>hospodaření</form>
   <lemma>hospodaření_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w34</w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w35</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w36</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w37</w.rf>
   <form>uvedl</form>
   <lemma>uvést</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95048-147-p4s1w38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w38</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w39</w.rf>
   <form>dotaz</form>
   <lemma>dotaz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w40">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w40</w.rf>
   <form>LN</form>
   <lemma>LN-1_:B_;R_^(Lidové_noviny,_deník)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-ln95048-147-p4s1w41">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w41</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m-ln95048-147-p4s1w42">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w42</w.rf>
   <form>místopředseda</form>
   <lemma>místopředseda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w43">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w43</w.rf>
   <form>FNM</form>
   <lemma>FNM-1_:B_;K_;p_^(Fond_národního_majetku)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln95048-147-p4s1w44">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w44</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w45">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w45</w.rf>
   <form>Čermák</form>
   <lemma>čermák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95048-147-p4s1w46">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-147-p4s1w46</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-80-p1s1">
  <m id="m-ln94204-80-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p1s1w1</w.rf>
   <form>Rozruch</form>
   <lemma>rozruch</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94204-80-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p1s1w2</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94204-80-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p1s1w3</w.rf>
   <form>L</form>
   <lemma>L-0_:B_;Y</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-ln94204-80-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p1s1w4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-80-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p1s1w5</w.rf>
   <form>Pittnera</form>
   <lemma>Pittner_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln94204-80-p2s1A">
  <m id="m-ln94204-80-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Aw1</w.rf>
   <form>Bratislava</form>
   <lemma>Bratislava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Aw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-80-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Aw3</w.rf>
   <form>miš</form>
   <lemma>miš-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94204-80-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Aw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-80-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Aw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-80-p2s1B">
  <m id="m-ln94204-80-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw1</w.rf>
   <form>Značný</form>
   <lemma>značný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw2</w.rf>
   <form>rozruch</form>
   <lemma>rozruch</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw3</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw4</w.rf>
   <form>slovenské</form>
   <lemma>slovenský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw5</w.rf>
   <form>předvolební</form>
   <lemma>předvolební</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw6</w.rf>
   <form>atmosféře</form>
   <lemma>atmosféra</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw7</w.rf>
   <form>vyvolalo</form>
   <lemma>vyvolat_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw8</w.rf>
   <form>jmenování</form>
   <lemma>jmenování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw9</w.rf>
   <form>nových</form>
   <lemma>nový</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw10</w.rf>
   <form>generálů</form>
   <lemma>generál</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw11</w.rf>
   <form>armády</form>
   <lemma>armáda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw13</w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s1Bw14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-80-p2s2">
  <m id="m-ln94204-80-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w1</w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-80-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w2</w.rf>
   <form>příležitosti</form>
   <form_change>spell</form_change>
   <lemma>příležitost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w2</w.rf>
   <form>50</form>
   <form_change>spell</form_change>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-80-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-80-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w5</w.rf>
   <form>výročí</form>
   <lemma>výročí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w6</w.rf>
   <form>Slovenského</form>
   <lemma>slovenský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w7</w.rf>
   <form>národního</form>
   <lemma>národní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w8</w.rf>
   <form>povstání</form>
   <lemma>povstání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w9</w.rf>
   <form>povýšil</form>
   <lemma>povýšit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-80-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w10</w.rf>
   <form>prezident</form>
   <lemma>prezident</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w11</w.rf>
   <form>Kováč</form>
   <lemma>Kováč_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w12</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94204-80-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w13</w.rf>
   <form>hodnosti</form>
   <lemma>hodnost</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w14</w.rf>
   <form>generálmajora</form>
   <lemma>generálmajor</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w15</w.rf>
   <form>Ministerstva</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w16</w.rf>
   <form>vnitra</form>
   <lemma>vnitro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w17</w.rf>
   <form>SR</form>
   <lemma>SR-1_:B_;G_^(Slovenská_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94204-80-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w18</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-80-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w19</w.rf>
   <form>současného</form>
   <lemma>současný</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w20</w.rf>
   <form>ministra</form>
   <lemma>ministr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w21</w.rf>
   <form>vnitra</form>
   <lemma>vnitro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w22</w.rf>
   <form>Ladislava</form>
   <lemma>Ladislav_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w23</w.rf>
   <form>Pittnera</form>
   <lemma>Pittner_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s2w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-80-p2s3">
  <m id="m-ln94204-80-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w1</w.rf>
   <form>Jako</form>
   <lemma>jako</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94204-80-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w2</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m-ln94204-80-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w3</w.rf>
   <form>zareagovalo</form>
   <lemma>zareagovat_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-80-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w4</w.rf>
   <form>HZDS</form>
   <lemma>HZDS-1_:B_;K_;p_,t_^(Hnutie_za_demokratické_Slovensko)</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-ln94204-80-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-80-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w6</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-ln94204-80-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w7</w.rf>
   <form>Pittnerovo</form>
   <lemma>Pittnerův_;S_^(*2)</lemma>
   <tag>AUNS4M---------</tag>
  </m>
  <m id="m-ln94204-80-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w8</w.rf>
   <form>jmenování</form>
   <lemma>jmenování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w9</w.rf>
   <form>označilo</form>
   <lemma>označit_:W</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-80-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w10</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-80-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w11</w.rf>
   <form>skandální</form>
   <lemma>skandální</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94204-80-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-80-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w13</w.rf>
   <form>znevažující</form>
   <lemma>znevažující_^(*5ovat)</lemma>
   <tag>AGNS4-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w14</w.rf>
   <form>památku</form>
   <lemma>památka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94204-80-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w15</w.rf>
   <form>padlých</form>
   <lemma>padlý</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94204-80-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-80-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w17</w.rf>
   <form>SNP</form>
   <lemma>SNP-1_:B_;K_;p_^(Slovenské_národní_povstání)</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-ln94204-80-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-80-p2s3w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-18-p1s1">
  <m id="m-ln94204-18-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p1s1w1</w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94204-18-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p1s1w2</w.rf>
   <form>světě</form>
   <lemma>svět</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94204-18-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p1s1w3</w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-18-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p1s1w4</w.rf>
   <form>méně</form>
   <lemma>málo-3</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ln94204-18-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p1s1w5</w.rf>
   <form>pšenice</form>
   <lemma>pšenice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln94204-18-p2s1A">
  <m id="m-ln94204-18-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Aw1</w.rf>
   <form>Londýn</form>
   <lemma>Londýn_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-18-p2s1B">
  <m id="m-ln94204-18-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw1</w.rf>
   <form>Světová</form>
   <lemma>světový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw2</w.rf>
   <form>rada</form>
   <lemma>rada-3_^(poradní_sbor;_př._Česká_národní_r.)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw3</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw4</w.rf>
   <form>pšenici</form>
   <lemma>pšenice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw5</w.rf>
   <form>odhaduje</form>
   <lemma>odhadovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw6</w.rf>
   <form>letošní</form>
   <lemma>letošní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw7</w.rf>
   <form>světový</form>
   <lemma>světový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw8</w.rf>
   <form>obchod</form>
   <lemma>obchod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw9</w.rf>
   <form>pšenicí</form>
   <lemma>pšenice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw10</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw11</w.rf>
   <form>95.8</form>
   <form_change>num_normalization</form_change>
   <lemma>95.8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw12</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw13</w.rf>
   <form>tun</form>
   <lemma>tuna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw14</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw15</w.rf>
   <form>předchozímu</form>
   <lemma>předchozí</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw16</w.rf>
   <form>odhadu</form>
   <lemma>odhad</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw17</w.rf>
   <form>94.7</form>
   <form_change>num_normalization</form_change>
   <lemma>94.7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw18</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw19</w.rf>
   <form>tun</form>
   <lemma>tuna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s1Bw20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-18-p2s2">
  <m id="m-ln94204-18-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-18-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w2</w.rf>
   <form>sezoně</form>
   <lemma>sezona</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w3</w.rf>
   <form>1993</form>
   <lemma>1993</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-18-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w4</w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-18-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w5</w.rf>
   <form>94</form>
   <lemma>94</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-18-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w6</w.rf>
   <form>dosáhl</form>
   <lemma>dosáhnout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-18-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w7</w.rf>
   <form>světový</form>
   <lemma>světový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94204-18-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w8</w.rf>
   <form>obchod</form>
   <lemma>obchod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w9</w.rf>
   <form>pšenicí</form>
   <lemma>pšenice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w10</w.rf>
   <form>93.3</form>
   <form_change>num_normalization</form_change>
   <lemma>93.3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-18-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w11</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w12</w.rf>
   <form>tun</form>
   <lemma>tuna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-18-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w14</w.rf>
   <form>uvádí</form>
   <lemma>uvádět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-18-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w15</w.rf>
   <form>agentura</form>
   <lemma>agentura</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w16</w.rf>
   <form>Reuter</form>
   <lemma>Reuter_;K</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-18-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p2s2w17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-18-p3s1">
  <m id="m-ln94204-18-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w1</w.rf>
   <form>Původní</form>
   <lemma>původní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w2</w.rf>
   <form>údaje</form>
   <lemma>údaj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w3</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln94204-18-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w4</w.rf>
   <form>revidovány</form>
   <lemma>revidovat_:T</lemma>
   <tag>VsTP---XX-AP---</tag>
  </m>
  <m id="m-ln94204-18-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w5</w.rf>
   <form>zejména</form>
   <lemma>zejména</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-18-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w6</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94204-18-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w7</w.rf>
   <form>ohledem</form>
   <lemma>ohled</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w8</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-18-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w9</w.rf>
   <form>vyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAIS4----2A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w10</w.rf>
   <form>dovoz</form>
   <lemma>dovoz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w11</w.rf>
   <form>bývalého</form>
   <lemma>bývalý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w12</w.rf>
   <form>Sovětského</form>
   <lemma>sovětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w13</w.rf>
   <form>svazu</form>
   <lemma>svaz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-18-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w15</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94204-18-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w16</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln94204-18-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w17</w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-18-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w18</w.rf>
   <form>dovézt</form>
   <lemma>dovézt</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w19</w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-18-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w20</w.rf>
   <form>9.3</form>
   <form_change>num_normalization</form_change>
   <lemma>9.3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-18-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w21</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w22</w.rf>
   <form>tun</form>
   <lemma>tuna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w23</w.rf>
   <form>pšenice</form>
   <lemma>pšenice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w24</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94204-18-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w25</w.rf>
   <form>původnímu</form>
   <lemma>původní</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w26</w.rf>
   <form>odhadu</form>
   <lemma>odhad</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w27</w.rf>
   <form>8.5</form>
   <form_change>num_normalization</form_change>
   <lemma>8.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94204-18-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w28</w.rf>
   <form>milionu</form>
   <lemma>milión`1000000</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w29</w.rf>
   <form>tun</form>
   <lemma>tuna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p3s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p3s1w30</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-18-p4s1">
  <m id="m-ln94204-18-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w1</w.rf>
   <form>Celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w2</w.rf>
   <form>řada</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w3</w.rf>
   <form>republik</form>
   <lemma>republika</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w4</w.rf>
   <form>SNS</form>
   <lemma>SNS-2_:B_;G_^(Sdr._nezávislých_států)</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-ln94204-18-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w5</w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-ln94204-18-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w6</w.rf>
   <form>muset</form>
   <lemma>muset</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w7</w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-18-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w8</w.rf>
   <form>dovézt</form>
   <lemma>dovézt</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w9</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w10</w.rf>
   <form>množství</form>
   <lemma>množství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w11</w.rf>
   <form>pšenice</form>
   <lemma>pšenice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w12</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ln94204-18-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w13</w.rf>
   <form>třetích</form>
   <lemma>třetí</lemma>
   <tag>CrFP2----------</tag>
  </m>
  <m id="m-ln94204-18-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w14</w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w15</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-18-p4s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w16</w.rf>
   <form>zejména</form>
   <lemma>zejména</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-18-p4s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w17</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-18-p4s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w18</w.rf>
   <form>nedostatečnou</form>
   <lemma>dostatečný</lemma>
   <tag>AAFS4----1N----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w19</w.rf>
   <form>domácí</form>
   <lemma>domácí</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w20</w.rf>
   <form>úrodu</form>
   <lemma>úroda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-18-p4s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w22</w.rf>
   <form>nižší</form>
   <lemma>nízký</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w23</w.rf>
   <form>produkci</form>
   <lemma>produkce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w24</w.rf>
   <form>Kazachstánu</form>
   <lemma>Kazachstán_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94204-18-p4s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-18-p4s1w25</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-108-p1s1">
  <m id="m-mf920925-108-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-108-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w2</w.rf>
   <form>Bosně</form>
   <lemma>Bosna_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-mf920925-108-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-108-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w4</w.rf>
   <form>Hercegovině</form>
   <lemma>Hercegovina_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-mf920925-108-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w5</w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920925-108-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w6</w.rf>
   <form>pokračují</form>
   <lemma>pokračovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf920925-108-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w7</w.rf>
   <form>prudké</form>
   <lemma>prudký</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-mf920925-108-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w8</w.rf>
   <form>boje</form>
   <lemma>boj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-mf920925-108-p1s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w9</w.rf>
   <form>ZRANĚNI</form>
   <lemma>zranit_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-mf920925-108-p1s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w10</w.rf>
   <form>DVA</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-mf920925-108-p1s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w11</w.rf>
   <form>FRANCOUZŠTÍ</form>
   <lemma>francouzský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-mf920925-108-p1s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p1s1w12</w.rf>
   <form>VOJÁCI</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
 </s>
 <s id="m-mf920925-108-p2s1">
  <m id="m-mf920925-108-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s1w1</w.rf>
   <form>Sarajevo</form>
   <lemma>Sarajevo_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf920925-108-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s1w2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-108-p2s2">
  <m id="m-mf920925-108-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-108-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w2</w.rf>
   <form>hlavním</form>
   <lemma>hlavní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf920925-108-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w3</w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf920925-108-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w4</w.rf>
   <form>Bosny</form>
   <lemma>Bosna_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-108-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w6</w.rf>
   <form>Hercegoviny</form>
   <lemma>Hercegovina_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w7</w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-mf920925-108-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m-mf920925-108-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w9</w.rf>
   <form>středu</form>
   <lemma>středa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf920925-108-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w10</w.rf>
   <form>zraněni</form>
   <lemma>zranit_:W</lemma>
   <tag>VsMP---XX-AP---</tag>
  </m>
  <m id="m-mf920925-108-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w11</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-mf920925-108-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w12</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-mf920925-108-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w13</w.rf>
   <form>francouzští</form>
   <lemma>francouzský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-mf920925-108-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w14</w.rf>
   <form>příslušníci</form>
   <lemma>příslušník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-mf920925-108-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w15</w.rf>
   <form>ochranných</form>
   <lemma>ochranný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-mf920925-108-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w16</w.rf>
   <form>sil</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w17</w.rf>
   <form>OSN</form>
   <lemma>OSN-1_:B_;K_^(Organizace_spojených_národů)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-mf920925-108-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w18</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-108-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w19</w.rf>
   <form>UNPROFOR</form>
   <lemma>UNPROFOR_:B</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-mf920925-108-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w20</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-108-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p2s2w21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-108-p3s1">
  <m id="m-mf920925-108-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s1w1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-108-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s1w2</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-mf920925-108-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s1w3</w.rf>
   <form>místech</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s1w4</w.rf>
   <form>Bosny</form>
   <lemma>Bosna_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s1w5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-108-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s1w6</w.rf>
   <form>Hercegoviny</form>
   <lemma>Hercegovina_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s1w7</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920925-108-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s1w8</w.rf>
   <form>pokračovaly</form>
   <lemma>pokračovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-mf920925-108-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s1w9</w.rf>
   <form>boje</form>
   <lemma>boj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s1w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-108-p3s2">
  <m id="m-mf920925-108-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w1</w.rf>
   <form>Nejprudší</form>
   <lemma>prudký</lemma>
   <tag>AAFP1----3A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w2</w.rf>
   <form>srážky</form>
   <lemma>srážka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf920925-108-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w4</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920925-108-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w5</w.rf>
   <form>dostupných</form>
   <lemma>dostupný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w6</w.rf>
   <form>zpráv</form>
   <lemma>zpráva</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w7</w.rf>
   <form>nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920925-108-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w8</w.rf>
   <form>odehrávají</form>
   <lemma>odehrávat_:T_^(*3t)</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf920925-108-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w9</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-108-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w10</w.rf>
   <form>centrální</form>
   <lemma>centrální</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w11</w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w12</w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w13</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920925-108-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w14</w.rf>
   <form>Maglaje</form>
   <lemma>Maglaj_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-108-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-108-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w17</w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w18</w.rf>
   <form>Bihače</form>
   <lemma>Bihač_;G_;S</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-108-p3s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w20</w.rf>
   <form>západní</form>
   <lemma>západní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w21</w.rf>
   <form>Bosně</form>
   <lemma>Bosna_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s2w22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-108-p3s3">
  <m id="m-mf920925-108-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s3w1</w.rf>
   <form>Srbské</form>
   <lemma>srbský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-mf920925-108-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s3w2</w.rf>
   <form>zdroje</form>
   <lemma>zdroj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s3w3</w.rf>
   <form>nehlásí</form>
   <lemma>hlásit_:T</lemma>
   <tag>VB-P---3P-NA---</tag>
  </m>
  <m id="m-mf920925-108-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s3w4</w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-mf920925-108-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s3w5</w.rf>
   <form>Sarajeva</form>
   <lemma>Sarajevo_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s3w6</w.rf>
   <form>rozsáhlejší</form>
   <lemma>rozsáhlý</lemma>
   <tag>AAIP4----2A----</tag>
  </m>
  <m id="m-mf920925-108-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s3w7</w.rf>
   <form>ozbrojené</form>
   <lemma>ozbrojený_^(*3it)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-mf920925-108-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s3w8</w.rf>
   <form>střety</form>
   <lemma>střet</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s3w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-108-p3s4">
  <m id="m-mf920925-108-p3s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w1</w.rf>
   <form>Bosenský</form>
   <lemma>bosenský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf920925-108-p3s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w2</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-108-p3s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w3</w.rf>
   <form>chorvatský</form>
   <lemma>chorvatský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf920925-108-p3s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w4</w.rf>
   <form>rozhlas</form>
   <lemma>rozhlas</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w5</w.rf>
   <form>však</form>
   <lemma>však</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-108-p3s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w6</w.rf>
   <form>mezitím</form>
   <lemma>mezitím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920925-108-p3s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w7</w.rf>
   <form>informovaly</form>
   <lemma>informovat_:T_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-mf920925-108-p3s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w8</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-108-p3s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w9</w.rf>
   <form>pokračujícím</form>
   <lemma>pokračující_^(*5ovat)</lemma>
   <tag>AGNS6-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w10</w.rf>
   <form>ostřelování</form>
   <lemma>ostřelování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w11</w.rf>
   <form>metropole</form>
   <lemma>metropole</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w12</w.rf>
   <form>srbskými</form>
   <lemma>srbský</lemma>
   <tag>AANP7----1A----</tag>
  </m>
  <m id="m-mf920925-108-p3s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w13</w.rf>
   <form>děly</form>
   <lemma>dělo</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-mf920925-108-p3s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-108-p3s4w14</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
