<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="sample9.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-cmpr9413-006-p1s1">
  <m id="m-cmpr9413-006-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p1s1w1</w.rf>
   <form>Začal</form>
   <lemma>začít-1</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p1s1w2</w.rf>
   <form>podnikat</form>
   <lemma>podnikat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-cmpr9413-006-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p1s1w3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p1s1w4</w.rf>
   <form>vystřízlivěl</form>
   <lemma>vystřízlivět_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
 </s>
 <s id="m-cmpr9413-006-p2s1A">
  <m id="m-cmpr9413-006-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Aw1</w.rf>
   <form>Základem</form>
   <lemma>základ</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Aw2</w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Aw3</w.rf>
   <form>rodinná</form>
   <lemma>rodinný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-cmpr9413-006-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Aw4</w.rf>
   <form>tradice</form>
   <lemma>tradice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Aw5</w.rf>
   <form>*</form>
   <lemma>*</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-006-p2s1B">
  <m id="m-cmpr9413-006-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Bw1</w.rf>
   <form>Vzniká</form>
   <lemma>vznikat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Bw2</w.rf>
   <form>model</form>
   <lemma>model</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Bw3</w.rf>
   <form>spolupráce</form>
   <lemma>spolupráce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Bw4</w.rf>
   <form>zemědělců</form>
   <lemma>zemědělec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Bw5</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p2s1Bw6</w.rf>
   <form>zpracovatelů</form>
   <lemma>zpracovatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
 </s>
 <s id="m-cmpr9413-006-p3s1">
  <m id="m-cmpr9413-006-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s1w1</w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s1w2</w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s1w3</w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s1w4</w.rf>
   <form>naměkko</form>
   <lemma>naměkko</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s1w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s1w6</w.rf>
   <form>neschopen</form>
   <lemma>schopný</lemma>
   <tag>ACYS------N----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s1w7</w.rf>
   <form>mluvit</form>
   <lemma>mluvit_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s1w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-006-p3s2">
  <m id="m-cmpr9413-006-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w1</w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w2</w.rf>
   <form>hodnotí</form>
   <lemma>hodnotit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w3</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w4</w.rf>
   <form>Chodura</form>
   <lemma>Chodura_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w6</w.rf>
   <form>podnikatel</form>
   <lemma>podnikatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w8</w.rf>
   <form>Ostravy</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w10</w.rf>
   <form>první</form>
   <lemma>první</lemma>
   <tag>CrIP4----------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w11</w.rf>
   <form>momenty</form>
   <lemma>moment</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w12</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w13</w.rf>
   <form>oznámení</form>
   <lemma>oznámení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w15</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w16</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w17</w.rf>
   <form>stal</form>
   <lemma>stát-2_^(něco_se_přihodilo)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w18</w.rf>
   <form>Vynikajícím</form>
   <lemma>vynikající_^(*4t)</lemma>
   <tag>AGMS7-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w19</w.rf>
   <form>podnikatelem</form>
   <lemma>podnikatel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w20</w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w21</w.rf>
   <form>1993</form>
   <lemma>1993</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s2w22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-006-p3s3">
  <m id="m-cmpr9413-006-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w1</w.rf>
   <form>Jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w2</w.rf>
   <form>dojetí</form>
   <lemma>dojetí_^(př._k_slzám)_(*3mout)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w3</w.rf>
   <form>znásobila</form>
   <lemma>znásobit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w4</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w5</w.rf>
   <form>vyhlašování</form>
   <lemma>vyhlašování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w6</w.rf>
   <form>přítomnost</form>
   <lemma>přítomnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w7</w.rf>
   <form>Tomáše</form>
   <lemma>Tomáš_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w8</w.rf>
   <form>Bati</form>
   <form_change>spell</form_change>
   <lemma>Baťa-3_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w10</w.rf>
   <form>Jiřího</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w11</w.rf>
   <form>Lobkowitze</form>
   <lemma>Lobkowitz_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w13</w.rf>
   <form>Tomáše</form>
   <lemma>Tomáš_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w14</w.rf>
   <form>Ježka</form>
   <lemma>ježek</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w15</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w16</w.rf>
   <form>pořadatelů</form>
   <lemma>pořadatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w17</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w18</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w19</w.rf>
   <form>Českého</form>
   <lemma>český</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w20</w.rf>
   <form>manažerského</form>
   <lemma>manažerský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w21</w.rf>
   <form>centra</form>
   <lemma>centrum</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w22</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w23</w.rf>
   <form>Čelákovicích</form>
   <lemma>Čelákovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s3w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-006-p3s4">
  <m id="m-cmpr9413-006-p3s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s4w1</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s4w2</w.rf>
   <form>letošním</form>
   <lemma>letošní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s4w3</w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s4w4</w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s4w5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s4w6</w.rf>
   <form>spolupodílí</form>
   <lemma>spolupodílet_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p3s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s4w7</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p3s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s4w8</w.rf>
   <form>Profit</form>
   <lemma>profit</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p3s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p3s4w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-006-p4s1">
  <m id="m-cmpr9413-006-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p4s1w1</w.rf>
   <form>Jaromír</form>
   <lemma>Jaromír_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p4s1w2</w.rf>
   <form>Složil</form>
   <lemma>Složil_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-cmpr9413-006-p5s1">
  <m id="m-cmpr9413-006-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s1w1</w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s1w2</w.rf>
   <form>Chodura</form>
   <lemma>Chodura_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s1w3</w.rf>
   <form>podniká</form>
   <lemma>podnikat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s1w4</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9413-006-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s1w5</w.rf>
   <form>oboru</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s1w6</w.rf>
   <form>výroby</form>
   <lemma>výroba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s1w7</w.rf>
   <form>masných</form>
   <lemma>masný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s1w8</w.rf>
   <form>výrobků</form>
   <lemma>výrobek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s1w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-006-p5s2">
  <m id="m-cmpr9413-006-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w1</w.rf>
   <form>Úzce</form>
   <lemma>úzce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w2</w.rf>
   <form>navazuje</form>
   <lemma>navazovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-006-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9413-006-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w4</w.rf>
   <form>tradici</form>
   <lemma>tradice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w5</w.rf>
   <form>podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w6</w.rf>
   <form>svého</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m-cmpr9413-006-p5s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w7</w.rf>
   <form>rodu</form>
   <lemma>rod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p5s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w9</w.rf>
   <form>především</form>
   <lemma>především</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9413-006-p5s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w10</w.rf>
   <form>dědy</form>
   <lemma>děda</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-006-p5s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-006-p5s2w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-021-p2s1">
  <m id="m-cmpr9410-021-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p2s1w1</w.rf>
   <form>štoček</form>
   <lemma>štoček</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p2s1w2</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p2s1w3</w.rf>
   <form>KALENDÁŘ</form>
   <lemma>kalendář</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p2s1w4</w.rf>
   <form>PODNIKATELE</form>
   <lemma>podnikatel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
 </s>
 <s id="m-cmpr9410-021-p3s1">
  <m id="m-cmpr9410-021-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p3s1w1</w.rf>
   <form>Výstavy</form>
   <lemma>výstava</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p3s1w2</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-021-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p3s1w3</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p3s1w4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p3s1w5</w.rf>
   <form>polovině</form>
   <lemma>polovina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p3s1w6</w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-cmpr9410-021-p4s2">
  <m id="m-cmpr9410-021-p4s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w1</w.rf>
   <form>Organizuje</form>
   <lemma>organizovat_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w2</w.rf>
   <form>Zahrada</form>
   <lemma>zahrada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w3</w.rf>
   <form>Čech</form>
   <lemma>Čechy_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w5</w.rf>
   <form>výstaviště</form>
   <lemma>výstaviště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w7</w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w8</w.rf>
   <form>vinici</form>
   <lemma>vinice_^(kdo_je_vinen/vinna)_(*3ík)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w9</w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w11</w.rf>
   <form>412</form>
   <lemma>412</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w12</w.rf>
   <form>01</form>
   <lemma>01</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w13</w.rf>
   <form>Litoměřice</form>
   <lemma>Litoměřice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w15</w.rf>
   <form>tel</form>
   <lemma>telefon_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w17</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w18</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w19</w.rf>
   <form>0416</form>
   <lemma>0416</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w20</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w21</w.rf>
   <form>3927</form>
   <lemma>3927</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w23</w.rf>
   <form>5714</form>
   <lemma>5714</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w24</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w25</w.rf>
   <form>FAX</form>
   <lemma>fax</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w26</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w27</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w28</w.rf>
   <form>0416</form>
   <lemma>0416</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w29</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w30</w.rf>
   <form>4057</form>
   <lemma>4057</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p4s2w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p4s2w31</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-021-p5s2">
  <m id="m-cmpr9410-021-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w1</w.rf>
   <form>Organizují</form>
   <lemma>organizovat_:T_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w2</w.rf>
   <form>Brněnské</form>
   <lemma>brněnský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w3</w.rf>
   <form>veletrhy</form>
   <lemma>veletrh</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w5</w.rf>
   <form>výstavy</form>
   <lemma>výstava</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w7</w.rf>
   <form>a</form>
   <lemma>akciový_:B_^(jen_akciová_společnost)</lemma>
   <tag>AAXXX----1A---8</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w9</w.rf>
   <form>s</form>
   <lemma>společnost_:B</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w12</w.rf>
   <form>pražská</form>
   <lemma>pražský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w13</w.rf>
   <form>kancelář</form>
   <lemma>kancelář</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w15</w.rf>
   <form>Washingtonova</form>
   <lemma>Washingtonův-1_;S_^(*4-1)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w16</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w17</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w18</w.rf>
   <form>112</form>
   <lemma>112</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w19</w.rf>
   <form>49</form>
   <lemma>49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w20</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w21</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w22</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w23</w.rf>
   <form>tel</form>
   <lemma>telefon_:B</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w25</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w26</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w27</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w28</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w29</w.rf>
   <form>220922</form>
   <form_change>num_normalization</form_change>
   <lemma>220922</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w30</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w31</w.rf>
   <form>FAX</form>
   <lemma>fax</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w32</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w33</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w34</w.rf>
   <form>02</form>
   <lemma>02</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w35</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w36</w.rf>
   <form>242282</form>
   <form_change>num_normalization</form_change>
   <lemma>242282</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w37</w.rf>
   <form>43</form>
   <lemma>43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-021-p5s2w38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-021-p5s2w38</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-003-p3s1">
  <m id="m-cmpr9410-003-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p3s1w1</w.rf>
   <form>|</form>
   <lemma>|</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p3s1w2</w.rf>
   <form>Rady</form>
   <lemma>rada-1_^(př._dát_někomu_dobrou_radu)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p3s1w3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9410-003-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p3s1w4</w.rf>
   <form>telefon</form>
   <lemma>telefon</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p3s1w5</w.rf>
   <form>|</form>
   <lemma>|</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-003-p5s1">
  <m id="m-cmpr9410-003-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s1w1</w.rf>
   <form>Potřebujete</form>
   <lemma>potřebovat_:T</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-cmpr9410-003-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s1w2</w.rf>
   <form>rychle</form>
   <lemma>rychle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s1w3</w.rf>
   <form>poradit</form>
   <lemma>poradit_:T_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s1w4</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-003-p5s2">
  <m id="m-cmpr9410-003-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s2w1</w.rf>
   <form>Zvedněte</form>
   <lemma>zvednout_:T_:W</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s2w2</w.rf>
   <form>telefon</form>
   <lemma>telefon</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s2w3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s2w4</w.rf>
   <form>zavolejte</form>
   <lemma>zavolat_:W</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s2w5</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-003-p5s3">
  <m id="m-cmpr9410-003-p5s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s3w1</w.rf>
   <form>Váš</form>
   <lemma>tvůj_^(přivlast.)</lemma>
   <tag>PSIS4-P2-------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s3w2</w.rf>
   <form>obecně</form>
   <lemma>obecně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s3w3</w.rf>
   <form>platný</form>
   <lemma>platný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s3w4</w.rf>
   <form>dotaz</form>
   <lemma>dotaz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s3w5</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-003-p5s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s3w6</w.rf>
   <form>připraven</form>
   <lemma>připravit_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-cmpr9410-003-p5s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s3w7</w.rf>
   <form>zodpovědět</form>
   <lemma>zodpovědět</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s3w8</w.rf>
   <form>spolupracovník</form>
   <lemma>spolupracovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s3w9</w.rf>
   <form>Profitu</form>
   <lemma>profit</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s3w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-003-p5s4">
  <m id="m-cmpr9410-003-p5s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w2</w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w4</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w5</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w6</w.rf>
   <form>nedovoláte</form>
   <lemma>dovolat_:W</lemma>
   <tag>VB-P---2P-NA---</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w7</w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w8</w.rf>
   <form>den</form>
   <lemma>den_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w10</w.rf>
   <form>vytočte</form>
   <lemma>vytočit_:W</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w11</w.rf>
   <form>číslo</form>
   <lemma>číslo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w12</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w13</w.rf>
   <form>večerních</form>
   <lemma>večerní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w14</w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w15</w.rf>
   <form>nočních</form>
   <lemma>noční</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w16</w.rf>
   <form>hodinách</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w18</w.rf>
   <form>svůj</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8IS4----------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w19</w.rf>
   <form>dotaz</form>
   <lemma>dotaz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w20</w.rf>
   <form>namluvte</form>
   <lemma>namluvit_:W</lemma>
   <tag>Vi-P---2--A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w21</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w22</w.rf>
   <form>telefonní</form>
   <lemma>telefonní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w23</w.rf>
   <form>záznamník</form>
   <lemma>záznamník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s4w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s4w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-003-p5s5">
  <m id="m-cmpr9410-003-p5s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s5w1</w.rf>
   <form>Nejzajímavější</form>
   <lemma>zajímavý</lemma>
   <tag>AAIP4----3A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s5w2</w.rf>
   <form>dotazy</form>
   <lemma>dotaz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s5w3</w.rf>
   <form>najdete</form>
   <lemma>najít</lemma>
   <tag>VB-P---2P-AA---</tag>
  </m>
  <m id="m-cmpr9410-003-p5s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s5w4</w.rf>
   <form>zodpovězené</form>
   <lemma>zodpovězený_^(*4dět)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s5w5</w.rf>
   <form>pravidelně</form>
   <lemma>pravidelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s5w6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s5w7</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m-cmpr9410-003-p5s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s5w8</w.rf>
   <form>stránce</form>
   <lemma>stránka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p5s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p5s5w9</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-003-p6s1">
  <m id="m-cmpr9410-003-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p6s1w1</w.rf>
   <form>Zdravotní</form>
   <lemma>zdravotní_,a</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p6s1w2</w.rf>
   <form>pojištění</form>
   <lemma>pojištění_^(*5stit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-cmpr9410-003-p7s1">
  <m id="m-cmpr9410-003-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w1</w.rf>
   <form>Zajímalo</form>
   <lemma>zajímat_:T</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w2</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w3</w.rf>
   <form>mne</form>
   <lemma>já_^(2./4.pád)</lemma>
   <tag>PP-S4--1-------</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w5</w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w6</w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w7</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w8</w.rf>
   <form>titulu</form>
   <lemma>titul</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w9</w.rf>
   <form>všeobecného</form>
   <lemma>všeobecný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w10</w.rf>
   <form>zdravotního</form>
   <lemma>zdravotní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w11</w.rf>
   <form>pojištění</form>
   <lemma>pojištění_^(*5stit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w12</w.rf>
   <form>pojištěn</form>
   <lemma>pojistit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w13</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w14</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w15</w.rf>
   <form>případ</form>
   <lemma>případ</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w16</w.rf>
   <form>úrazu</form>
   <lemma>úraz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w17</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w18</w.rf>
   <form>pobytu</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w19</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w20</w.rf>
   <form>zahraničí</form>
   <lemma>zahraničí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p7s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p7s1w21</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-003-p8s1">
  <m id="m-cmpr9410-003-p8s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p8s1w1</w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p8s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p8s1w2</w.rf>
   <form>Anděl</form>
   <lemma>anděl</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-003-p8s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p8s1w3</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-003-p8s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-003-p8s1w4</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
</mdata>
